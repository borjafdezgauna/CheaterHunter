clear
clc
matriz1 = dlmread('a1-height.csv',',',1,0);
matriz2 = dlmread('n1-height.csv',',',1,0);
subplot(1,2,1);
hold on
Latitud1 = matriz1(:,1);
Longitud1 = matriz1(:,2);
plot(Longitud1,Latitud1);
Latitud2 = matriz2(:,1);
Longitud2 = matriz2(:,2);
plot(Longitud2,Latitud2);
xlabel('Longitud');
ylabel('Latitud');
title('Coordenadas');
subplot(1,2,2);
hold on
Elevacion1 = matriz1(:,3);
Distancia1 = matriz1(:,4);
plot(Distancia1,Elevacion1);
Elevacion2 = matriz2(:,3);
Distancia2 = matriz2(:,4);
m=plot(Distancia2,Elevacion2);
xlabel('Distancia(km)');
ylabel('Elevacion(m)');
title('Mapa');
saveas (m,'route-elevations.png');


matrizH1=matriz1(:,3);
media1=mean(matrizH1);
desviacion1=std(matrizH1);

[m,n]=size(matriz1);
H1min=matriz1(1,1);
H1max=matriz1(1,1);

for i=1:m
    for j=1:n
        if abs(matriz1(i,j))>H1max
            H1max=abs(matriz1(i,j));
        end
        
        if abs(matriz1(i,j))<H1min
            H1min=abs(matriz1(i,j));
        end
    end
end
disp('Ruta por autopista:')
fprintf('La altura media de la primera ruta es %.2f\n', media1)
fprintf('La desvicion estandar de la primera ruta es %.2f\n', desviacion1)
fprintf('La elevacion minima de la primera ruta es  %.2f y la maxima es %.2f\n\n', H1min,H1max)


matrizH2=matriz2(:,3);
media2=mean(matrizH2);
desviacion2=std(matrizH2);

[m,n]=size(matriz2);
H2min=matriz2(1,1);
H2max=matriz2(1,1);

for i=1:m
    for j=1:n
        if abs(matriz2(i,j))>H2max
            H2max=abs(matriz2(i,j));
        end
        
        if abs(matriz2(i,j))<H2min
            H2min=abs(matriz2(i,j));
        end
    end
end
disp('Ruta por carreteras nacionales:')
fprintf('La altura media de la segunda ruta es %.2f\n', media2)
fprintf('La desvicion estandar de la segunda ruta es %.2f\n', desviacion2)
fprintf('La elevacion minima de la segunda ruta es %.2f y la maxima es %.2f\n', H2min,H2max)
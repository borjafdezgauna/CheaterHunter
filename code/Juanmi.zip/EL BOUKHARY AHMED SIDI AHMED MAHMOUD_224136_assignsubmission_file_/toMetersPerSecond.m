%function [ msSpeed ] = toMetersPerSecond( speedKmH )
%end

function y = toMetersPerSecond(x)
    y = (x*1000/3600)
end

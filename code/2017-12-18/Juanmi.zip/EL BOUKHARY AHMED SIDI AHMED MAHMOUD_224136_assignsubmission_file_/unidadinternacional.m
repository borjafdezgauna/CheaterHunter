%function [ m ] = toMeters( km )
%end

%f(x)=x*100

function y = toMeters(x)
       y = x*100
end
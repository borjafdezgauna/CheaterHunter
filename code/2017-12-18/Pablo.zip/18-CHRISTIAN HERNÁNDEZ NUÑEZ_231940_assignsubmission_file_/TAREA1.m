clear;
clc;
y={'a1','n1'};
archivo = ('%s-height.csv');
for i=1:2
    x=sprintf(archivo,y{i});
    matriz=dlmread(x,',',1,0);     
    subplot(1,2,1);
    hold on
    Latitud = matriz(:,1);
    Longitud = matriz(:,2);
    plot(Longitud,Latitud)
    xlabel('Longitud');
    ylabel('Latitud');
    title('Coordenadas');
    subplot(1,2,2);
    hold on
    Elevacion = matriz(:,3);
    Distancia = matriz(:,4);
    plot(Distancia,Elevacion);
    xlabel('Distancia(km)');
    ylabel('Elevacion(m)');
    title('Mapa');
    
    matrizH=matriz(:,3);
    media=mean(matrizH);
    desviacion=std(matrizH);
    Hmax=max(matrizH);
    Hmin=min(matrizH);

    fprintf('Estadisticas de la ruta por la %s\n', y{i})
    fprintf('La altura media de la ruta es %.2f\n', media)
    fprintf('La desviacion estandar de la ruta es %.2f\n', desviacion)
    fprintf('La elevacion minima de la ruta es %.2f y la maxima es %.2f\n\n', Hmin,Hmax)
end

saveas (gcf,'route-elevations.png');
clear;
clc;
y={'a1','n1'};
z={'driver1','driver2'};
archivo = ('%s-%s-log.csv');
for i=1:2
   for j=1:2
       x=sprintf(archivo,y{i},z{j});
       matriz=dlmread(x,','); 
             
       subplot(1,2,i);
    hold on
    velocidad = matriz(:,2);
    distorigen= matriz(:,1);
    plot(distorigen,velocidad);
    xlabel('Distancia(km)');
    ylabel('Velocidad(km/h)');
    title(y{i});
   
    media=mean(velocidad);
    desviacion=std(velocidad);
    Vmax=max(velocidad);
    Vmin=min(velocidad);
    fprintf('Estadisticas de la velocidad en la ruta %s del %s\n', y{i}, z{j})
    fprintf('La velocidad media es %.2f\n', media)
    fprintf('La desviacion estandar es %.2f\n', desviacion)
    fprintf('La velocidad minima es  %.2f y la maxima %.2f\n\n', Vmin,Vmax)
       
   end
end
 saveas (gcf,'route-elevations.png');
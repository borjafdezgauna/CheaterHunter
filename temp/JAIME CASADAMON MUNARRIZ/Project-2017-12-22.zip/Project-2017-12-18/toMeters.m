function [ m ] = toMeters( km )%Prepared to change from kilometers to meters
m=km*1000
end
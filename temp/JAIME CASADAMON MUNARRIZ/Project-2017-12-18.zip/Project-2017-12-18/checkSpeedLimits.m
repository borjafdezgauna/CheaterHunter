%checkSpeedLimits

function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =
checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)







end
function [ msSpeed ] = toMetersPerSecond( speedKmH )%Prepared to change from kilometers per hour to meters per second
msSpeed=speedKmH/3.6
end
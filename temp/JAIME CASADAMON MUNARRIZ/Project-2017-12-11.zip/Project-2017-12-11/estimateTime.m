function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
lastkm=length(kms);
newkm=linspace(kms(1),kms(lastkm),numSlices);
lastspeed=length(speedKmH);
newspeed=linspace(speedKmH(1),speedKmH(lastspeed),numSlices);
interpolateLinearly(newkm,newspeed,numSlices);
end
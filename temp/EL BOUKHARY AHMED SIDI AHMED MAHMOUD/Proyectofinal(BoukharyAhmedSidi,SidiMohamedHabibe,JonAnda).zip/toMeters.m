function y = toMeters(x)
    %Pasamos km a m
    y = x*1000;
end
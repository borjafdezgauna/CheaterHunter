function y = toMetersPerSecond(x);
    %Pasamos km/h a m/s
    y = (x*1000/3600);
end

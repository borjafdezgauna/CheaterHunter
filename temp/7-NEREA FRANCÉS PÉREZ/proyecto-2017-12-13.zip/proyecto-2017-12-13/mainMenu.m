clc
fprintf('####### MENU ########:\n')
fprintf('1. Muestra las graficas y estadisticas de las rutas\n')
fprintf('2. Muestra las graficas y estadisticas de los conductores\n')
fprintf('3. Calculos de tiempo para cada conductor y ruta\n')
fprintf('4. Comprobar los limites de velocidad\n')
fprintf('5. Calculo de consumo de combustible para cada conductor y ruta\n')
fprintf('6. Salir\n')
while opcionelegida=input('Elige una opcion: ')<6

  
if opcionelegida== 1 || opcionelegida==2 || opcionelegida==3 || opcionelegida==4 || opcionelegida==5 ||opcionelegida== 6 
        if opcionelegida== 1 
             Tarea1
  
        elseif opcionelegida== 2
            Tarea2
      
        elseif opcionelegida== 3
           disp('Esta en proceso')
    
        elseif opcionelegida==4
           disp('Esta en proceso');
    
       elseif opcionelegida== 5
           disp('Esta en proceso');
    
    
       elseif opcionelegida== 6
         clear
      else
          disp('Opcion incorrecta: debe ser un numero entre 1 y 6')
       end
  end       
  end
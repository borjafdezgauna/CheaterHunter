function [ msSpeed ] = toMetersPerSecond3( speedKmH ) 
  msSpeed=((speedKmH*1000)/3600);
 end
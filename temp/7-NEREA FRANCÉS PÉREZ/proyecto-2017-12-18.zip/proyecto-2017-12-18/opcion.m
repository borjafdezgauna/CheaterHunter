 opcionelegida=input('Elige una opcion: '); 
 
 if opcionelegida== 1 || opcionelegida==2 || opcionelegida==3 || opcionelegida==4 || opcionelegida==5 ||opcionelegida== 6 
    elseif opcionelegida== 1 
      Tarea1
      saveas (route-elevations.png,Tarea1.m)
  
      
else
    disp('Opci�n incorrecta: debe ser un n�mero entre 1 y 6')
  end
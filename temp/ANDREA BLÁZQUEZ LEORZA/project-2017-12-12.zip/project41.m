function [result] = zeit(x,y)
t1 = 0;
    for i=1:length(x)-1
        myX= x(i+1)-x(i);
        myY= y(i+1);
        t = (myX/myY);
        t1 = t1 + t;
    end
     result =t1;
end 
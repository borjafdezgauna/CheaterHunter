%4.1.
function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
xVector1=dlmread('a1-driver1-log.csv',',');
xV1=xVector1(:,1);
yVector1=dlmread('a1-driver1-log.csv',',');
yV1=yVector1(:,2);
interpolatedY (xV1,yV1);
end











%4.4
function [ hms ] = toHMS( seconds )
Horas = fix(seconds/3600) ;
Min = fix(rem/60) ;
hms = fprintf('%d:%d:%d' ,Horas,Min,seconds ) ;
end

%TASK4.3%

function [msSpeed] = toMetersPerSecond(speedKmH)
msSpeed= v*0.2778;
end 
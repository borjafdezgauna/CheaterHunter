clc
options = menu ('#######  MENU  ########:','Show route plots/statistics','Show driver plots/statistics','Time calculations for each driver/route','Check speed limits','Fuel consumption calculations for each driver/route','Exit');
input('Choose an ption');
switch options 
  case 1
    disp('project1')
     disp('Press any key to continue')
  case 2
    disp('project1.2')
    disp('Press any key to continue')
  case 3
    disp('Time calculations for each driver/route')
    disp('Press any key to continue')
  case 4
    disp('Check speed limits')
    disp('Press any key to continue')
  case 5
    disp('Fuel consumption calculations for each driver/route')
    disp('Press any key to continue')
  case 6
    disp('Exit')
    disp('Press any key to continue')
  otherwise
    disp('Incorrect option: it must be between 1 and 6')
end 
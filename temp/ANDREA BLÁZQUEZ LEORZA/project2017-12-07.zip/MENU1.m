clc
clear 
 disp ('####### MENU ########');
 disp('1.Show route plots/statistics');
 disp('2.Show driver plots/statistics');
 disp('3.Time calculations for each friver/route');
 disp('4.Check speed limits');
 disp('5.Fuel consumption calculations for each driver/route');
 disp('6.Exit');
 input('Choose an option');
 for i = 1:6 ;
  if i == 1;
    disp('Show route plots/statistics');
    end 
  if i == 2;
    disp('Show driver plots/statistics');
    end
  if i == 3;
    disp('Time calculations for each driver/route');
    end
  if i == 4;
    disp('Check speed limits');
    end
  if i == 5;
    disp('Fuel consumption calculations for each driver/route');
   end 
  if i == 6;
    disp('Exit');
   end 
  if i> 6;
    disp('Incorrect Option: it must be between 1 and 6');
  end
  end

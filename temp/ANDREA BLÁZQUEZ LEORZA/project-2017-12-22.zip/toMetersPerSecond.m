%TASK4.3%
filedriver1n1= dlmread('n1-driver1-log.csv',',');
v1n1=  filedriver1n1(:,2);
function [msSpeed] = toMetersPerSecond(speedKmH)
msSpeed = v*0.2778;
end 

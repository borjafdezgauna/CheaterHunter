function [ hms ] = toHMS( seconds )
hours= floor(seconds/3600);
seconds= seconds-hours*3600;
minutes= floor(seconds/60);
secs = seconds - minutes*60;
hms= sprintf('%02d:%02d:%02.0f\n',hours, minutes, secs)
end

clc
options = menu ('#######  MENU  ########:','Show route plots/statistics','Show driver plots/statistics','Time calculations for each driver/route','Check speed limits','Fuel consumption calculations for each driver/route','Exit');
switch options 
  case 1
    run('project1.m')
     disp('menu')
  case 2
    run('project1.2.m')
   disp('menu')
   case 3
    run('toHMS.m')
    disp('menu')
  case 4
    disp('Check speed limits')
    disp('menu')
  case 5
    disp('Fuel consumption calculations for each driver/route')
    disp('menu')
  case 6
    disp('Exit')
    disp('menu')
  otherwise
    disp('Incorrect option: it must be between 1 and 6')
    disp('Press any other key to continue')
end 
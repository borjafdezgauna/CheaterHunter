
function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices) 
myX = linspace (kms(1),kms(end), numSlices);
Ttotal = 0;
Y =[];
for i = 2:length(myX)
 myY(i-1) = interpolateLinearly(kms, speedKmH, myX(i-1));
 y1 = myY(i-1);
 x2 = myX(i);
 x1 = myX(i-1);
 t = (x2-x1)/y1;
 Ttotal = Ttotal+t;
end 
estimatedTime = (Ttotal +t)*3600;
end 
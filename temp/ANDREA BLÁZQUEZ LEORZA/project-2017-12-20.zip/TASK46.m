seconds =estimateTime( x1n1, v1n1, 1000 );
finalTime = toHMS(seconds);
seconds =estimateTime( x2n1, v2n1, 1000 );
finalTime = toHMS(seconds);
seconds =estimateTime( x1a1, v1a1, 1000 );
finalTime = toHMS(seconds);
seconds =estimateTime( x2a1, v2a1, 1000 );
finalTime = toHMS(seconds);



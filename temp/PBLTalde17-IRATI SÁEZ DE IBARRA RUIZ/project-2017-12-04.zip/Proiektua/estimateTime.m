function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
  %This function is given a vector with a vehicle�s speed (speedKmH) at
%different points (kms) and the number of integration slices we want to
%use (numSlices)
interpolatedV=[];
for tartea=linspace(kms(2),kms(end),numSlices)
  V=interpolateLinearly(kms,speedKmH,tartea);
  interpolatedV=[interpolatedV V];
end
diferentzia=[diff(kms(:,1))' 0];
denbora= diferentzia./interpolatedV;
time=sum(denbora);
estimatedTime=time*3600;
end


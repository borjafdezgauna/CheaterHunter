function [kmsAboveSpeedLimit,percentAboveSpeedLimit] = checkSpeedLimits(driverLogKm,driverLogSpeed,limitKms,limitSpeeds,numSlices)
for tartea=linspace(driverLogKm(1),driverLogKm(end),numSlices)
abiaduralimitea=interpolateToTheLeft(limitKms,limitSpeeds,tartea);
end
b=driverLogSpeed>abiaduralimitea;
kmsAboveSpeedLimit=sum(b)*(driverLogKm(end)/numSlices);
percentAboveSpeedLimit=(kmsAboveSpeedLimit/driverLogKm(end))*100;
end

    
 
    
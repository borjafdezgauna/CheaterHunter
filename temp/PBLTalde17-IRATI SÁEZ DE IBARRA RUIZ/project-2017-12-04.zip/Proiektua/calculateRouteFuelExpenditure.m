function [fuelExpenditure] =calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices)
  
  
end
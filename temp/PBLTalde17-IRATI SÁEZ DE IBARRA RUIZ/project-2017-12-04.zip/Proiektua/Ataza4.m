clear
clc
close
for ibilbidea={'n1','a1'};
  for gidaria={'driver1','driver2'};
    fitxategia=sprintf('%s-%s-log.csv',ibilbidea{1},gidaria{1});
    log=dlmread(fitxategia,',');
    denbora=estimateTime(log(:,1),log(:,2),length(log));
    hms=toHMS(denbora);
    fprintf('%s-(r)en denbora estimazioa %s ibilbidean: %d:%d:%02d\n',gidaria{1},ibilbidea{1},hms(1),hms(2),hms(3));
  end
end  
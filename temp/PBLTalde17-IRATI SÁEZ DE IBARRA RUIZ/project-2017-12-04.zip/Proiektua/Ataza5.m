clear
clc
close
for ibilbidea={'n1','a1'};
  for gidaria={'driver1','driver2'};
    fitxategia=sprintf('%s-%s-log.csv',ibilbidea{1},gidaria{1});
    abiadurafitxategia=sprintf('%s-speed-limit.csv',ibilbidea{1});
    log=dlmread(fitxategia,',',1,0);
    abiaduralimitea=dlmread(abiadurafitxategia,';');
    [kmsAboveSpeedLimit,percentAboveSpeedLimit] =checkSpeedLimits(log(:,1),log(:,2),abiaduralimitea(:,1),abiaduralimitea(:,2),length(log));
    if percentAboveSpeedLimit==0
    fprintf('Analyzing: Driver=%s, Route=%s\n No risk of infraction\n',gidaria{1},ibilbidea{1});
    elseif percentAboveSpeedLimit>0 && percentAboveSpeedLimit<10
    fprintf('Analyzing: Driver=%s, Route=%s\n Mild infraction risk: Kms above the speed limit= %d (%%%.2d of the route)\n',gidaria{1},ibilbidea{1},kmsAboveSpeedLimit,percentAboveSpeedLimit);
    elseif percentAboveSpeedLimit>=10
    fprintf('Analyzing: Driver=%s, Route=%s\n HIGH INFRACTION RISK: Kms above the speed limit= %d (%%%.2d of the route)\n',gidaria{1},ibilbidea{1},kmsAboveSpeedLimit,percentAboveSpeedLimit);
    end
  end
end
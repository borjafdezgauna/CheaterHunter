function [ m ] = toMeters( km )
  %Funtzio honek distantzia km-tan jasotzen du eta m-tan itzultzen du.
  m=km*1000;
  end
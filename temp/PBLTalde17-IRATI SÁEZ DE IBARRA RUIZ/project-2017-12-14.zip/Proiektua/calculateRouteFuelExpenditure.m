function [fuelExpenditure] =calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices)
%Funtzio honek
 distantzia=(routeKms*1000);
 interpolatedV=[];
 Altuera=[];
 for tartea=linspace(logKms(1),logKms(end),numSlices)
   V=interpolateLinearly(logKms,logSpeeds,tartea);
   interpolatedV=[interpolatedV;V];
   Y=interpolateLinearly(distantzia,routeHeights,tartea);
   Altuera=[Altuera,Y];
 end
 malda=diff(Altuera)./(distantzia(end)/numSlices);
 alpha=[0,atan(malda)];
 interpolatedV=interpolatedV/3.6;
 a=[0;diff(interpolatedV)];
 fuel=calculateFuelExpenditure(interpolatedV,a,alpha',(distantzia(end)/numSlices));
 fuelExpenditure=sum(fuel);
end

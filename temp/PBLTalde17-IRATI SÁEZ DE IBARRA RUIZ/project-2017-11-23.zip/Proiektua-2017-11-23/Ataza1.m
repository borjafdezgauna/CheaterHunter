clear
clc
n1_fitxategia=dlmread('n1-height.csv',',',1,0);
a1_fitxategia=dlmread('a1-height.csv',',',1,0);
subplot(1,2,1);
plot(a1_fitxategia(:,4),a1_fitxategia(:,3),'b',n1_fitxategia(:,4),n1_fitxategia(:,3),'r');
title('');
xlabel('Distantzia(Km)');
ylabel('Altuera(m)');
subplot(1,2,2);
plot(a1_fitxategia(:,1),a1_fitxategia(:,2),'b',n1_fitxategia(:,1),n1_fitxategia(:,2),'r');
xlabel('Latitudea');
ylabel('Longitudea');

a1_minimo
a=min(a1_fitxategia(:,3));
a1_maximoa=max(a1_fitxategia(:,3));
a1_tamaina=size(a1_fitxategia(:,3));
a1_altuerabatezbestekoa= sum(a1_fitxategia(:,3))/a1_tamaina(:,1);

n1_minimoa=min(n1_fitxategia(:,3));
n1_maximoa=max(n1_fitxategia(:,3));
n1_tamaina=size(n1_fitxategia(:,3));
n1_altuerabatezbestekoa= sum(n1_fitxategia(:,3))/n1_tamaina(:,1);
fprintf('n1 ibilbidearen estadistikak:\n Batez-besteko altuera: %d.2\n Altuera tartea: [%d.2 , %d.2]\n','n1_altuerabatezbestekoa','n1_maximoa','n1_minimoa');





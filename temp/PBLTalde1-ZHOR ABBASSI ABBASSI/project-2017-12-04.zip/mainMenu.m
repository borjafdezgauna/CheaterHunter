# Created by Octave 4.2.1, Mon Dec 04 13:39:26 2017 GMT <unknown@unknown>
# name: ans
# type: sq_string
# elements: 1
# length: 231
####### MENU ########:
1. Show route plots/statistics
2. Show driver plots/statistics
3. Time calculations for each driver/route
4. Check speed limits
5. Fuel consumption calculations for each driver/route
6. Exit
Choose an option:



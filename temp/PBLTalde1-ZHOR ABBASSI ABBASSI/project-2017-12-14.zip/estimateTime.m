% 4. ATAZA:
% Scrit honek gifdari bakoitzak egin duen bidea burutzeko behar izan duen
% denbora aztertzen du:

%4 partea: funtzio honek bide bakoitzean emandako denbora kalkulatzen du.

function [estimateTime] = estimatedTime(kms, speedKmH, numSlices)
  Slicetamainua= kms(end)/numSlices
  zeinKmden= linspace(0,kms(end),numSlices)
  time= 
  
  
  
  
  




% 4. ATAZA:
% Scrit honek gifdari bakoitzak egin duen bidea burutzeko behar izan duen
% denbora aztertzen du:

%1 partea:  This function gets a vector with x-values and a vector with y-values
%and returns the interpolated value of y for the given x.

function [interpolatedY] = interpolateLinearly(xVector, yVector, x)
i=1;
while xVector(i) <= x
    i= i + 2;
end
y2 = yVector(i);
y1 = yVector(i - 2);
x2 = xVector(i);
x1 = xVector(i - 2);
malda = (y2-y1)/(x2-x1);
interpolatedY = y1 + malda*(x - x1);

end




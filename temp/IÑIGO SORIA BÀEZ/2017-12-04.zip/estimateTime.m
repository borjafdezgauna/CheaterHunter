function [ estimatedTime ] = estimateTime( kms,speedKmH,numSlices)
estimatedTime=0
 
  
[ msSpeed ] = toMetersPerSecond( speedKmH )
[ m ] = toMeters( kms) 
 x=linspace(0,2,numSlices)

% x=[0 1 2 3]
for i=1:length(x)
     interpolatedY  = interpolateLinearly( m, msSpeed , x)
     estimatedTime =estimatedTime+(m./interpolatedY)
    
end
end
    
    
    
    
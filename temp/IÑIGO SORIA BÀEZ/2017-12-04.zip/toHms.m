function [hms]=toHms(seconds)
horas=floor(seconds/3600);
minutos=floor(seconds/60);
segundos=floor(mod(seconds,60));
hms=fprintf('%.2d:%.2d:%2d',horas,minutos,segundos);
end
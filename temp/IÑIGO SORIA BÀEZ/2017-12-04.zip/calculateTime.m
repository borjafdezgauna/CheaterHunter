function [ estimatedTime ] = calculateTime( kms,speedKmH)
[ msSpeed ] = toMetersPerSecond( speedKmH )
[ m ] = toMeters( kms) 

x=[1 2]
estimatedTime=0
for i=1:length(x)
[estimatedTime] =[estimatedTime]+(m/msSpeed)
end
end
 
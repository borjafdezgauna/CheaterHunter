xVector=[10 20 40]
yVector=[120 150 130]
x=input('introduce numero ')
[ interpolatedY ] = interpolateLinearly( xVector, yVector , x)

% CREAR MENU
clc

opcion=input('introduce opci�n: ')
while x~=6
    sprintf('####### MEN� ########: n\ 1. Muestra las gr�ficas y estad�sticas de las rutas n\ 2. Muestra las gr�ficas y estad�sticas de los conductores n\ 3. C�lculos de tiempo para cada conductor y ruta n\ 4. Comprobar los l�mites de velocidad n\ 5. C�lculo de consumo de combustible para cada conductor y ruta n\ 6. Salir')

if opcion == 1
    a=dlmread(pruebaEstadisticas1.m)
end
end
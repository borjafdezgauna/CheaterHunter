clc
clear all
%recogida de datos de dos archivos y guardarlos en variables
nombreFichero={'a1-height.csv','n1-height.csv'};
ruta={'A1','N1'};

for i=1:length(nombreFichero)
    

    file=nombreFichero{i};
    datos=dlmread(file,',',1,0);
    
    %leer datos a1,n1
    distancia=datos(:,4);
    
    altura=datos(:,3);
    
    
    longitud=datos(:,2);
    
    latitud=datos(:,1);

    %plotear altura vs distancia
%     figure('visible','off')
    
    b=subplot(1,2,1);
    plot(distancia,altura)
    hold(b,'on')
    plot(distancia,altura)
    xlabel('distancia(Km)')
    ylabel('altura(m)')
    title('elevaci�n A1 y N1')
    
    %plotear latitud vs longitud
    %A1 COLOR AZUL,N1 COLOR ROJO
    
    a=subplot(1,2,2);
    plot(longitud,latitud)
    hold(a,'on')
    plot(longitud,latitud)
    xlabel('longitud')
    ylabel('latitud')
    title('ruta A1 y N1')
%     hold(a,'off')
     %     guardar plot en .png
    saveas(gcf,'route/route-elevations.png');
    
    %calculo media
    media=mean(altura);
  
    %calculo desviacion estandar
    sd=std(altura);

    %buscar valor minimo
    minimo=min(altura);
   
    %buscar valor maximo
    maximo=max(altura);

    %imprimimos datos("falta comprobar si imprime bien la salida de textos")
%     fprintf('Estadistica de las rutas %s:\n ', ruta{j})
   fprintf('Estadistica de las rutas %s:\n Altura media: %.2f (sd: %.2f)\n Rango de alturas: [%.2f, %.2f]\n\n ',ruta{i},media,sd,minimo,maximo)
  
  
end

 
   

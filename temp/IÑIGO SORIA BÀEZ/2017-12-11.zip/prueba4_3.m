speedKmH=120
[ msSpeed ] = toMetersPerSecond( speedKmH )
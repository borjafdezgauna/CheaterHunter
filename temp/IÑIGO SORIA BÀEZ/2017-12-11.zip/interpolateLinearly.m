% crear funcion interpolatedY
function [ interpolatedY ] = interpolateLinearly(xVector,yVector,x)
% inicializamos posicion inicial en xVector
 i=1
% buscamos posion superior a x
while xVector(i)<=x && i<length(xVector)
    i=i+1;
end
% seleccionamos valor superior e inferior a x
x_1=xVector(i);
y_1=yVector(i);
x_0=xVector(i-1);
y_0=yVector(i-1);
% interpolacion
interpolatedY=y_0+((y_1-y_0)/(x_1-x_0))*(x-x_0);
end
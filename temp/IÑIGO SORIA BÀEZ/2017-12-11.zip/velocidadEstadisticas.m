
%recojida de datos de dos archivos y guardarlos en variables
lectura_datos={'a1-driver1-log.csv','a1-driver2-log.csv','n1-driver1-log.csv','n1-driver2-log.csv'}
ruta={'A1','A1','N1','N1'}
conductor=[1,2,1,2]
for i=1:length(lectura_datos)
    %leer datos a1,n1
    archivo=lectura_datos{i};
    datos=dlmread(archivo,',',0,0);
    
    distancia=datos(:,1);
    velocidad=datos(:,2);
    
    %plotear distancia vs velocidad
    
    b=subplot(1,2,1);
    plot(distancia,velocidad)
    hold(b,'on')
    plot(distancia,velocidad)
    xlabel('DISTANCIA(Km)')
    ylabel('VELOCIDAD(Km/h)')
    title('RUTA A1')
    %plotear distancia 2 vs velocidad 2
    %A1 COLOR AZUL,N1 COLOR ROJO falta leyendas
    a=subplot(1,2,2);
    plot(distancia,velocidad)
    hold(a,'on')
    plot(distancia,velocidad)
    xlabel('DISTANCIA(Km)')
    ylabel('VELOCIDAD(Km/h)')
    title('RUTA N1')
     % guardar imagen
    saveas(gcf,'route/route-speed.png');
    
    %calculo media
    media=mean(velocidad);
    
    %calculo desviacion estandar
    sd=std(velocidad);
    
    %buscar valor minimo
    minimo=min(velocidad);
    
    %buscar valor maximo
    maximo=max(velocidad);
    
    %imprimimos datos("falta comprobar si imprime bien la salida de textos")
    fprintf('\n\n Estadistica del conductor %2d en la ruta %2s:\n Velocidad media: %.2f (sd: %.2f)\n Rango de velocidades: [%.2f, %.2f]',conductor(i),ruta{i},media,sd,minimo,maximo)    
end
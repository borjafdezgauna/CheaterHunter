% script tarea 4
% leemos archivos con datos
lectura_datos={'a1-driver1-log.csv','a1-driver2-log.csv','n1-driver1-log.csv','n1-driver2-log.csv'};
ruta={'A1','A1','N1','N1'};
conductor=[1,2,1,2];
numSlices=1000;
% falta crear un vector con estimatedTime
estimateTimes=[0 estimatedTime]
for i=1:length(lectura_datos)
    
    archivo=lectura_datos{i};
    datos=dlmread(archivo,',',0,0);
    
    kms=datos(:,1);
    speedKmH=datos(:,2); 
    [ estimatedTime ] = estimateTime( kms,speedKmH,numSlices);
    [hms]=toHms(estimateTimes);
     fprintf('\n\n Estimated time for driver%d in route %2d: %2s \n',conductor(i),ruta{i},hms)
end
function [ estimatedTime ] = estimateTime( kms,speedKmH,numSlices)
estimatedTime =0;
[ msSpeed ]   = toMetersPerSecond(speedKmH);
[ m ]         = toMeters(kms) ;
delta_x       = (m(length(m))/(numSlices));
x             = linspace(1,m(length(m)),numSlices);

for i=1:length(x)
  i
  x(i)
  [interpolatedY]  = interpolateLinearly(m,msSpeed,x(i))
  estimatedTime =estimatedTime+(delta_x/interpolatedY)
end

end
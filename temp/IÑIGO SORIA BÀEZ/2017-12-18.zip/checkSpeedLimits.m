function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
for i:length(datos_entrada)
    for j:length(datos_entrada_dos)
    archivo_1=lectura_datos{i};
    archivo_2=lectura_datos{j};
    datos_1=dlmread(archivo_1,',',0,0);
    datos_2=dlmread(archivo_2,',',0,0);
    distancia_1=datos(:,1);
    velocidad_1=datos(:,2);
%       pendiente por desarrollo de if pa no repetir.
    
        
        
    
        
        
    end
end
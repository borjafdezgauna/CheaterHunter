%estimaci�n del tiempo que tarda en recorrer
function [ estimatedTime ] = estimateTime( kms,speedKmH,numSlices)
% inicializaci�n de estimatedTime
estimatedTime =0;
%conversi�n a m/s
[ msSpeed ]   = toMetersPerSecond(speedKmH);
%conversi�n a m
[ m ]         = toMeters(kms);
%crear un delta
delta_x       = (m(length(m))/(numSlices));
%crear intervalo de mi eje x
x             = linspace(m(1),m(length(m)),numSlices);
% recorrer el intervalo
for j=1:length(x)
    j;
    x(j);
    [interpolatedY]  = interpolateLinearly(m,msSpeed,x(j));
    if interpolatedY ~= 0
        estimatedTime =estimatedTime+(delta_x/interpolatedY);
    end
end

end
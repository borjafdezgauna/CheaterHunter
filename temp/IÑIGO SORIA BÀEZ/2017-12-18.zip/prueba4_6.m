seconds=234.4;
[hms]=toHms(seconds);

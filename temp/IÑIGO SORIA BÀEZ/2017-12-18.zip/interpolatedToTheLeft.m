% calcular limite de velocidad constante en un intervalo
function [interpolatedY]=interpolatedToTheLeft(xVector,yVector,x)
i=1
while (i)<=length(xVector) && xVector(i)<=x
    interpolatedY=yVector(i)
    i=i+1
end
end
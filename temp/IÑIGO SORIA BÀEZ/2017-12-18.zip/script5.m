% prueba script 5
kms=[0 10 40];
speedLimit=[90 120 90];
x=input('introduce numero ')

[interpolatedY]=interpolatedToTheLeft(kms,speedLimit,x)
% transformar cantidad de segundos en horas,minutos y segundos
function [hms]=toHms(seconds);
segundos=fix(mod(seconds,60));
minutos=fix(mod(seconds/60,60));
horas=fix(seconds/3600);
hms=sprintf('%02.f:%02.f:%02.f',horas,minutos,segundos);
end
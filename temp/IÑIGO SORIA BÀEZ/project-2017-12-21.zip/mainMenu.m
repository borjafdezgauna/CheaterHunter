% CREAR MENU
while true
 %Aparici�n de menu en pantalla
clc
fprintf(' #######  MENU  #######: \n' )
fprintf('1.Muestra las gr�ficas y estad�sticas de las rutas \n')
fprintf('2.Muestra las gr�ficas y estad�sticas de los conductores \n')
fprintf('3.C�lculos de tiempo para cada conductor y ruta \n')
fprintf('4.Comprobar los l�mites de velocidad \n')
fprintf('5.C�lculo de consumo de combustible para cada conductor y ruta \n')
fprintf('6.Salir \n')
% Elecci�n de entrada deseada
numeroEntrada=input('Elige una opcion: ');
% Sucesos posibles dependiendo de entrada elegida entre 1 y 6
switch numeroEntrada
  case 1
   graficaRuta 
  case 2
    velocidadEstadisticas
  case 3
    timeRutaConductor
  case 4
   script5_3 
  case 5
    script6_3
  case 6
    break;
  otherwise
   disp('Opci�n incorrecta: Debe ser un numero entre 1 y 6') 
end
%pulsar tecla despu�s de usar una de las opciones para poder continuar
teclaEspera=input('pulse una tecla para continuar');
end


%funci�n para estudiar que puntos de la ruta del conductor sobrepasan l�mite de velocidad
function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
%inicializar variables
kmsAboveSpeedLimit=0;
percentAboveSpeedLimit=0;
deltakms  = (driverLogKm(length(driverLogKm))/(numSlices));
%creaci�n de vectores cadena vacia
vectorKm=[];
vectorY1=[];
vectorY2=[];
vectorkmsH=[];
%creaci�n de un vector de poscionamiento con n numSlices
vectorX=linspace(driverLogKm(1),driverLogKm(length(driverLogKm)),numSlices);
%recorro dicha longitud
   for i=1:length(vectorX)
  %interpolar los valores linealmente de driverLog
    [ interpolatedY1 ] = interpolateLinearly(driverLogKm,driverLogSpeed,vectorX(i));
    %crear un vector con los valores que devuelve el interpolatedY1
    vectorY1=[vectorY1 interpolatedY1];
    %interpoar los valores de limitSpeed
    [interpolatedY2]=interpolatedToTheLeft(limitKms,limitSpeeds,vectorX(i));
    %crear un vector con los valores obtenidos de interpolatedY2
    vectorY2=[vectorY2 interpolatedY2];
    %en caso de que se aprecie que alguna velocidad de interpolatedY1 supere a la limite buscaremos dicho punto km que le corresponde
     if vectorY1(i)>vectorY2(i) 
   %creamos vector con los valor que corresponden a las velocidades sobrepasadas
        vectorkmsH= [vectorkmsH vectorY1(i)];
    % nos da km recorridos 
         vectorKm=[vectorKm vectorX(i)];
     end 
   end
   %devolvemos total de kms en los que ha escedido el limite de velocidad
     kmsAboveSpeedLimit=length(vectorKm)*deltakms;
     %calculo de porcentaje infracci�n
     percentAboveSpeedLimit=((kmsAboveSpeedLimit/deltakms)/100);
end
    
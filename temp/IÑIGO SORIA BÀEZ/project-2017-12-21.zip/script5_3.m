clc;
clear all;
%recogida de datos de dos archivos y guardarlos en variables
lectura_datosUno={'n1-driver1-log.csv','n1-driver2-log.csv','a1-driver1-log.csv','a1-driver2-log.csv'};
lectura_datosDos={'n1-speed-limit.csv','n1-speed-limit.csv','a1-speed-limit.csv','a1-speed-limit.csv'};
ruta={'N1','N1','A1','A1'};
conductor=[1,2,1,2];
numSlices=10000;
%recorrido de lectura_datosUno para escoger las diferentes carpetas de datos de cada conductor en las dos diferentes vias
for i=1:length(lectura_datosUno)
    
    %extraer datos de lectura_datosDos
    archivoDos=lectura_datosDos{i};
    datosDos=dlmread(archivoDos,';',0,0);  
    %agrupar en cada variable la columna de datos que deseamos
    limitKms=datosDos(:,1);
    limitSpeeds=datosDos(:,2);

        %extraer datos de lectura_datosUno
        archivoUno=lectura_datosUno{i};
        datosUno=dlmread(archivoUno,',',0,0);

        %agrupar en cada variable la columna de datos que deseamos
        driverLogKm=datosUno(:,1);
        driverLogSpeed=datosUno(:,2);
        %Llamada a la funci�n
         [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices);
      %escoger tipo de salida deseada de impresi�n por pantalla
      if percentAboveSpeedLimit>10
             fprintf('Analyzing: driver=driver%d, Route=%s \n HIGH INFRACTION RISK: Kms abover the speed limit=%.2f (%.2f percent of the route) \n',conductor(i),ruta{i},kmsAboveSpeedLimit,percentAboveSpeedLimit)
         elseif percentAboveSpeedLimit>0 && percentAboveSpeedLimit<=10
              fprintf('Analyzing: driver=driver%d, Route=%s \n Mild infraction risk: Kms abover the speed limit=%.2f (%.2f percent of the route) \n',conductor(i),ruta{i},kmsAboveSpeedLimit,percentAboveSpeedLimit)
         elseif percentAboveSpeedLimit==0
              fprintf('Analyzing: driver=driver%d, Route=%s \n no risk of infracion  \n',conductor(i),ruta{i})
        end    
    end


clc;
clear all;
%script 6_3.m
% archivos de entrada
archivo1={'n1-height.csv','n1-height.csv','a1-height.csv','a1-height.csv'};
archivo2={'n1-driver1-log.csv','n1-driver2-log.csv','a1-driver1-log.csv','a1-driver2-log.csv'};
ruta={'N1','N1','A1','A1'};
conductor=[1,2,1,2];
numSlices=1000;
% lectura de datos
for i=1:length(archivo2)
    lectura_archivo1=dlmread(archivo1{i},',',1,0);
    lectura_archivo2=dlmread(archivo2{i},',',0,0);
    routeKms=lectura_archivo1(:,4);
    routeHeights=lectura_archivo1(:,3);
    logKms=lectura_archivo2(:,1);
    logSpeeds=lectura_archivo2(:,2);
%     llamada funcion
    [fuelExpenditure] =calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices );
    fprintf('Analyzing: driver=driver%d, Route=%s \n Estimated fuel consumption: %.2f liters of fuel \n',conductor(i),ruta{i},fuelExpenditure)
end  

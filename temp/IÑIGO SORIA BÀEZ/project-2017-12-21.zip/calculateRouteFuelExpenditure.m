% funcion de calculo consumo de combustible en ruta completa
function [ fuelExpenditure ] =calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices )
% cambio de unidades
[ m1 ] = toMeters(routeKms);
[ m2 ] = toMeters(logKms);
[ msSpeeds ] = toMetersPerSecond( logSpeeds );
% creacion vector de posiciones
  x=linspace(m1(1),m1(length(m1)),numSlices);
%  interpolaciones
 for i=1:length(x)
 v0  = interpolateLinearly(m2,msSpeeds,x(i));
 h0 = interpolateLinearly(m1,routeHeights,x(i));
 v1  = interpolateLinearly(m2,msSpeeds,x(i)+0.01);
 h1 = interpolateLinearly(m1,routeHeights,x(i)+0.01);
%  calculo theta y aceleracion
pendiente=((h1-h0)/0.01);
theta=atan(pendiente);
a=((v1-v0)^2)/0.01;
% llamada funcion
[fuelExpenditure]=calculateFuelExpenditure(v0,a,theta,x(i));
end
end
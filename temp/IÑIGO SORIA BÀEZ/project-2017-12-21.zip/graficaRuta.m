clc;
clear all;
%recogida de datos de dos archivos y guardarlos en variables
nombreFichero={'a1-height.csv','n1-height.csv'};
ruta={'A1','N1'};
for i=1:length(nombreFichero)
    %leer datos a1,n1
    file=nombreFichero{i};
    datos=dlmread(file,',',1,0);
    distancia=datos(:,4);
    altura=datos(:,3);
    longitud=datos(:,2);
    latitud=datos(:,1);
    %plotear altura vs distancia
    b=subplot(1,2,1);
    plot(distancia,altura)
    hold(b,'on')
    xlabel('distancia(Km)')
    ylabel('altura(m)')
    title('elevaciones')
    legend(b,'elevacion A1','elevacion N1')
    %plotear latitud vs longitud 
    a=subplot(1,2,2);
    plot(longitud,latitud)
    hold(a,'on')
    xlabel('longitud')
    ylabel('latitud')
    title('rutas')
    legend(a,'ruta A1','ruta N1')
    %guardar imagen
    saveas(gcf,'route/route-elevations.png');
    %calculo media
    media=mean(altura);
    %calculo desviacion estandar
    sd=std(altura);
    %buscar valor minimo
    minimo=min(altura);
    %buscar valor maximo
    maximo=max(altura);
    %imprimimos datos
    fprintf('Estadistica de las rutas %s:\n Altura media: %.2f (sd: %.2f)\n Rango de alturas: [%.2f, %.2f]\n\n ',ruta{i},media,sd,minimo,maximo)
end
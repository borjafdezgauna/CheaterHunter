
function int = tare1(nombre_archivo)
  % leer archivo de entrada
  datos=dlmread(nombre_archivo,',',1,0);
  for i=1:length(datos_a1)
          %leer datos a1,n1
          distancia_a1=datos(:,4)
          altura_a1=datos(:,3)
          longitud_a1=datos(:,2)
          latitud_a1=datos(:,1)
          %plotear altura vs distancia
          subplot(2,2,1)
          plot (distancia_a1,altura_a1,"b")
          xlabel('DISTANCIA(Km)')
          ylabel('ALTURA(m)')
          title('ELEVACION A1')
          %plotear latitud vs longitud
          subplot(2,2,2)
          plot(longitud_a1,latitud_a1,"b")
          xlabel('LONGITUD')
          ylabel('LATITUD')
          title('RUTA A1')
  end 
  %calculo media
  mean_a1=mean(altura_a1)
  %calculo desviacion estandar
  sd_a1=std(altura_a1)
  %buscar valor minimo
  min_a1=min(altura_a1)
  %buscar valor maximo
  max_a1=max(altura_a1)
  %imprimimos datos
  fprintf('Estadistica de las rutas n1:;Altura media: %.2d (sd: %.2d);Rango de alturas: [%.2d, %.2d]',mean_n1,sd_n1,min_n1,max_n1);
end


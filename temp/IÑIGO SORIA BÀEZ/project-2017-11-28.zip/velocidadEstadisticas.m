%recojida de datos de dos archivos y guardarlos en variables
datos_a1_1=dlmread('a1-driver1-log.csv',',',0,0);
datos_a1_2=dlmread('a1-driver2-log.csv',',',0,0);
datos_n1_1=dlmread('n1-driver1-log.csv',',',0,0);
datos_n1_2=dlmread('n1-driver2-log.csv',',',0,0);

for i=1
    %leer datos a1,n1
    distancia_a1_1=datos_a1_1(:,1);
    distancia_a1_2=datos_a1_2(:,1);
    distancia_n1_1=datos_n1_1(:,1);
    distancia_n1_2=datos_n1_2(:,1);
    velocidad_a1_1=datos_a1_1(:,2);
    velocidad_a1_2=datos_a1_2(:,2);
    velocidad_n1_1=datos_n1_1(:,2);
    velocidad_n1_2=datos_n1_2(:,2);
    %plotear altura vs distancia
    figure('visible','off')
    b=subplot(2,2,1);
    plot (distancia_a1_1,velocidad_a1_1,'b',distancia_a1_2,velocidad_a1_2,'r')
    xlabel('DISTANCIA(Km)')
    ylabel('VELOCIDAD(Km/h)')
    title('RUTA A1')
    %plotear latitud vs longitud
    %A1 COLOR AZUL,N1 COLOR ROJO
    a=subplot(2,2,2);
    plot(distancia_n1_1,velocidad_n1_1,'b',distancia_n1_2,velocidad_n1_2,'r')
    xlabel('DISTANCIA(Km)')
    ylabel('VELOCIDAD(Km/h)')
    title('RUTA N1')
     %     guardar plot en .pmg
    saveas(gcf,'route/route-speed.png');
    close all;
    %calculo media
    mean_a1_1=mean(velocidad_a1_1);
    mean_a1_2=mean(velocidad_a1_2);
    mean_n1_1=mean(velocidad_n1_1);
    mean_n1_2=mean(velocidad_n1_2);
    %calculo desviacion estandar
    sd_a1_1=std(velocidad_a1_1);
    sd_a1_2=std(velocidad_a1_2);
    sd_n1_1=std(velocidad_n1_1);
    sd_n1_2=std(velocidad_n1_2);
    %buscar valor minimo
    min_a1_1=min(velocidad_a1_1);
    min_a1_2=min(velocidad_a1_2);
    min_n1_1=min(velocidad_n1_1);
    min_n1_2=min(velocidad_n1_2);
    %buscar valor maximo
    max_a1_1=max(velocidad_a1_1);
    max_a1_2=max(velocidad_a1_2);
    max_n1_1=max(velocidad_n1_1);
    max_n1_2=max(velocidad_n1_2);
    %imprimimos datos("falta comprobar si imprime bien la salida de textos")
    fprintf('Estadistica del conductor 1 en la ruta a1:\n Velocidad media: %.2f (sd: %.2f)\n Rango de velocidades: [%.2f, %.2f]',mean_a1_1,sd_a1_1,min_a1_1,max_a1_1)
    fprintf('\n\n Estadistica del conductor 2 en la ruta a1:\n Velocidad media: %.2f (sd: %.2f)\n Rango de velocidades: [%.2f, %.2f]',mean_a1_2,sd_a1_2,min_a1_2,max_a1_2)
    fprintf('\n\n Estadistica del conductor 1 en la ruta n1:\n Velocidad media: %.2f (sd: %.2f)\n Rango de velocidades: [%.2f, %.2f]',mean_n1_1,sd_n1_1,min_n1_1,max_n1_1)
    fprintf('\n\n Estadistica del conductor 2 en la ruta n1:\n Velocidad media: %.2f (sd: %.2f)\n Rango de velocidades: [%.2f, %.2f]',mean_n1_2,sd_n1_2,min_n1_2,max_n1_2)
    
  
end
a=dlmread('a1-height.csv')
disp('a')
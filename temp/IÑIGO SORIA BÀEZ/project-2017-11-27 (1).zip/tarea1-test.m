
tare1('n1-height.csv')
tare1('a1-height.csv')
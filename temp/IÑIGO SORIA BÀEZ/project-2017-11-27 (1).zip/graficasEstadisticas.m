%recojida de datos de dos archivos y guardarlos en variables
datos_a1=dlmread('a1-height.csv',',',1,0);
datos_n1=dlmread('n1-height.csv',',',1,0);

for i=1:length(datos_a1)
    %leer datos a1,n1
    distancia_a1=datos_a1(:,4);
    distancia_n1=datos_n1(:,4);
    altura_a1=datos_a1(:,3);
    altura_n1=datos_n1(:,3);
    longitud_a1=datos_a1(:,2);
    longitud_n1=datos_n1(:,2);
    latitud_a1=datos_a1(:,1);
    latitud_n1=datos_n1(:,1);
    %plotear altura vs distancia
    subplot(2,2,1)
    plot (distancia_a1,altura_a1,'b',distancia_n1,altura_n1,'r')
    xlabel('DISTANCIA(Km)')
    ylabel('ALTURA(m)')
    title('ELEVACION A1 y N1')
    %plotear latitud vs longitud
    %A1 COLOR AZUL,N1 COLOR ROJO
    a=subplot(2,2,2)
    plot(longitud_a1,latitud_a1,'b',longitud_n1,latitud_n1,'r')
    xlabel('LONGITUD')
    ylabel('LATITUD')
    title('RUTA A1 y N1')
    %calculo media
    mean_a1=mean(altura_a1);
    mean_n1=mean(altura_n1);
    %calculo desviacion estandar
    sd_a1=std(altura_a1);
    sd_n1=std(altura_n1);
    %buscar valor minimo
    min_a1=min(altura_a1);
    min_n1=min(altura_n1);
    %buscar valor maximo
    max_a1=max(altura_a1);
    max_n1=max(altura_n1);
    %imprimimos datos("falta comprobar si imprime bien la salida de textos")
    fprintf('Estadistica de las rutas n1:\n Altura media: %.2f (sd: %.2f)\n Rango de alturas: [%.2f, %.2f]',mean_n1,sd_n1,min_n1,max_n1)
    fprintf('\n\n Estadistica de las rutas a1:\n Altura media: %.2f (sd: %.2f)\n Rango de alturas: [%.2f, %.2f]',mean_a1,sd_a1,min_a1,max_a1)
    %     guardar plot en .pmg
    saveas(a,'route-elevations,'-dpng')
end


function [hms]=toHms(seconds);
segundos=fix(mod(seconds,60));
minutos=fix(mod(seconds/60,60));
horas=fix(seconds/3600);
hms=sprintf('%2.f:%2.f:%2.f',horas,minutos,segundos);
end
lectura_datos='a1-driver1-log.csv'
ruta='A1'
conductor=1
numSlices=1000;
% falta crear un vector con estimatedTime
    archivo=lectura_datos;
    datos=dlmread(archivo,',',0,0);
    
    kms=datos(:,1);
    speedKmH=datos(:,2); 
    [ estimatedTime ] = estimateTime( kms,speedKmH,numSlices)
    
    [hms]=toHms(estimatedTime);
     fprintf('\n\n Estimated time for driver%d in route %2s: %2f \n',conductor,ruta,hms)

km=2.3
[ m ] = toMeters( km )
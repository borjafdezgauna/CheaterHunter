    function [ estimatedTime ] = estimateTime( kms,speedKmH,numSlices)
    estimatedTime =0;
    [ msSpeed ]   = toMetersPerSecond(speedKmH);
    [ m ]         = toMeters(kms);
    delta_x       = (m(length(m))/(numSlices));
    x             = linspace(m(1),m(length(m)),numSlices);

    for j=1:length(x)
      j;
      x(j);
      [interpolatedY]  = interpolateLinearly(m,msSpeed,x(j));
      if interpolatedY ~= 0
            estimatedTime =estimatedTime+(delta_x/interpolatedY);
      end
    end

    end
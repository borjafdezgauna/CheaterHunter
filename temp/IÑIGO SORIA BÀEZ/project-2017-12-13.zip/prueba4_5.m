km=[1 2]
speedKmH=[10 20]


estimatedTime= calculateTime( km,speedKmH)
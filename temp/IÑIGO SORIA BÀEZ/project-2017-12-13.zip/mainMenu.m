% CREAR MENU
while true
 %menu que aparece
clc
fprintf(' #######  MENU  #######: \n' )
fprintf('1.Muestra las gr�ficas y estad�sticas de las rutas \n')
fprintf('2.Muestra las gr�ficas y estad�sticas de los conductores \n')
fprintf('3.C�lculos de tiempo para cada conductor y ruta \n')
fprintf('4.Comprobar los l�mites de velocidad \n')
fprintf('5.C�lculo de consumo de combustible para cada conductor y ruta \n')
fprintf('6.Salir \n')

numeroEntrada=input('Eligue una opcion: ');

switch numeroEntrada
  case 1
    velocidadEstadisticas
  case 2
    graficaRuta
  case 3
    timeRutaConductor
  case 4
   %realizar tarea 5 
  case 5
    %realizar tarea 6
  case 6
    break;
  otherwise
   disp('Opcion incorrecta: Debe ser un numero entre 1 y 6') 
end
%pulsar tecla despues de usar una de las opciones para poder continuar
teclaEspera=input('pulse una tecla para continuar');
teclaEspera;

end


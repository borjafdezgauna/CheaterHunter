x=1;
for errepidea={'a','n'}
  subplot(1,2,x)
  for gidaria={'driver1','driver2'}

    
    fitxategia=sprintf('%s1-%s-log.csv',errepidea{1},gidaria{1});
    Fitxategia=dlmread(fitxategia,'"');
    
    hold on
    plot(Fitxategia(:,1),Fitxategia(:,2),kolorea);
    title(sprintf('%s1 errepidea',errepidea{1}));
    xlabel('Distantzia(km)');
    ylabel('Abiadura(km/h)');
    
    
  end
  legend('Gidari1','Gidari2')
  x=x+1;
end
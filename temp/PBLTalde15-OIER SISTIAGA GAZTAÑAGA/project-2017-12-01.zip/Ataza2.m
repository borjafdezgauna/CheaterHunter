x=1;
for errepidea={'a','n'}
  subplot(1,2,x)
  for gidaria={'driver1','driver2'}

    
    fitxategia=sprintf('%s1-%s-log.csv',errepidea{1},gidaria{1});
    Fitxategia=dlmread(fitxategia,',');
    
    hold on
    plot(Fitxategia(:,1),Fitxategia(:,2));
    title(sprintf('%s1 errepidea',errepidea{1}));
    xlabel('Distantzia(km)');
    ylabel('Abiadura(km/h)');
    
    batezbestekoabiadura=mean(Fitxategia(:,2));
    desbiderazioestandarra=std(Fitxategia(:,2));
    abiaduramax=max(Fitxategia(:,2));
    abiaduramin=min(Fitxategia(:,2));
    
    fprintf('\n%s estatistikak %s1 errepidean\nBatazbesteko abiadura: %.2f Km/h (sd. %.2f)\nAbiadura Min-Max: [%.2f,%.2f]\n\n',gidaria{1},errepidea{1},batezbestekoabiadura,desbiderazioestandarra,abiaduramin,abiaduramax);
  end
  legend('Gidari1','Gidari2')
  x=x+1;
end
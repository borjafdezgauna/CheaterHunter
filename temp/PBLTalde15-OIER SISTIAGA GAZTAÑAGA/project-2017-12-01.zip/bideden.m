function [ denbora ] = bideden(distatzia,abiadura,tarteak)
abiadura=KmstoMs(abiadura);
distantzia=KmtoM(distantzia);
denbora=distantzia/abiadura;
interpolazioa()


end


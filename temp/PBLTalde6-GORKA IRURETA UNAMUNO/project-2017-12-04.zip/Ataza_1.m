for route={'n1','a1'}
filename=sprintf('%s-height.csv',route{1});  
i=dlmread(filename,',',1,0);
subplot(1,2,1);
hold on
plot(i(:,4),i(:,3));
xlabel('Distantzia(km)');
ylabel('Altuera(m)');
title('Altuera jatorriarekiko');
subplot(1,2,2);
hold on
plot(i(:,1),i(:,2));
xlabel('Latitudea(�)');
ylabel('Longitudea(�)');
title('Koordenatuak');
Batazbestekoa=mean(i(:,3));
Desbiderazioa=std(i(:,3));
Altueramaximoa=max(i(:,3));
Altueraminimoa=min(i(:,3));
fprintf('%s route statistics\nBataz bestekoa: %.2f\nAltuera maximoa: %.2f\nAltuera minimoa: %.2f\nDesbiderazioa: %.2f\n\n ',route{1},Batazbestekoa,Altueramaximoa,Altueraminimoa,Desbiderazioa);
end
subplot(1,2,1);
legend('n1','a1');
subplot(1,2,2);
legend('n1','a1');
saveas(gcf,'RouteElevation.png');
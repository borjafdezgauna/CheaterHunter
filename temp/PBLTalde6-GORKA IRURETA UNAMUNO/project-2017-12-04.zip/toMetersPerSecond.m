function [ msSpeed ] = toMetersPerSecond( speedKmH )
  msSpeed=3.6*speedKmH
  end
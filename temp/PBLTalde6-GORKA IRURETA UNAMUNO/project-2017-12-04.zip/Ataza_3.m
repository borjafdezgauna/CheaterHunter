option=1;
while option<6 && option>0
fprintf('####### MENU ########:\n1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit\n');
option=input('Choose an option: ');
if option=1
  Ataza_1
elseif option=2
  Ataza_2
elseif option=

option=input('Choose an option: ');
end
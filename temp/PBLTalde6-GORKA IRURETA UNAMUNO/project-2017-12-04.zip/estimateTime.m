function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices);
  u=zeros(1,numSlices+1);
  dx=kms(length(kms))/numSlices;
  estimatedTime=0;
  for j=1:length(u);
 u(j)=kms(1)+(j-1)*dx;
 end
for i=1:(length(u)-1);
interpolatedspeedKmH=interpolateLinearly(kms,speedKmH,u(i));
estimatedTime=(dx/interpolatedspeedKmH)+estimatedTime;
  end
  estimatedTime=3600*estimatedTime;
  end
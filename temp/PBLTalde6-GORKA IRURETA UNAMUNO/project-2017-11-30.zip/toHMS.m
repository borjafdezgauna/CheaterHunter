function [ hms ] = toHMS( seconds )
HH=fix(seconds/3600);
x=rem(seconds,3600);
MM=fix(x/60);
SS=fix(rem(x,60));
fprintf('%02d:%02d:%02d\n',HH,MM,SS);
end
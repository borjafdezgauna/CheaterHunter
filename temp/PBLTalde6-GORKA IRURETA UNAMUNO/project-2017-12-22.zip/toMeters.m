function m = toMeters(km)
  m=km*(10^3);
  end
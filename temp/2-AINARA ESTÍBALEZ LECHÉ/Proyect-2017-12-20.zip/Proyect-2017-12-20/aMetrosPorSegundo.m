function [msSpeed]=aMetrosPorSegundo(speedKmH)
%A partir de una velocidad en km/h la convertimos en m/s
msSpeed=(speedKmH*(10^3))/360
end
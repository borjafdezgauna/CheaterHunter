function [m]= aMetros(km)
%a partir de los km calculamos los m
m=km*(10^3)
end

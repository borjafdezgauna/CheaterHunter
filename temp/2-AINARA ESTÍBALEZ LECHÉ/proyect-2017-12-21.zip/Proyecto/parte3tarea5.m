%Leemos los ficheros, llamamos a la funci�n y lo imprimimos por pantalla.
%Nos sale un error en por la funci�n
for ruta={'a1','n1'}
    for opcion={'-driver1-log.csv','-driver2-log.csv','-speed-limit.csv'}
            ficheros=sprintf('%s%s%s',ruta{1},opcion{1});
            tabla=dlmread(ficheros,',');
            [ kmsAboveSpeedLimit,percentAboveSpeedLimit ]=checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices);
            fprintf('analyzing:driver=%s, route= %s\n',opcion{1},ruta{1})
            
            if percentAboveSpeedLimit>10
            fprintf('high infraction risk:kms abover the speed limit=%s ( %s of the route)\n',kmsAboveSpeedLimit,percentAboveSpeedLimit)
            elseif percentAboveSpeedLimit==0
                fprintf('no risk infraction')
            else
                fprintf('mild infraction risk:kms abover the speed limit=%s(%s of the route)\n',kmsAboveSpeedLimit,percentAboveSpeedLimit)
            end
    end
end
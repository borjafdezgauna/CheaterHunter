numSlices=input('Dime el n�mero de intervalos');
for ruta ={'a1','n1'}
    for conductor={'1','2'}
        ficheros=sprintf('%s-driver%s-log.csv',ruta{1},conductor{1});
        tabla=dlmread(ficheros,',',1,0);
        
        kms=tabla(:,1);
        speedKmH=tabla(:,2);
        %Se leen los ficheros y se recogen en una tabla de la que, por
        %columnas, sacamos los datos
       
        tEstimado=estimateTime(kms,speedKmH, numSlices);%Se llama a la funci�n de estimar el tiempo
        hms=toHMS(tEstimado);%Se llama a la funci�n para que nos cambie de segundos a horas:minutos:segundos
        
        %Se imprime por pantalla
        fprintf('Tiempo estimado para conductor %s en %s : ',conductor{1},ruta{1})
        fprintf('%s \n',hms)
    end
end

function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
    for x =linspace(driverLogKm(1), driverLogKm(end),numSlices)
        for y=linspace (driverLogSpeed(1),driverLogSpeed(end),numSlices)%Creamos un vector cogiendo los datos para la x
            v1=interpolateLinearly(driverLogKm,driverLogSpeed,numSlices);%Calculamos la velocidad 
            v2=interpolateToTheLeft(limitKms,limitSpeeds,numSlices);%Calculamos el l�mite de la velocidad en el tramo
             if v1>v2 
                 e=(v1(length(v1))-v1(1))/numSlices;
                 kmsAboveSpeedLimit =kmsAboveSpeedLimit+e;
             end
        end
    end    
end


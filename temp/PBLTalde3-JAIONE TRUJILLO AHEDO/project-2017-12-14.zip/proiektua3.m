i= input('sartu zenbaki bat')
For i = 1:6
  if i = 1 then
    A=dlmread('proiektua11.m')
    B=dlmread('proiektua12.m')
    disp(A)
    disp(B)
    
    
  end if
  if i = 2 then
    A=dlmread('proiektua21.m')
    B=dlmread('proiektua22.m')
    disp(A)
    disp(B)
    
    
  end if
  if i=3 then
  
  
  
  
  end if
  if i=4 then 
  
  
  
  endif
  if i=5 then
    
    
    
  endif
  if i = 6 then
  
  
  
  endif
  disp('sakatu edozein tekla jarraitzeko')
  pause()
  clc()
  home()
end

While i<1 & i>6 
disp('Aukera egokia: 1 eta 6 artean egon behar da')
end
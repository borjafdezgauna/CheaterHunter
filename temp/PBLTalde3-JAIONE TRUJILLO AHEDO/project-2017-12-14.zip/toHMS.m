function [ hms ] = toHMS( seconds )
o=(seconds-rem(seconds,3600))/3600;
m=(seconds-rem(seconds,60))/60;
s=rem(seconds,60);
hms=sprintf('%d:%d:%f',o,m,s);
end
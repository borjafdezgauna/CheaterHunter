function [estimatedTime]=estimateTime(kms,speedKmH,numSlices)
    msSpeed=speedKmH*1000/3600
    m=kms*1000
    i=1;
    while m(i)<m
        i=i+1;
    x1=m(i);
    x0=m(i-1);
    y1=msSpeed(i);
    y0=msSpeed(i-1);
    Y=((y1-y0)/(x1-x0))*(x-x0)
end
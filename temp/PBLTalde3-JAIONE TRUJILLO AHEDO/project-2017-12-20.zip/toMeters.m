function [ m ] = toMeters( kms )
m=kms*1000
end
clear
clc
close
i=0;
kolorea1='b';
kolorea2='b';
for fitxategia={'n1-driver1-log.csv','n1-driver2-log.csv','a1-driver1-log.csv','a1-driver2-log.csv'};
log=dlmread(fitxategia{1},',');
if i<=1;
subplot(2,1,1);
plot(log(:,1),log(:,2),kolorea1);
hold on
title('n1 ibilbidea');
xlabel('Distantzia(Km)');
ylabel('Abiadura(Km/h)');
i=i+1;
kolorea1='r';
gidaria=i;
bidea='n1';
elseif 
subplot(2,1,2);
plot(log(:,1),log(:,2),kolorea2);
hold on
title('a1 ibilbidea');
xlabel('Distantzia(Km)');
ylabel('Abiadura(Km/h)');
gidaria=i-1;
bidea='a1';
i=i+1;
kolorea2='r';
end
minimoa=min(log(:,2));
maximoa=max(log(:,2));
desbiderazioa=std(log(:,2));
batezbestekoa=sum(log(:,2))/length(log(:,2));
fprintf('%d gidariaren datuak %s ibilbidean:\n Batez-besteko abiadura: %.2f  (sd: %.2f)\n Abiadura Min-Max: [%.2f,%.2f]\n\n',gidaria,bidea,batezbestekoa,desbiderazioa,minimoa,maximoa);
end
subplot(2,1,1);
legend('1 gidaria','2 gidaria');
subplot(2,1,2);
legend('1 gidaria','2 gidaria');

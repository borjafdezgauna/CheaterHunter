function [ msSpeed ] = toMetersPerSecond( speedKmH )
  %Funtzio honek abiadura km/h-tan jasotzen du eta m/s-tan itzultzen du.
  msSpeed= speedKmH/3.6;
  end
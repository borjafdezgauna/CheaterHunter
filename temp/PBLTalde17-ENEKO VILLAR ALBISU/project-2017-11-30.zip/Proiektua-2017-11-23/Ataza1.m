clear
clc
close
bidea='n1';
kolorea='b';
for fitxategia={'n1-height.csv','a1-height.csv'};
  altuera=dlmread(fitxategia{1},',',1,0);
  subplot(1,2,1);
  plot(altuera(:,4),altuera(:,3),kolorea);
  hold on
  title('Distantzia-Altuera grafikoa');
  xlabel('Distantzia(Km)');
  ylabel('Altuera(m)');
  subplot(1,2,2);
  plot(altuera(:,1),altuera(:,2),kolorea);
  hold on
  title('Latitude-Longitude grafikoa');
  xlabel('Latitudea');
  ylabel('Longitudea');
  minimoa=min(altuera(:,3));
  maximoa=max(altuera(:,3));
  desbiderazioa=std(altuera(:,3));
  batezbestekoa=sum(altuera(:,3))/length(altuera(:,3));
  fprintf('%s ibilbidearen datuak:\n Batez-besteko altuera: %.2f  (sd: %.2f)\n Altuera tartea: [%.2f , %.2f]\n \n',bidea,batezbestekoa,desbiderazioa,minimoa,maximoa);
  bidea='a1';
  kolorea='r';
end
subplot(1,2,1);
legend('n1','a1');
subplot(1,2,2);
legend('n1','a1');
saveas(gcf,'route-elevations','png');

function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
  %This function is given a vector with a vehicle�s speed (speedKmH) at
%different points (kms) and the number of integration slices we want to
%use (numSlices)
interp1(kms,speedKmH,
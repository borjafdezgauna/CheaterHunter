function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
  %This function gets a vector with x-values and a vector with y-values
%and returns the interpolated value of y for the given x.
if xVector(:,1)~~0;
xVector=[0 xVector];
end
if yVector(:,1)~~0;
yVector=[0 yVector];
end
a=xVector<=x;
b=sum(a);
u=(x-xVector(:,b))/(xVector(:,b+1)-xVector(:,b));
interpolatedY=((1-u)*yVector(:,b))+(yVector(:,b+1)*u);
end
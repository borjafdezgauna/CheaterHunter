function [ m ] = toMeters( km )
  %Funtzio honek distantzian km-tan jasotzen du eta m-tan itzultzen du.
  m=km*1000;
  end
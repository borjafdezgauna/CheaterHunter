function [ hms ] = toHMS( seconds )
  %Funtzio honek sartutako segunduak ordu:minutu:segundu moduan itzultzen ditu.
 mins=seconds/60;
 min=fix(mins);
 hours=min/60;
 orduak=fix(hours);
 segunduak=seconds-60*min;
 minutuak=min-60*orduak;
 hms=[orduak minutuak segunduak];
 end
 
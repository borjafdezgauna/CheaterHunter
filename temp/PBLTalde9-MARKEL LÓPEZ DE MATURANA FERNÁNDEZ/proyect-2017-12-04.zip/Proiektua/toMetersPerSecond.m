function [msSpeed]=toMetersPerSecond(speedKmH)
  msSpeed=speedKmH/3.6;
  end
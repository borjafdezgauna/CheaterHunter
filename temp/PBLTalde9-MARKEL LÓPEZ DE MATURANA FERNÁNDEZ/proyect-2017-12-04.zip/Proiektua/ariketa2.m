for gidaria={'driver1','driver2'}
   fitxategia = sprintf('a1-%s-log.csv', gidaria{1});
   
    %%Datu fitxategiak irakurri
    abiadura=dlmread(fitxategia,',');
    %%bi grafikoak sortu
    subplot(1,2,1);
    plot(abiadura(:,1),abiadura(:,2));
    title('Abiadura distantziaren funtzioan(a1)');
    xlabel('distantzia(km)');
    ylabel('abiadura(km/h)'); 
    hold on 
    fprintf('%s statistics in route a1:\nMean speed: %.02f (sd. %.02f)\nMin-Max speed: [%.02f, %.02f]\n\n',gidaria{1},mean(abiadura(:,2)),std(abiadura(:,2)),min(abiadura(:,2)),max(abiadura(:,2)));
    end
   %%bigarren subplota
   for gidaria={'driver1','driver2'}
     fitxategia = sprintf('n1-%s-log.csv', gidaria{1});
    %%Datu fitxategiak irakurri
    abiadura=dlmread(fitxategia,',');
  subplot(1,2,2);
    plot(abiadura(:,1),abiadura(:,2));
    hold on
    title('Abiadura distantziaren funtzioan(n1)');
    xlabel('distantzia(km)');
    ylabel('abiadura(km/h)');
    fprintf('%s statistics in route n1:\nMean speed: %.02f (sd. %.02f)\nMin-Max speed: [%.02f, %.02f]\n\n',gidaria{1},mean(abiadura(:,2)),std(abiadura(:,2)),min(abiadura(:,2)),max(abiadura(:,2)));
   end
input('sakatu enter jarraitzeko');
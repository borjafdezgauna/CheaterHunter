function [estimatedTime]=estimateTime(kms,speedKmH,numSlices)
  for i=1:numSlices
    x=(i-1)*numSlices
    [interpolatedDenbora]=interpolateLinearly(kms,speedKmH,x);
    estimatedTime=0;
    estimatedTime=estimatedTime+interpolatedDenbora;
    end
    end
    
    
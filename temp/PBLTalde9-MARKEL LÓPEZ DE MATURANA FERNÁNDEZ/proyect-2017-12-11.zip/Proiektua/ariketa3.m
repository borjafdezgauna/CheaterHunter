

i=0;

 while i==0
    clc
     fprintf('1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit\n');



n=input('Choose an option:');
switch n
    case 1
        ariketa1
    case 2
        ariketa2
    case 3
        ariketa4
    case 6 
        %%ariketa;
     disp('programa amaitu da');
     i=1;   
    
    otherwise
        disp('Sartutako zenbakia ez da zuzena');
        input('sakatu enter jarraitzeko');
end




 end

l1={'a','n'}
for i=1:length(l1)
 a=sprintf('%s1-height.csv',l1{i});
 v=dlmread(a,',',1,0);
 b=v(:,1);
 c=v(:,2);
 subplot(2,2,1);
 x=linspace(1,3688);
 y=linspace(1,3688);
 plot(c,b);
end





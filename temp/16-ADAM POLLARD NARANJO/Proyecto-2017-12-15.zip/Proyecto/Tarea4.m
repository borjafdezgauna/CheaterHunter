clc;
clear;
format compact;
toHMS(234.4)
toHMS(3601)
%------(KM-M)-------------------------
km=input('DAME km');%variable
m=toMeters(km);
disp(m)
%-------------KM/H-M/S----------------------
speedKmH = input('sidfhb');
msSpeed = toMetersPerSecond(speedKmH);
disp (msSpeed);
%-------------S-H----------------------
seconds = input('segundos');
hms=toHMS(seconds);
disp (hms)
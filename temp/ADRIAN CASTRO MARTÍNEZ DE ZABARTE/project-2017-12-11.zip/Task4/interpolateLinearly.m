%Task4%
%Write a function that linearly interpolates from a set of x-y values%
function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
i=1;
while xVector(i)<x
     i=i+1;
y2=yVector(i);
y1=yVector(i-1);
x2=xVector(i);
x1=xVector(i-1);
slope=(y2-y1)/(x2-x1);
interpolatedY=y1+slope*(x-x1);
end
if xVector(i)==x
    interpolatedY=yVector(i);
end
end

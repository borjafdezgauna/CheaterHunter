x=dlmread('n1-driver1-log.csv',',');
y=dlmread('n1-driver2-log.csv',',');
w=dlmread('a1-driver1-log.csv',',');
z=dlmread('a1-driver2-log.csv',',');
subplot(1,2,1);
hold on
plot(x(:,1),x(:,2));
plot(y(:,1),y(:,2)),xlabel('Distance from the origin(km)'),ylabel('Speed(km/h)'),title('National road');
subplot(1,2,2);
hold on
plot(w(:,1),w(:,2));
plot(z(:,1),z(:,2)),xlabel('Distance from the origin(km)'),ylabel('Speed(km/h)'),title('Highway');
legend('Driver 1','Driver 2')

A=(x(:,2));
meanspeed= mean(A);

A=(x(:,2));
meanspeed= mean(A);
A=(x(:,2));
meanspeed= mean(x);
A=(x(:,2));
meanspeed= mean(x);


x=dlmread('n1-driver1-log.csv',',');
y=dlmread('n1-driver2-log.csv',',');
w=dlmread('a1-driver1-log.csv',',');
z=dlmread('a1-driver2-log.csv',',');
dop=input('Type(x)for driver1 statics in n1\n Type(y)for driver2 statics in n1\n Type(w)for driver1 statics in a1\n Type(z)for driver2 statics in a1\n');
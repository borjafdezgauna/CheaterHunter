%Write a function that, given an amount of kilometers, returns the equivalent number of meters
function [m] = toMeters( km )
m=km*1000;
end

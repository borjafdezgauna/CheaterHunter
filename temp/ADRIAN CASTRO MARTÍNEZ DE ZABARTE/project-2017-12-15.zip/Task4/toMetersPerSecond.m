%Write a function that, given a speed in km/h, returns the equivalent speed
%in m/s
function [ msSpeed ] = toMetersPerSecond( speedKmH )
msSpeed=speedKmH/3.6
end
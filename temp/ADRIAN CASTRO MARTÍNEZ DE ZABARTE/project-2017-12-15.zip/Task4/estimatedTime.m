%Write a function that estimates the time taken in a route
%This function is given a vector with a vehicle�s speed (speedKmH) at
%different points (kms) and the number of integration slices we want to
%use (numSlices)
function [ estimatedTime ] = estimatedTime( kms, speedKmH, numSlices )
interpolateLinearly( xVector, yVector , x)
end




%Write a function that, given an amount of seconds, returns a string with
%the format HH:MM:SS (hours, minutes and seconds, each with 2 digits)%
%Fractions of seconds will be ignored%
function [ hms ] = toHMS( seconds )
hms=datestr(seconds/(24*60*60), 'HH:MM:SS');
end

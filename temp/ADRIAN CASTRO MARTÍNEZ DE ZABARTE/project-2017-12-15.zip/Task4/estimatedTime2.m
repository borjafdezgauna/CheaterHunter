m=dlmread('n1-driver1-log.csv',',');
y=dlmread('n1-driver2-log.csv',',');
w=dlmread('a1-driver1-log.csv',',');
z=dlmread('a1-driver2-log.csv',',');
kms=(m(:,1));
speedKmH=(m(:,2));

estimatedTime( [0 1 2 3], [40 50 40 30], 1000 )






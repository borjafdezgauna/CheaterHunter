%Write a function that calculates the fuel expenditure in a complete route
function [ fuelExpenditure ] =calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices)
routeKms=max(dop(:,1))
routeHeights=



end


for file= {'a1-height.csv','n1-height.csv'}
   data= dlmread(file{1},',',1,0);
   subplot(1,2,1)
   hold on
   plot(data(:,4),data(:,3))
   subplot(1,2,2)
   hold on
   plot(data(:,2),data(:,1))
end
input('Sakatu edozein tekla jarraitzeko: ','s');

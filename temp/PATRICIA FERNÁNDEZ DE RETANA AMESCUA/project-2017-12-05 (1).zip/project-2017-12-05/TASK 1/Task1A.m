elevationA = dlmread('a1-height.csv',',',[1 2 0 2])
distanceA = dlmread('a1-height.csv',',',[1 3 0 3])
elevationN = dlmread('n1-height.csv',',',[1 2 0 2])
distanceN = dlmread('n1-height.csv',',',[1 3 0 3])


subplot(1,2,1);
plot(distanceA,elevationA,'b',distanceN,elevationN,'g');
title('Subplot A1: elevation(m) vs distance(km)');
xlabel  ('distance(km)');
ylabel  ('elevation(m)');


LatitudeA = dlmread('a1-height.csv',',',[1 0 0 0])
LongitudeA = dlmread('a1-height.csv',',',[1 1 0 1])
LatitudeN = dlmread('n1-height.csv',',',[1 0 0 0])
LongitudeN = dlmread('n1-height.csv',',',[1 1 0 1])


subplot(1,2,2);
plot(LongitudeA,LatitudeA,'b',LongitudeN,LatitudeN,'g');
title('Subplot A2: latitude vs longitude');
xlabel  ('longitude');
ylabel ('latitude');
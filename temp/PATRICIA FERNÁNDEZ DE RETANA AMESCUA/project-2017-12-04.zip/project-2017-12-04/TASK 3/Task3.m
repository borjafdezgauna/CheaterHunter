fprintf('MENU \n 1-Show route plots/statistics \n 2-Show driver plots/statistics \n 3-Time calculations for each driver/route \n 4-Check speed limits \n 5-Fuel consumption calculations for each driver/route \n 6-Exit \n')
option=input('choose an option')
if option<=0 && option>6
    fprintf('incorrect option: it must be between 1 and 6')
else
while option>=1 && option<=6
fprintf('MENU \n 1-Show route plots/statistics \n 2-Show driver plots/statistics \n 3-Time calculations for each driver/route \n 4-Check speed limits \n 5-Fuel consumption calculations for each driver/route \n 6-Exit \n')
option=input('choose an option')
end
end
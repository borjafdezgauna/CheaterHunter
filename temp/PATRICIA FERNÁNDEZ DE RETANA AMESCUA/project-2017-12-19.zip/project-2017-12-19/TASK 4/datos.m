
numSlices = input('give me a number')

  driver1N1 = dlmread('n1-driver1-log.csv');
  speedKmH = driver1N1(:,2);
  km = driver1N1(:,1);
  numSlices = 1000;
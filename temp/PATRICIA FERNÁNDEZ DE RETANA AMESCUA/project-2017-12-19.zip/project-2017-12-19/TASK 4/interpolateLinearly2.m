
    
function interpolateY = interpolateLinearly2 (km, speedKmH,numSlices)

   m = toMeters(km);
   
   msSpeed = toMetersperSecond(speedKmH);
   
   estimatedTime = estimateTime( m, msSpeed, numSlices);
    
   hms  = toHMS(estimatedTime);
   interpolateY = sprintf('Estimated time for driver1 in route n1: %s',hms)

      
 end


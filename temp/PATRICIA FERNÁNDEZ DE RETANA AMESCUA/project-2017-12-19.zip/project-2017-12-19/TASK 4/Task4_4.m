function estimatedTime = estimateTime (kms, speedKmH,numSlices)
  
  
  totalTime=0;
  delta_d= kms(end)/numSlices;
  
   m = toMeters(kms)
   msSpeed = toMetersperSecond(speedKmH)
  
  for  i=1:numSlices
      
      km= (i-1)*delta_d;
      
      interpolateSpeed = interpolateLinearly(m, msSpeed,km);
      
        if km == 0
          
            timeSlice = 0;
            
            totalTime = 0;
            
        else 
            
            timeSlice=delta_d/interpolateSpeed;
       
            totalTime = totalTime + timeSlice;
            
        end
        
  end

     estimatedTime = totalTime;
  end
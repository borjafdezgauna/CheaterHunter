function msSpeed = toMetersperSecond(speedKmH)

    msSpeed = (speedKmH*1000)/3600

end


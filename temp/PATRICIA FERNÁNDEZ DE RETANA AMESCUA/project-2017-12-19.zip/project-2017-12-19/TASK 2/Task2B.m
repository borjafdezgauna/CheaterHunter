clc 
clear
for files1={'a1','n1'}
for files2= 1:2
    filename=sprintf('%s-driver%d-log.csv', files1{1}, files2(1));
    data=dlmread(filename,',');
    speed=data(:,2);  
    min1=min(speed);
    max1=max(speed);
    averagespeed=mean(speed);
    StandardDeviation=std(speed);
    fprintf('\n driver%d statistics in route %s: \n Mean speed: %.2f(sd:%.2f) \n Min-Max speed: [%.2f , %.2f] \n',files2(1),files1{1}, averagespeed, StandardDeviation, min1, max1)
end
    end

clc
clear
v=[];
w=[];
i=1;
for files1={'a1','n1'}
for files2= 1:2
    filename=sprintf('%s-driver%d-log.csv', files1{1}, files2(1));
    data=dlmread(filename,',');
    speed=data(:,2);
    distanceorigin=data(:,1);
    v=[v speed];
    w=[w distanceorigin];
    end
  subplot(1,2,i);
  plot(w,v);
  if i==1
    title('Subplot A1: Driver 1 vs Driver 2'); 
  else
     title('Subplot N1: Driver 1 vs Driver 2'); 
  end
  i=i+1;
  v=[];
  w=[];
end

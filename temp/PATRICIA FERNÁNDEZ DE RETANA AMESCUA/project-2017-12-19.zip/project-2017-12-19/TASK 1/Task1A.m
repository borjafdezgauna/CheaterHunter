v=[];
files= {'a1','n1'};
for i=1:length(files)
  filename= sprintf('%s-height.csv',files{i});
  data=dlmread(filename, ',',1,0);
  v={v data};
end
subplot(1,2,1);
plot(v{1,1}{1,2}(:,4),v{1,1}{1,2}(:,3),v{1,2}(:,4),v{1,2}(:,3));
title('Subplot A1: elevation(m) vs distance(km)');
xLabel = 'distance(km)';
yLabel = 'elevation(m)';

subplot(1,2,2);
plot(v{1,1}{1,2}(:,2),v{1,1}{1,2}(:,1),v{1,2}(:,2),v{1,2}(:,1));
title('Subplot A2: latitude vs longitude');
xLabel = 'longitude';
yLabel = 'latitude';



% ROUTE 1 - HIGHWAY

elevationA = dlmread('a1-height.csv',',',[1 2 0 2]);
minA = min(elevationA);
maxA = max(elevationA);
aveheightA = mean(elevationA);
StandardDeviationA = std(elevationA);

fprintf('A1 Route statistics: \n Mean height: %f(sd:%f) \n Height range: [%f , %f] \n', aveheightA, StandardDeviationA, minA, maxA)




% ROUTE 2 - NATIONAL ROAD

elevationN = dlmread('n1-height.csv',',',[1 2 0 2]);
minN = min(elevationN);
maxN = max(elevationN);
aveheightN = mean(elevationN);
StandardDeviationN = std(elevationN);

fprintf('N1 Route statistics: \n Mean height: %f(sd:%f) \n Height range: [%f , %f]', aveheightN, StandardDeviationN, minN, maxN)



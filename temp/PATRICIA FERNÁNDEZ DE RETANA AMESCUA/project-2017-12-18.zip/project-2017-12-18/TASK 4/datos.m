
numSlices = input('give me a number')

  driver1N = dlmread('n1-driver1-log.csv');
  speedKm = driver1N1(:,2);
  km = driver1N1(:,1);
  numSlices = 1000;
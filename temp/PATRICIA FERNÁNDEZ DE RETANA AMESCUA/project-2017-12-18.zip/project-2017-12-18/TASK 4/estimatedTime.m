function estimatedTime = estimateTime (kms, speedKmH,numSlices)
  
  i = 1;
  
  while kms(i)<x
    
        i = i+1;   
end

  Y2 = speedKmH (i);
  Y1 = speedKmH (i-1);
  X2 = kms (i);
  X1 = kms (i-1);
  
  slope = (Y2-Y1)/(X2-X1);
  
  interpolateY = Y1 + slope*(x-X1)
  
  end
  
  

    
function interpolateY = interpolateLinearly (distance, speed,x)

   m = toMeters(km)
   
   msSpeed = toMetersperSecond(speedKmH)
   
   estimatedTime = estimateTime( m, msSpeed, numSlices)
    
   hms  = toHMS(totalseconds) 
   
      fprintf('Estimated time for driver1 in route n1: %d',hms)

      
 end


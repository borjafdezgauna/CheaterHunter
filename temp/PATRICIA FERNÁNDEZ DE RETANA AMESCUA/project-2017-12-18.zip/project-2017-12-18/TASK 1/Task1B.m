
% ROUTE 1 - HIGHWAY

elevationA = dlmread('a1-height.csv',',',[1 2 0 2]);
minA = min(elevationA);
maxA = max(elevationA);
aveheightA = mean(elevationA);
StandardDeviationA = std(elevationA);

fprintf('\n A1 Route statistics: \n Mean height: %.2f(sd:%.2f) \n Height range: [%.2f , %.2f] \n', aveheightA, StandardDeviationA, minA, maxA)




% ROUTE 2 - NATIONAL ROAD

elevationN = dlmread('n1-height.csv',',',[1 2 0 2]);
minN = min(elevationN);
maxN = max(elevationN);
aveheightN = mean(elevationN);
StandardDeviationN = std(elevationN);

fprintf('\n N1 Route statistics: \n Mean height: %.2f(sd:%.2f) \n Height range: [%.2f , %.2f]', aveheightN, StandardDeviationN, minN, maxN)



function interpolateY = interpolateLinearly (distanceorigin1N1, speed1N1,x)
  
  i = 1;
  
  while distanceorigin1N1<=x
    
        i = i+1;   
end

  Y2 = speed1N1 (i);
  Y1 = speed1N1 (i-1);
  X2 = distanceorigin1N1 (i);
  X1 = distanceorigin1N1 (i-1);
  
  slope = (Y2-Y1)/(X2-X1);
  
  interpolateY = Y1 + slope*(x-X1)
  
  end
  
  

%driver1N1 = dlmread('n1-driver1-log.csv',',');
%speed1N1 = driver1N1(:,2);
%distanceorigin1N1 = driver1N1(:,1);
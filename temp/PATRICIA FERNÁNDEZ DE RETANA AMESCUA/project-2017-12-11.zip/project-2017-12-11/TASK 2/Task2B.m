% ROUTE N

driver1N1 = dlmread('n1-driver1-log.csv',',');
driver2N1 = dlmread('n1-driver2-log.csv',',');

speed1N1 = driver1N1(:,2);
speed2N1 = driver2N1(:,2);

min1N1 = min(speed1N1);
max1N1 = max(speed1N1);
averagespeed1N1 = mean(speed1N1);
StandardDeviation1N1 = std(speed1N1);

fprintf('\n driver1 statistics in route N1: \n Mean speed: %.2f(sd:%.2f) \n Min-Max speed: [%.2f , %.2f] \n', averagespeed1N1, StandardDeviation1N1, min1N1, max1N1)

min2N1 = min(speed2N1);
max2N1 = max(speed2N1);
averagespeed2N1 = mean(speed2N1);
StandardDeviation2N1 = std(speed2N1);

fprintf('\n driver2 statistics in route N1: \n Mean speed: %.2f(sd:%.2f) \n Min-Max : [%.2f , %.2f]', averagespeed2N1, StandardDeviation2N1, min2N1, max2N1)



% ROUTE A

driver1A1 = dlmread('a1-driver1-log.csv',',');
driver2A1 = dlmread('a1-driver2-log.csv',',');

speed2A1 = driver2A1(:,2);
speed1A1 = driver1A1(:,2);


min1A1 = min(speed1A1);
max1A1 = max(speed1A1);
averagespeed1A1 = mean(speed1A1);
StandardDeviation1A1 = std(speed1A1);

fprintf('\n\n driver1 statistics in route A1: \n Mean speed: %.2f(sd:%.2f) \n Min-Max speed: [%.2f , %.2f] \n', averagespeed1A1, StandardDeviation1A1, min1A1, max1A1)

min2A1 = min(speed2A1);
max2A1 = max(speed2A1);
averagespeed2A1 = mean(speed2A1);
StandardDeviation2A1 = std(speed2A1);

fprintf('\n driver2 statistics in route A1: \n Mean speed: %.2f(sd:%.2f) \n Min-Max speed: [%.2f , %.2f]', averagespeed2A1, StandardDeviation2A1, min2A1, max2A1)


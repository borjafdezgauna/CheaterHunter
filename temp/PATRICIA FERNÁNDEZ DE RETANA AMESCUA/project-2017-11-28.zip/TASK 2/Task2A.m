
% ROUTE A

driver1A1 = dlmread('a1-driver1-log.csv',',');
driver2A1 = dlmread('a1-driver2-log.csv',',');

speed1A1 = driver1A1(:,2);
distanceorigin1A1 = driver1A1(:,1);
speed2A1 = driver2A1(:,2);
distanceorigin2A1 = driver2A1(:,1);

subplot(1,2,1);
plot(distanceorigin1A1,speed1A1,'k',distanceorigin2A1,speed2A1,'c');
title('Subplot A1: Driver A1 vs Driver A2');



% ROUTE B

driver1N1 = dlmread('n1-driver1-log.csv',',');
driver2N1 = dlmread('n1-driver2-log.csv',',');


speed1N1 = driver1N1(:,2);
distanceorigin1N1 = driver1N1(:,1);
speed2N1 = driver2N1(:,2);
distanceorigin2N1 = driver2N1(:,1);

subplot(1,2,2);
plot(distanceorigin1N1,speed1N1,'k',distanceorigin2N1,speed2N1,'c');
title('Subplot A1: Driver N1 vs Driver N2');

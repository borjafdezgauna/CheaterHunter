%driver1N1 = dlmread('n1-driver1-log.csv',',');
%speed1N1 = driver1N1(:,2);
%distanceorigin1N1 = driver1N1(:,1);
%x=20
function time1N = calculateTime(distanceorigin1N1,speed1N1)

 time=distanceorigin1N1(1)/speed1N1(1);
 
 for i=1:length(distanceorigin1N1)-1 
     
 sumTime=distanceorigin1N1(i+1)/speed1N1(i+1);
 
 time= time + sumTime;
 
 end
 
 time1N = time
 
end

 
 
 
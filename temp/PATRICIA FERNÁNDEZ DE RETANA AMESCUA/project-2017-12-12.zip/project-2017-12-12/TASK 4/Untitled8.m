
numSlices = input('give me a number')

function estimatedTime = estimateTime( kms, speedKmH, numSlices)

    driver1N = dlmread('n1-driver1-log.csv')
    speed1N1 = driver1N1(:,2);
    distanceorigin1N1 = driver1N1(:,1);
    
    


    

end


function  hms  = toHMS(totalseconds) 

hours = fix(totalseconds/3600);

minutes = fix(rem(totalseconds,3600)/60);

seconds = rem(rem(totalseconds,3600),60);

hms = fprintf('%02d:%02d:%02d',hours,minutes,seconds);

end


clear
clc

kms= [0 10 40];
speedLimit= [90 120 90];
x=input('Dime la posicion: ');
SpeedLimit = interpolateToTheLeft( kms, speedLimit , x)
function interpolatedY = interpolateToTheLeft( kms, speedLimit , x)
i=1;
while i<=length(kms)  && kms(i)<=x
    i=i+1;
end
if i==1
    interpolatedY = speedLimit(i);
else
    interpolatedY = speedLimit(i-1);
end
end



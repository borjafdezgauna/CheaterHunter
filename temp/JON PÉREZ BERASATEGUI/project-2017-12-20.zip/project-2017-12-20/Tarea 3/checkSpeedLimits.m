function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)

slices = (driverLogKm(end)-driverLogKm(1))/numSlices;
percentAboveSpeedLimit = 0;
kmsAboveSpeedLimit = 0;
for m = linspace(driverLogKm(1),driverLogKm(end),numSlices)
    velocidad= interpolateLinearly( driverLogKm, driverLogSpeed , m);
    SpeedLimit = interpolateToTheLeft( limitKms, limitSpeeds , m);
    if velocidad > SpeedLimit
        kmsAboveSpeedLimit = kmsAboveSpeedLimit + slices;
    end
    percentAboveSpeedLimit= kmsAboveSpeedLimit*100/(driverLogKm(end)-driverLogKm(1));
end




        
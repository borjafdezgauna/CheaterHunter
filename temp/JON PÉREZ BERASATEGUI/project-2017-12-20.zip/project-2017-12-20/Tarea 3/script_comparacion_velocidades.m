clear
clc

numSlices=10000;
rutas = {'n1','a1'};
conductores = {'driver1','driver2'};
patron_entrada = 'Datos/%s-%s-log.csv';
limite_velocidad = 'Datos/%s-speed-limit.csv';
for k = 1:length(rutas)
    file_name_two = sprintf(limite_velocidad,rutas{k});
    limite = dlmread(file_name_two,';');
    for b = 1:length(conductores)
        file_name = sprintf(patron_entrada,rutas{k},conductores{b});
        velocidad = dlmread(file_name,',');
        [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits(velocidad(:,1), velocidad(:,2), limite(:,1), limite(:,2), numSlices);
        if percentAboveSpeedLimit >0 && percentAboveSpeedLimit<=10
            fprintf ('\nAnalyzing: Driver = %s, Route = %s\n',conductores{b},rutas{k});
            fprintf ('Mild infraction risk: Kms abover the speed limit= %.2f (%.2f%% of the route)\n', kmsAboveSpeedLimit, percentAboveSpeedLimit);
        elseif percentAboveSpeedLimit == 0
            fprintf ('\nAnalyzing: Driver = %s, Route = %s\n',conductores{b},rutas{k});
            fprintf ('No risk of infraction\n');
        else
            fprintf ('\nAnalyzing: Driver = %s, Route = %s\n',conductores{b},rutas{k});
            fprintf ('HIGH INFRACTION RISK: Kms abover the speed limit= %.2f (%.2f%% of the route)\n', kmsAboveSpeedLimit, percentAboveSpeedLimit);
        end
    end
end

 



function combustible_conductor_ruta
    disp('Lo sentimos, no nos ha dado tiempo a realizarlo. ')
    pause (5)
end




function combustible_conductor_ruta
    disp('Todavia no esta realizado')
    pause (5)
end




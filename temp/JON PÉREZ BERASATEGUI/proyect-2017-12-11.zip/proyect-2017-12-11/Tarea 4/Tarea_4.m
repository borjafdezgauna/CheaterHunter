km = input('Introduce un valor en kilometros: ');
ms = toMeters( km );
fprintf('toMeters(%.1f) => %.f',km,ms)

speedKmH = input('Introduce una velocidad: ');
msSpeed = toMetersPerSecond( speedKmH );
fprintf('toMetersPerSecond(%.f) => %.4f',speedKmH,msSpeed)
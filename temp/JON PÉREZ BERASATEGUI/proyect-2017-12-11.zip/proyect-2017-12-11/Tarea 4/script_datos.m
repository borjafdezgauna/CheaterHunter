x = input ('Introduce la posici�n: ')
xVector = [10 20 40];
yVector = [120 150 130];
Diferecia_vector = diff(xVector);
i=xVector(1);
while ~(x>i && x<=i+1)
    i=i+1;
end

disp(i)
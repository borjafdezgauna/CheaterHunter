clear
clc

seconds = input('Mete los segundos: ')  
hms  = toHMS( seconds ) 
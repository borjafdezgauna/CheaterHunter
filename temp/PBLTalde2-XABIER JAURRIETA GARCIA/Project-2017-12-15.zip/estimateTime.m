function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
  estimatedTime=0
  m  = toMeters(kms)
  bukaera=m(1,end)
  aldakuntza_d=bukaera/numSlices
  if speedKmH==0
    estimatedTime=0
    else
   msSpeed = toMetersPerSecond( speedKmH );
 
for i=1:numSlices
  t=(i-1)*aldakuntza_d;
  interpolatedY=interpolateLinearly(m,msSpeed,t);
  estimatedTime= estimatedTime + aldakuntza_d/interpolatedY;
  end
  end
  end
for num={'a1','n1'}
  for gid=1:2
      file=sprintf('%s-driver%d-log.csv',num{1},gid)

        datuak=dlmread(file, ',');
        denboraTotala=estimateTime([datuak(:,1)],[datuak(:,2)],1000);
        denboraOrdutan=toHMS (denboraTotala);
        fprintf('%d gidariaren denbora estimatua %s bidean:' ,denboraOrdutan)
        end
        end
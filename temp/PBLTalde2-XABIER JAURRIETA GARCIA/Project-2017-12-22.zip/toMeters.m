function [ m ] = toMeters( km )
  %Kilometroak metrotan bihurtuko ditugu.
  m=km*1000;
end
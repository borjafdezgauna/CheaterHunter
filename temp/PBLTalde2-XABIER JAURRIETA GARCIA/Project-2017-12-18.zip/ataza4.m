%Hasi aurretik, kontsola garbitu.
clc
  
  
  for num={'a1','n1'}
    for gid=1:2
      file=sprintf('%s-driver%d-log.csv',num{1},gid);
      datuak=dlmread(file, ',');
        
      kilometroakErrenkada=rot90([datuak(:,1)]);
      abiaduraErrenkada=rot90([datuak(:,2)]);
      
      denboraTotala=estimateTime(kilometroakErrenkada,abiaduraErrenkada,5000);
      denboraOrdutan=toHMS (denboraTotala);
     fprintf('%d gidariaren denbora estimatua %s bidean:%s\n' ,gid,num{1},denboraOrdutan)
    end
   end
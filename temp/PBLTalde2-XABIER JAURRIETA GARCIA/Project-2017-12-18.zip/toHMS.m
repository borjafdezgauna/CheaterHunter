function [ hms ] = toHMS( seconds )
  orduak=seconds/3600;
  
  orduakFix=fix(orduak);
  segunduak1=seconds-orduakFix*3600;
  minutuak=segunduak1/60;
  minutuakFix=fix(minutuak);
  
  segunduak2=segunduak1-minutuakFix*60;
  segunduakFix=fix(segunduak2);
  hms=sprintf('Ordua:%02d:%02d:%02d',orduakFix, minutuakFix,segunduakFix);
  end
  
  
  
  
%%This will convert the speed in km/h into m/s
function [ msSpeed ] = toMetersPerSecond( speedKmH )
  msSpeed = speedKmH/3.6
  end
%%This will convert the kilometers into meters
function [meters] = toMeters(km)
  meters = km*1000
  endfunction
leters={'a1','n1'};
drivers={'driver1','driver2'};
numSlices=100;
for x=[1,2]
    for y=[1,2]
        
    filenamedriver=sprintf('%s-%s-log.csv',leters{x},drivers{y});
    distancespeed=dlmread(filenamedriver, ',');
    kms=distancespeed(:,1);
    speedKmH=distancespeed(:,2);
    
seconds=estimateTime(kms, speedKmH, numSlices);

time = toHMS (seconds);

fprintf('Estimated time for %s in route %s: %s\n',drivers{y},leters{x},time)

    end
end
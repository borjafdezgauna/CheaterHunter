function [hms] = toHMS2 (seconds)

secondsans = rem (seconds,60);
minutes=(seconds-secondsans)/60);
if minutes=>60;
  minutes=rem(minutes,60)
  hours=minutes
hours= ((seconds/60)/ 60);
  
  hsm = sprintf('%2d:%2d:%2d',hours,minutes,secondsans)
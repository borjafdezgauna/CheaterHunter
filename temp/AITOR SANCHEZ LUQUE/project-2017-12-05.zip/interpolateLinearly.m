function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
variable=1;
while xVector(variable)<=x
variable= variable+1;
end
y2= yVector(variable);
y1= yVector(variable-1);
x2= xVector(variable);
x1= xVector(variable-1);
slope= (y2-y1)/(x2-x1);
interpolatedY= y1 + slope * (x-x1);
endfunction    



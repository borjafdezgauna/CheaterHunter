disp('######  MENU  ######:')
disp('1. Show route plots/statistics')
disp('2. Show driver plots/statistics')
disp('3. time calculations for each driver/route')
disp('4. Check speed limits')
disp('5. Fuel consumption calculations for each driver/route')
disp('6. Exit')

number= input('Choose an option: ');

if number == 1
  
  leters={'a1','n1'};
 
       for x=[1,2]
          filename=sprintf('%s-height.csv',leters{x});
          height=dlmread(filename,',',1,0);
          Latitude=height(:,1);
          Longitude=height(:,2);
          Elevation=height(:,3);
          Distance=height(:,4);
          
          average = mean(Elevation);
          sd = std(Elevation);
          minx = min(Elevation);
          maxx = max(Elevation);
          fprintf('%s route statistics:\n',leters{x}); 
          fprintf('Mean height: %.2f (sd: %.2f)\n', average, sd);
          fprintf('Height range: [%.2f, %.2f]', minx, maxx);
          
           subplot(1,2,1)
           re=plot(Distance, Elevation);
           xlabel('Distance(km)');
           ylabel('Height(m)');
           hold on
           subplot(1,2,2)
           plot(Longitude, Latitude);
           xlabel('Longitude');
           ylabel('Latitude');
           hold on
        end
  hold off

 
 elseif number== 2
      
        leters={'a1','n1'};
        drivers={'driver1','driver2'};
    
    for x=[1,2]
        
        for y=[1,2]
        
             filenamedriver=sprintf('%s-%s-log.csv',leters{x},drivers{y});
             distancespeed=dlmread(filenamedriver, ',');
             Distance=distancespeed(:,1);
             speed=distancespeed(:,2);
      
    
             average = mean(speed);
             sd = std(speed);
             minx = min(speed);
             maxx = max(speed);
             fprintf('%s statistics in route %s:\n',drivers{y}, leters{x}); 
             fprintf('Mean speed: %.2f km/h (sd: %.2f)\n', average, sd);
             fprintf('Min-Max speed: [%.2f, %.2f]\n\n', minx, maxx);
            
     
    
             subplot(1,2,x);
             ds=plot(Distance,speed);
             title(leters(x))
             xlabel('Distance(km)');
             ylabel('Speed(km/h)');
             hold on
       end
    legend('Driver 1','Driver 2');
    hold off
    end
    
    
elseif number==3
    
    leters={'a1','n1'};
    drivers={'driver1','driver2'};
    Distancefrag=0.10204;
      
      for x=[1,2]
      
          for y=[1,2]
                
            filename=sprintf('%s-%s-log.csv',leters{x},drivers{y});
            velocity=dlmread(filename,',',1,1);
            Times=Distancefrag./velocity;
            Totaltime=sum(Times);
            fprintf('The time %s took driving through %s was: %f h\n',drivers{y}, leters{x} , Totaltime);
          end
          
       end
       
elseif number == 4
       
     leters={'a1','n1'};
     
        for x=[1,2]
          
          filename=sprintf('%s
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
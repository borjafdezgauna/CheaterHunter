leters={'a1','n1'};
drivers={'driver1','driver2'};
for x=[1,2]
    for y=[1,2]
        
    filenamedriver=sprintf('%s-%s-log.csv',leters{x},drivers{y});
    distancespeed=dlmread(filenamedriver, ',');
    Distance=distancespeed(:,1);
    speed=distancespeed(:,2);
  
    
    average = mean(speed);
    sd = std(speed);
    minx = min(speed);
    maxx = max(speed);
    fprintf('%s statistics in route %s:\n',drivers{y}, leters{x}); 
    fprintf('Mean speed: %.2f km/h (sd: %.2f)\n', average, sd);
    fprintf('Min-Max speed: [%.2f, %.2f]\n\n', minx, maxx);
    
    
    
    subplot(1,2,x);
    ds=plot(Distance,speed);
    title(leters(x))
    xlabel('Distance(km)');
    ylabel('Speed(km/h)');
    hold on
    end
   legend('Driver 1','Driver 2');
    hold off
end

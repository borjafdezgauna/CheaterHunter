function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
interpolatedspeed=[];
kmsAboveSpeedLimit=0;
Slices=limspace(1:numSlices);
for Slices
    interpolatedspeed = interpolateToTheLeft( driverLogKm, driverLogSpeed , Slices);
end
    totalTime=0;
    lvalue = driverLogKm(length(driverLogKm));
    kmslices = linspace(0,lvalue,numSlices);
    for stage=numSlices;
     variable=2;
    while limitKms(variable)<kmslices(stage)
    variable= variable+1;
    end
    variablespeed=  limitSpeeds(variable-1);
    if interpolatedspeed(stage) > variablespeed
        kmsAboveSpeedLimit=kmsAboveSpeedLimit+kmslices(1)
    end
end
percentAboveSpeedLimit=(kmsAboveSpeedLimit/driverLogKm(lenght(driverLogKm)))*100
  
end
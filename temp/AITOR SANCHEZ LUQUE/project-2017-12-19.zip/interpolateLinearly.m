function [ interpolatedY ] = interpolateToTheLeft( xVector, yVector , x)
variable=2;
while xVector(variable)<x
variable= variable+1;
end

interpolatedY= yVector(variable-1);

end
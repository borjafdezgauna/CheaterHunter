function [estimatedTime] = estimateTime(kms, speedKmH, numSlices) 
totalTime=0;
lvalue = kms(length(kms));
slices = linspace(0,lvalue,numSlices);
for slice=slices;
  speed=interpolateLinearly(kms,speedKmH,slice);
  if speed == 0
  time=0;
  else
  time=slices(2)/speed;
  end
  totalTime = totalTime+time;
end

estimatedTime = totalTime*3600;

end


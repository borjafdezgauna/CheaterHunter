function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
lvalue = kms(length(kms));
slices = linspace(0,lvalue,numSlices);
for slice=slices;
  speed=interpolateLinearly(kms,speedKmH,slice);
  speedlimit=interpolateToTheLeft(kms,speedKmH,slice)
  if speed == speedlimit
  kmsAboveSpeedLimit=kmsAboveSpeedLimit+slices(1)
  end
end

percentAboveSpeedLimit=(kmsAboveSpeedLimit/driverLogKm(lenght(driverLogKm)))*100

end
leters={'a1','n1'};
for x=[1,2]
    filename=sprintf('%s-height.csv',leters{x});
    height=dlmread(filename,',',1,0);
    Latitude=height(:,1);
    Longitude=height(:,2);
    Elevation=height(:,3);
    Distance=height(:,4);
    
    average = mean(Elevation);
    sd = std(Elevation);
    minx = min(Elevation);
    maxx = max(Elevation);
    fprintf('%s route statistics:\n',leters{x}); 
    fprintf('Mean height: %.2f (sd: %.2f)\n', average, sd);
    fprintf('Height range: [%.2f, %.2f]', minx, maxx);
    
   subplot(1,2,1)
   re=plot(Distance, Elevation);
   xlabel('Distance(km)');
   ylabel('Height(m)');
   hold on
   subplot(1,2,2)
   plot(Longitude, Latitude);
   xlabel('Longitude');
   ylabel('Latitude');
   hold on
end
hold off
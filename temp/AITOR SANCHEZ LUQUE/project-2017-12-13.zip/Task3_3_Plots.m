leters={'a1','n1'};
drivers={'driver1','driver2'};
Distancefrag=0.10204;
for x=[1,2]
    for y=[1,2]
        
    filename=sprintf('%s-%s-log.csv',leters{x},drivers{y});
    velocity=dlmread(filename,',',1,1);
    Times=Distancefrag./velocity;
    Totaltime=sum(Times);
    fprintf('The time %s took driving through %s was: %f h\n',drivers{y}, leters{x} , Totaltime);
    end
end
function [meters] = toMeters(km)
  meters = km*1000
  endfunction
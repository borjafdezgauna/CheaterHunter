 function [ m ] = toMeters( km )
   format long;
  m=km*1000;
  end
for file={'a1-driver1-log.csv','a1-driver2-log.csv'}
   a=dlmread(file{1},';');
   v1=a(:,2);
   d1=a(:,1);
   
   subplot(2850,2,1)
   hold on 
       plot(d1,v1)
       title('Abiadura-distantzia')
   hold off
end

       
   
   

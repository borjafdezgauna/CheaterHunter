bar=1;
for route={'a1','n1'}
    for driver={'1','2'}
        
        file=sprintf('%s-driver%s-log.csv', route{1}, driver{1});
        file2=sprintf('%s-speed-limit.csv', route{1});
            
            m1=dlmread(file,',',0,0);
            m2=dlmread(file2,';',0,0);
   
            vd=m1(:,1);
            vv=m1(:,2);
            stage=m2(:,1);
            lv=m2(:,2);
            
            
            xVector=vd;
            yVector=vv;
            x=linspace(0,1850,10000);
            intG= interpolazioa(xVector, yVector, x);
            
            xVector=stage;
            yVector=lv;
            x=linspace(0,3,10000);
            intV=interpolazioa(xVector, yVector, x);
       
            fprintf('subplot(1,2,%f', bar);
            hold on
            plot();
            hold off
    end
           bar=bar+1;    
end
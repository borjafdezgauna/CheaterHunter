k = 1;
  for route={'a1','n1'}
  subplot(1,2,k);   
  hold on 
  
  for driver=1:2
  
  file=sprintf('%s-driver%d-log.csv',route{1}, driver);
   a=dlmread(file,',');
   v=a(:,2);
   d=a(:,1);
   plot(d,v); 
   title('GIDARIEN ABIADURA AUTOPISTAN');
   xlabel('Distantzia(km)');
   ylabel('Abiadura(km/h)');
   hold on 
  medV=sum(a(:,2))/length(a(:,2));
  minV=min(a(:,2));
  maxV=max(a(:,2));
  desbiderazioa=std(a(:,2));
  fprintf('Driver%d''s statistics for route %s \n Mean speed:%.2f km/h (sd. %.2f) \n Min-max speed:[%.2f,%.2f]\n\n ',driver,route{1},medV,desbiderazioa,minV,maxV);
  end
  k = k +1;
  end 
    title('GIDARIEN ABIADURA NAZIONALEAN');



   
   
   
   
   
   
   
   
   
   
 
x=input('######## MENU########\n 1. Show route plots/statistics\n 2. Show driver plots/statistics\n 3. Time calculations for each driver/route\n 4. Check speed limits\n 5. Fuel consumption calculations for each driver/route\n 6. Exit\n Choose an option:', 's');
    X=str2num(x);
    if X==1
        Ejercicio1
        M=input('Sakatu edozein tekla jarraiteko.\n', 's')
        clc
        close all
        EjercicioMenu
    elseif X==2
        Ejercicio2
        M=input('Sakatu edozein tekla jarraiteko.\n', 's') 
        clc
        close all
        EjercicioMenu
    elseif X==3
        Ejercicio3
        M=input('Sakatu edozein tekla jarraiteko.\n', 's') 
        clc
        close all
        EjercicioMenu    
    elseif X==4
        Ejercicio4
        M=input('Sakatu edozein tekla jarraiteko.\n', 's') 
        clc
        close all
        EjercicioMenu    
    elseif X==5
        Ejercicio5
        M=input('Sakatu edozein tekla jarraiteko.\n', 's') 
        clc
        close all
        EjercicioMenu
        
    elseif X==6
        clc
        disp('See you!') 
        pause(1)
        clc
  
    else clc
        M=input('Aukera dezegokia: 1 eta 6 artean egon behar da.\n Sakatu edozein tekla menura bueltatzeko.', 's')
        EjercicioMenu
    end
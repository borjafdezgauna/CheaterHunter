clear
for filename={'a1','n1'}
file=sprintf('%s-height.csv', filename{1});
   
    m=dlmread(file,',',1,0);
    
     vla=m(:,1);
     vlo=m(:,2);
     vh=m(:,3);
     vd=m(:,4);
     
    subplot(1,2,1)
        hold on
            plot(vd, vh);
            title('Altuera-Distantzia')
        hold off
        
    subplot(1,2,2);
        hold on
            plot(vlo, vla);
            title('Latitudea-Longitudea')
        hold off
        
    medA=mean(vh);
    minA=min(vh);
    maxA=max(vh);
    stdA=std(vh);

fprintf('%s route statistics\n Mean height: %.2f (sd: %.2f)\n Height range: [%.2f,%.2f]\n', filename{1}, medA, stdA, minA, maxA)
end
            saveas(gcf, 'route-elevations.png');
            


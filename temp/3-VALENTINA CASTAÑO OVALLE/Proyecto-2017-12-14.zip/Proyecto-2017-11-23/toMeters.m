function [m] = toMeters(km)
  
  while km>0
   m=1000*km
  end
end 
    
  
[msSpeed] = toMetersPerSecond(15)

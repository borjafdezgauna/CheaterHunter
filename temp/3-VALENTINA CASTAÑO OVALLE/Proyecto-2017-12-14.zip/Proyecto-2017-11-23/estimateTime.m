function [estimatedTime] = estimateTime(kms, speedKmH, numSlices)

for i=1:numSlices
    estimatedTime=
    
end
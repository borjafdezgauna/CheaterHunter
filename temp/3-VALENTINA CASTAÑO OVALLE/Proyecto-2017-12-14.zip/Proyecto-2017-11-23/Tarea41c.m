[interpolatedY] = interpolateLinearly([10 20 40],[120 150 130],40)

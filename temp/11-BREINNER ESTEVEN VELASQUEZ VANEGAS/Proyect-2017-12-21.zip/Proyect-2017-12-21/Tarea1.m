clc
clear
Media=0;
lado=1;
    for ruta={'n1','a1'} %Ruta tienes los Ficheros de las n1(Ruta Nacional 1) y de a1(Ruta Autopista 1)
      lado=1;  
      Archivo=sprintf('%s-height.csv',ruta{1}); %Buscar el Fichero       
      Fichero=dlmread(Archivo,',',1,0); %Se cargan los ficheros a1, n1
      subplot(1,2,lado);%Sub graficas
      hold on
      plot(Fichero(:,4),Fichero(:,3)); % Grafica de Alturas Relativas a la Distancia 
      ylabel('Alturas')% Nombre de los Ejes y el titulo de la grafica
      xlabel('Distancia')
      title('Grafica1')
      lado=lado+1;%Cambiamos el lado para hacer el otro Subplot
      subplot(1,2,lado);
      hold on
      plot(Fichero(:,2),Fichero(:,1)); % Grafica de la longitud contra latitud
      ylabel('Latitud')% Nombre de los Ejes y el titulo de la grafica
      xlabel('Longitud')
      title('Grafica2')
      A=Fichero(:,3); %Con la columna 3 de cada fichero calculamos los valores estadisticos      
      Media=mean(A);
      DesviacionEstandar = std(A);
      Maximo=max(A);
      Minimo=min(A);
      fprintf('Estadisticas de la Ruta %s:\n Altura Media:%f\n Desviacion Estandar:%f\n Rango de Alturas :[%.1f,%.1f]\n',ruta{1},Media,DesviacionEstandar,Minimo,Maximo)
      %Sacamos por pantalla dichos valores 
      
    end



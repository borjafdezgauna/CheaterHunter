function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
    t=0;
    finaleskms= kms(end) - kms(1);
    e=finaleskms/numSlices;
   
      for i=kms(1):e:kms(end)
          v = interpolateLinearly(kms,speedKmH,i);
          t=t+(toMeters(e)/toMetersPerSecond(v));
      end
    estimatedTime=t;
end 

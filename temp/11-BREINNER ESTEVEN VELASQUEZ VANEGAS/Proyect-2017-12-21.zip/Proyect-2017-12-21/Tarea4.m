clc
clear 
     for ruta={'n1','a1'}
       lado=1;
        for conductor={'driver1','driver2'}
          fichero1=sprintf('%s-%s-log.csv',ruta{1},conductor{1});
          fichero2=dlmread(fichero1,',',1,0);
          tiempo = estimateTime( fichero2(:,1), fichero2(:,2), 1000);
          res = toHMS(tiempo);          
          fprintf('Estimated time for conductor %s in route %s: %s\n' ,conductor{1},ruta{1},res)
          lado=lado+1;
        end
      end

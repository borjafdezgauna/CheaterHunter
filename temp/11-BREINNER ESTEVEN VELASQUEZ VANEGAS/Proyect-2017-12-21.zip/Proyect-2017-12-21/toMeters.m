function  [m] = toMeters(kilometros)
     m = kilometros * 1000; 
end 
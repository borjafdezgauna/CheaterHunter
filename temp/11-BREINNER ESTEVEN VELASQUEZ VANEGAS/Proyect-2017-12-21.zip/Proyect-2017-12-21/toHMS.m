function [ hms ] = toHMS( seconds )
    horas=fix(seconds/3600);
    resto1=rem(seconds,3600);
    minutos=fix(resto1/60);
    resto2=rem(resto1,60);
    segundos=fix(resto2);
    [hms]=sprintf('%02d:%02d:%02d',horas,minutos,segundos);
end
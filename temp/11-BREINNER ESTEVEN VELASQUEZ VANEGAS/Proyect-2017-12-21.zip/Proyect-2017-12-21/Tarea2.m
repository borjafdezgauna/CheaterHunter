clc
clear
     for ruta={'n1','a1'}%Recorre los datos de las rutas
       lado=1;
      for conductor={'driver1','driver2'}%Recorre los datos de los Conductores
          fichero1=sprintf('%s-%s-log.csv',ruta{1},conductor{1});
          fichero2=dlmread(fichero1,',',1,0);%Leemos el Fichero 
          subplot(1,2,lado);
          plot(fichero2(:,1),fichero2(:,2)); % Grafica de la Velocidad contra distancia
          hold on  
          ylabel('Distancia')%Nombres de los Ejes 
          xlabel('Velocidad')
          title(conductor)
                             
          V=fichero2(:,1); %Con la columna 1 de cada fichero(Velocidades) calculamos los valores estadisticos      
          Media=mean(V);
          Maximo=max(V);
          Minimo=min(V);
          fprintf('Estadisticas de la Ruta %s y el conductor %s:\n Velocidad Media:%f\n  Rango de Velocidad :[%.1f,%.1f]\n',ruta{1},conductor{1},Media,Minimo,Maximo)
          %Sacamos por pantalla dichos valores 
          lado=lado+1;
     end
    end

function [ interpolatedY ] = interpolateToTheLeft( xVector, yVector , x)
i=1;
    while i<length(xVector) &&  xVector(i)<=x 
     i=i+1;
    end 
    i=i-1;
        if x > xVector(end)
         interpolatedY=yVector(1); 
        else
         interpolatedY=yVector(i);   
        end    
end

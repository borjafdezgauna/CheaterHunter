function [ interpolatedy ] = interpolateLinearly( xvector, yvector , x)
   i=1;
   while i<length(xvector) &&  xvector(i)<=x
     i=i+1;
   end 
   i=i-1;
   A=xvector(i+1)- xvector(i);   
   B=yvector(i+1)- yvector(i);   
   C=x-xvector(i);
   v=(C*B)/A + yvector(i);
   interpolatedy=v;
end 
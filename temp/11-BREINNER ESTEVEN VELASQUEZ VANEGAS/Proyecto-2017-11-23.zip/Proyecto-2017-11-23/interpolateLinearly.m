function [ interpolatedy ] = interpolateLinearly( xVector, yVector , x)
  i=1
  j=1
    for i = 1:length (xVector)
       for j = 1:length (yvector)
          if x = v(i)
            interpolatedy = v(j)
          end 
       end
    end 
end     
  
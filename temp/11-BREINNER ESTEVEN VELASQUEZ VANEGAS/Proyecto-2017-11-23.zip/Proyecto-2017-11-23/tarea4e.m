xVector=[10 20 40]
yVector=[120 150 130]
x= 10
res= interp1(xVector,yVector,x)
disp(res)
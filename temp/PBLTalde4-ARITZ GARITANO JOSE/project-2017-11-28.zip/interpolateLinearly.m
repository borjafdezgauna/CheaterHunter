function [interpolatedY] = interpolateLinearly (xVector, yVector, x)  
   i=1;
   x0=0;
   y0=0;
   while xVector(i)<x
     i=i+1;
    end
    if i>1
       x0= xVector(i-1);
       y0= yVector(i-1);
    end
       x1= xVector(i);
       y1= yVector(i);
    malda= (y1-y0)/(x1-x0);
    interpolatedY= (x-x0)*malda + y0;
     end
function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits (driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
pos=zeros(1,numSlices);
diff=driverLogKm(length(driverLogKm))/numSlices;
zatiaknonlimiteapasatu=0;
gidariabiadurak=zeros(1,numSlices);
abiaduralimiteak=zeros(1,numSlices);
for step= 1: numSlices
    pos(step)=diff*step;
    x= pos(step);    
    [gidariabiadurak(step)] = interpolateLinearly (driverLogKm, driverLogSpeed, x);
    [abiaduralimiteak(step)] = interpolateToTheLeft (limitKms, limitSpeeds, x);
   if gidariabiadurak(step)>abiaduralimiteak(step)
      zatiaknonlimiteapasatu=zatiaknonlimiteapasatu +1;
   end
end    
    kmsAboveSpeedLimit=diff*zatiaknonlimiteapasatu;
    percentAboveSpeedLimit=(kmsAboveSpeedLimit/driverLogKm(length(driverLogKm)))*100;
 end
 
    
     
    
    
    
    
    
    
    
    



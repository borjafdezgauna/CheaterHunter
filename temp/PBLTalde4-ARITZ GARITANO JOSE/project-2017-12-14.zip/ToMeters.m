function [m] = ToMeters (km)
m=km*1000;
end

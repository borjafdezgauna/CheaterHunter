zenbakia=1;
%%hau jarri dugu whilean dagoen parametroa definituta egoteko
while  zenbakia~=6
  %%if-ak bakarrik zenbaki hauen artean daudenean ejekutatzeko
  fprintf( ' MENU\n1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit\n')
  zenbakia=input('Eman zenbaki bat');
  %%zenbakia eskatu
  if zenbakia==1
    ataza1
    ataza12
    input('Sakatu edozein tekla jarraitzeko','s');
    close all
  elseif zenbakia==2
   ataza2 
   ataza22
       input('Sakatu edozein tekla jarraitzeko','s');
   close all
  elseif zenbakia==3
   ataza46
    input('sakatu edozein tekla jarraitzeko','s');
  elseif zenbakia==4
    
    input('Sakatu edozein tekla jarraitzeko','s');
  elseif zenbakia==5
    
    input('Sakatu edozein tekla jarraitzeko','s');
    
  elseif zenbakia<1 || zenbakia>6
        fprintf('Aukera ezegokia: zenbakia 1 eta 6 artean egon behar da\n')
    %%zenbaki bakoitzekin gauza konkretu batzuk bistaratzeko
    
  end
end
  
  
    
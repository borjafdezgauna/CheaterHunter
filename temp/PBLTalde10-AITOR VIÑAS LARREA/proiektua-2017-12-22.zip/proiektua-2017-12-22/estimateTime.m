function [ emaitza ] = estimateTime( kms, speedKmH, numSlices);
denbora=0;
for i=1:numSlices;
  %%zenbat tarte dauden jakiteko
  tarteluzeera=kms(end)/numSlices;
  %%tarte bakoitzeko luzeera jakiteko(kilometroak guztira zati zati kopuruak)
  puntukm=tarteluzeera*i;
  %%zein tartetan gauden jakiteko
  abiadura= interpol(kms,speedKmH,puntukm); 
  %%edozein puntutan abiadura jakiteko interpolatuz
  tartedenbora=tarteluzeera/abiadura;
  %%tartea burutzeko behar duen denbora
  denbora=denbora+tartedenbora;
  %%tartedenborak batzeko azkenengo puntura iritsi arte
end
     emaitza=denbora*3600;
     %%orduak segundutan emateko
end
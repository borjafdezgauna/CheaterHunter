for i={'n1','a1'}
    filename= sprintf('%s-height.csv',i{1});
    errepideak=dlmread(filename,',',1,0);
      %%hemen fitxategiak irakurri ditugu
    a=mean(errepideak(:,3));
    b=std(errepideak(:,3));
    c=max(errepideak(:,3));
    d=min(errepideak(:,3));
       %%datu estatistikoak kalkulatu
    fprintf('%s:\n Batazbestekoa: %.2f, (Desbideratze estandarra: %.2f),\n Maxiamoa: %.2f, Minimoa: %.2f\n\n',filename,a,b,c,d)
       %%emaitza pantailaratu
    end
    
id=1;
for i={'n1','a1'}
    for ii={'driver1','driver2'}
    filename= sprintf('%s-%s-log.csv',i{1},ii{1});
    errepideak=dlmread(filename,',',0,0);
    %%fitzategiak irakurri
    subplot(1,2,id)
    plot(errepideak(:,1),errepideak(:,2))
    hold on
    %%plotak egin
    title('n1-eko gidariak')
    xlabel('km');
    ylabel('km/h');
    legend('gidaria1','gidaria2') 
    %%grafikoen parrametroak identifikatu
    end
    id=id+1;
    %%plotak banatu
     title('a1-eko gidariak')
    xlabel('km');
    ylabel('km/h');
end
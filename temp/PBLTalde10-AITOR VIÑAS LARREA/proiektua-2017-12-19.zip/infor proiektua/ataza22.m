for i={'n1','a1'}
    for ii={'driver1','driver2'}
    filename= sprintf('%s-%s-log.csv',i{1},ii{1});
    errepideak=dlmread(filename,',',0,0);
    %%fitxategiak irakurri
    a=mean(errepideak(:,2));
    b=std(errepideak(:,2));
    c=max(errepideak(:,2));
    d=min(errepideak(:,2));
    %%datu estatistikoak kalkulatu
    fprintf('%s:\n Batazbestekoa: %.2f, (desbideratze estandarra: %.2f),\n Max-Min abiadura: [%.2f,%.2f]\n\n',filename,a,b,c,d)
    %%emaitza bistaratu
    end
end
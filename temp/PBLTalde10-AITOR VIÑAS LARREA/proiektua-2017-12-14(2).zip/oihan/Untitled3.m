for i={'n1','a1'}
    filename= sprintf('%s-height.csv',i{1})
    errepideak=dlmread(filename,',',1,0);
    a=mean(errepideak(:,3));
    b=std(errepideak(:,3));
    c=max(errepideak(:,3));
    d=min(errepideak(:,3));
    fprintf('%s=\n Batazbestekoa: %f.2, (desbideratze estandarra: %f.2),\n Maxiamoa: %f.2, Minimoa: %f.2\n\n',filename,a,b,c,d)
end
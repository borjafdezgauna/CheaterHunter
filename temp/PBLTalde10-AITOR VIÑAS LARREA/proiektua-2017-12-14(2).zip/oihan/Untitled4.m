for i={'n1','a1'}
    for ii={'driver1','driver2'}
    filename= sprintf('%s-%s-log.csv',i{1},ii{1});
    errepideak=dlmread(filename,',',0,0);
    denbora=estimateTime( errepideak(:,1), errepideak(:,2), 1000);
    denboraguztira=toHMS( denbora );
    end
    fprintf('%s ibilbidean %s-ek behar duen //Estimated time for driver1 in route n1:',filename,mean,std,max,min)
end
    
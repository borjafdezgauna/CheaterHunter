for i={'n1','a1'}
    for ii={'driver1','driver2'}
    filename= sprintf('%s-%s-log.csv',i{1},ii{1});
    errepideak=dlmread(filename,',',0,0);
    denbora=estimateTime( errepideak(:,1), errepideak(:,2),10000);
    denboraguztira=toHMS( denbora );
    fprintf('%s ibilbidean %s-ek behar duen denbora: %s\n',i{1},ii{1},denboraguztira)
    end
end
    
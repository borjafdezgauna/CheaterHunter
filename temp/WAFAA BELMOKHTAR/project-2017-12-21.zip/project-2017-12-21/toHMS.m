% en esta funci�n obtenemos un valor determinado de tiempo en segundos y lo
% que hacemos es pasarlo a un formato de horas-minutos-segundos llamando a
% la funcion toHMS
function [ hms ] = toHMS( seconds ) 
hours = fix(seconds/3600);
minuts =  fix(rem(seconds,3600)/60);
secondsfinal = fix(rem(seconds,60));
hms = fprintf('=>%2d:%2d:%2d',hours,minuts,secondsfinal); 
end


function [estimatedTime] = estimateTime( kms, speedKmH, numSlices)

kms = toMeters (kms);
speedKmH = toMetersPerSecond (speedKmH);

d = ((kms(end) - kms(1))/numSlices);
tiempo = 0;

for km = linspace(kms (1), kms (end), numSlices)
    v = interpolateLinearly(kms, speedKmH, km);
    tiempo_tramo = (d/v);
    tiempo = tiempo + tiempo_tramo;

 estimatedTime = tiempo;
end 
end

function [ interpolatedY ] = interpolateToTheLeft(xVector,yVector ,x)
i=length(xVector);
  while xVector(i)>x
   i=i-1;
  end
interpolatedY=yVector(i);
    
end 


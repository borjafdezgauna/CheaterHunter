
function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)

    i = 1;
     while ( i< length(xVector) && xVector( i ) < x )
            
            i = i + 1;
     end

      if ( i == 1 )
    
     interpolatedY = yVector(1) + (x - xVector(1))* ((yVector(2)-yVector(1))/ (xVector(2)-xVector(1)));
  
   
      else
     interpolatedY = yVector(i-1) + (x - xVector(i-1))* ((yVector(i)-yVector(i-1))/ (xVector(i)-xVector(i-1)));
      
      end
end


 
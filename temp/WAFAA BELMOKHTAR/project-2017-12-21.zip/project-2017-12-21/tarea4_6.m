for route = {'n1', 'a1' }
    siguiente = 1;
    for driver = {'driver1', 'driver2'}
        archivo1 = sprintf('%s-%s-log.csv', route {1}, driver{1});
        archivo2 = dlmread (archivo1,',',1,0);
        seconds = estimateTime(archivo2(:,1),archivo2(:,2),1000);
        tiempo_final =toHMS(seconds);
        fprintf('Estimated time for %s in route %s: %s\n', driver{1},route{1},tiempo_final);
        siguiente = siguiente +1;
    end
  
end

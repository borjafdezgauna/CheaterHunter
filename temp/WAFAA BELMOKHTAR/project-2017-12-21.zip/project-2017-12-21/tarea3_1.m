
fprintf('####### MEN� ########:\n1. Muestra las graficas y estadisticas de las rutas\n2. Muestra las graficas y estadisticas de los conductores\n3. Calculos de tiempo para cada conductor y ruta\n4. Comprobar los limites de velocidad\n5. Calculo de consumo de combustible para cada conductor y ruta\n6. Salir\n ');
numero = input('Elige una opci�n: ');
if (numero >=1 || numero <6)
while (numero ~=6)
  clear
  clc
    switch numero
        case 1
           saveas (gcf, '1_1.png')
           run(tarea1_2.m)
        case 2
            saveas (gcf, '2_1.png')
            run(tarea2_2.m)
        case 3
            run(tarea4_6.m)
        case 4
            disp('tarea en proceso...')
        case 5 
            disp('tarea en proceso...')
    end
end
 else
    fprintf('Opcion incorrecta: debe ser un valor entre 1 y 6');
end

a=dlmread('a1-height.csv',',',1,0);
alturaMedia1=mean(a(:,3));
desviacioEstandar=std(a(:,3));
minimo=min(a(:,3))% si funciona
maximo=max(a(:,3))% si funciona

fprintf('Altura media:% S''(sd:% S)'\n''Rango de las alturas) % s,% s]',alturaMedia1,desviacioEstandar,minimo,maximo)% esta mierda no va

b=dlmread('n1-height.csv',',',1,0)
alturaMedia2=mean(b(:,3))
desviacioEstandar2=std(b(:,3))% funciona perfectio
minimo2=min(b(:,3))% funciona perfecto
maximo2=max(b(:,3))% funciona perfecto


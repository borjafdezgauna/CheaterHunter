
function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
 if (x>= xVector(1) && x<xVector(2))
   interpolatedY = yVector(1) + ((x-xVector(1))/(xVector(2)-xVector(1)))*(yVector(2)-yVector(1));
 elseif (x>= xVector(2) && x<xVector(3))
      interpolatedY = yVector(2) + ((x-xVector(2))/(xVector(3)-xVector(2)))*(yVector(3)-yVector(2));
 end
 end


 
a = dlmread('a1-driver1-log.csv', ',');
b = dlmread('a1-driver2-log.csv', ',');
distancia_origen1 = a(:,1);
velocidad1 = a(:,2);
distancia_origen2 = b(:,1);
velocidad2 = b(:,2);
subplot(1,2,1)
plot(distancia_origen1,velocidad1, distancia_origen2,velocidad2)
title('Gr�fica Velocidad-Distancia')
xlabel('Distancia al origen (Km)')
ylabel('Velocidad (Km/h)')

c = dlmread('n1-driver1-log.csv', ',');
d = dlmread('n1-driver2-log.csv', ',');
distancia_origen3 = c(:,1);
velocidad3 = c(:,2);
distancia_origen4 = d(:,1);
velocidad4= d(:,2);
subplot(1,2,2)
plot(distancia_origen3,velocidad3, distancia_origen4,velocidad4)
title('Gr�fica Velocidad-Distancia')
xlabel('Distancia al origen (Km)')
ylabel('Velocidad (Km/h)')


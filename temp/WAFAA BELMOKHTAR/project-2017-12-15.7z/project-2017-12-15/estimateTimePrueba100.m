

function [ estimatedTime ] = estimateTimePrueba100( kms, speedKmH, numSlices)
xVector = toMeters(kms);
yVector = toMetersPerSecond (speedKmH);

distancia_tramo = ((kms(length(kms))- kms(1))/numSlices);
longitud_total = length(kms);
t_total=0;
x = distancia_tramo; 

while ( x>= 0 && x<= xVector (longitud_total))
    v = interpolateLinearlyPrueba2(xVector,yVector, x);
    x = x + distancia_tramo;
    tiempo_tramo = (distancia_tramo /v);
    t_total = t_total + tiempo_tramo;
end
estimatedTime = t_total;
end 
%Dada una cantidad de kil�metros, devuelva el n�mero equivalente de metros:
function [ m ] = toMeters( km )
m = 1000*km;
end
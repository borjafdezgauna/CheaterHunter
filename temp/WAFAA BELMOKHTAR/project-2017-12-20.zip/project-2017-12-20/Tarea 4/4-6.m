
a=dlmread('a1-driver1-log.csv',',',1,0);
numSlices=  1000;
xVector = (a(:,1));
yVector = (a(:,2));
seconds = estimateTime(xVector,yVector,numSlices);
b=toHMS(seconds);
fprintf('Estimated time for driver1 in route a1: %s', b);

a2=dlmread('a1-driver2-log.csv',',',1,0);
numSlices=  1000;
seconds = estimateTime((a2(:,1)),(a2(:,2)),numSlices);
b=toHMS(seconds);
fprintf('Estimated time for driver2 in route a1: %s', b);

n1=dlmread('n1-driver1-log.csv',',',1,0);
numSlices=  1000;
seconds = estimateTime((n1(:,1)),(n1(:,2)),numSlices);
b=toHMS(seconds);
fprintf('Estimated time for driver1 in route n1: %s', b);

n2=dlmread('n1-driver2-log.csv',',',1,0);
numSlices=  1000;
seconds = estimateTime((n2(:,1)),(n2(:,2)),numSlices);
b=toHMS(seconds);
fprintf('Estimated time for driver2 in route n1: %s', b);
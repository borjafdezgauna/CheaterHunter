
numero = input('introduce el valor deseado: ');
if (numero>1 || numero <6)
    switch numero
        case 1
           saveas (gcf, '')
           run(tarea1_2bien.m)
            
        case 2
            run(tarea2_2bien.m)
        case 3
            saveas (gcf, '')
        case 4
            
        case 5
            
        case 6
            
        
else
    fprintf('Opcion incorrecta: debe ser un n�mero entre 1 y 6');
end
  

   


  
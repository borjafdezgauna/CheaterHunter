function []=miMediaa(x)
        s=x(1); 
            for i=2:n 
                s=s+x(i); 
            end
end
                
                
                
                
    
function[x]=miMedia(y)
    for i=length(y)
        miMedia=(sum(i))/length(y);
    end
end
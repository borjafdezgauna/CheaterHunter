clear
clc
fprintf('####### MEN� ########:\n1. Muestra las graficas y estadisticas de las rutas\n2. Muestra las graficas y estadisticas de los conductores\n3. Calculos de tiempo para cada conductor y ruta\n4. Comprobar los limites de velocidad\n5. Calculo de consumo de combustible para cada conductor y ruta\n6. Salir\n ');
numero = input('Elige una opci�n: ')
if (numero >=1 || numero <6)
while (numero ~=6)
    switch
        case 1
           saveas (gcf, '1.1.jpg')
           run(tarea1_2bien.m)
            
        case 2
            saveas (gcf, '2.1.jpg')
            run(tarea2_2bien.m)
        case 3
            
        case 4
            
        case 5              
end
 else
    fprintf('Opcion incorrecta: debe ser un valor entre 1 y 6');
end

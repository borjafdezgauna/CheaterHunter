function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
kms= linspace(kms(1),kms(length(kms)),numSlices);
t_total=0;
for i= 1:length(kms)
    v = interpolateLinearly(kms,speedKmH,kms(i));
    d = ((kms(length(kms))- kms(1))/numSlices);
    t = (d / v);
    t_total = t_total + t;  
end
estimatedTime = t_total;
end
function [ m ] = toMeters( km )
  km*1000             %escribimos la funcion para pasar de km a m (*1000)
end
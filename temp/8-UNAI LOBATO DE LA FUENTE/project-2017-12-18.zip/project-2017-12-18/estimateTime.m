function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
  

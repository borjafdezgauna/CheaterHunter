function [ msSpeed ] = toMetersPerSecond( speedKmH )
  speedKmH/3.6                %escribimos la funcion para pasar de kmh a ms
end
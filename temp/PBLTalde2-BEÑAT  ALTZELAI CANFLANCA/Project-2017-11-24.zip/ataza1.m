for num={'a1','n1'}
file=sprintf('%s-height.csv',num{1});
datuak=dlmread(file, ',',1,0);
subplot (1,2,1);
  hold on
  plot (datuak(:,4),datuak(:,3))
    title('A1 eta N1-eko altuerak')
    xlabel('Distantzia (km)')
    ylabel('Altitudea (m)')
subplot (1,2,2);
  hold on
  plot (datuak(:,2),datuak(:,1))
    title('A1 eta N1-eko ibilbideak')
    xlabel ('Longitudea')
    ylabel ('Latitudea')


Altitudea=mean(datuak(:,3));
DesbEst=std(datuak(:,3));
AltMin=min(datuak(:,3));
AltMax=max(datuak(:,3));
fprintf('%s bideko estatistikak:\n Batez besteko altitudea: %.2f (Desbiderazio estandarra: %.2f)\n' ,num{1}, Altitudea, DesbEst)
fprintf(' Altuera minimoa: %.2f\n Altuera maximoa: %.2f\n', AltMin, AltMax)

end 
saveas(gcf,'route-elevations.png')
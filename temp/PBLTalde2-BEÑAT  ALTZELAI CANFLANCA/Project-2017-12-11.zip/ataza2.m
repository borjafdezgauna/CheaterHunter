irudiZenb = 1;

for num={'a1','n1'}

  subplot(1,2,irudiZenb);

  for gid=1:2
      file=sprintf('%s-driver%d-log.csv',num{1},gid);

        datuak=dlmread(file, ',');
        hold on
      plot(datuak(:,1),datuak(:,2));
        xlabel('Distantzia (km)')
        ylabel('Abiadura (km/h)')
        title(sprintf('%s bideko abiadurak 2 gidarientzat',num{1}))
        
        Abiadura=mean(datuak(:,2));
        DesbEst=std(datuak(:,2));
        AbiaMin=min(datuak(:,2));
        AbiaMax=max(datuak(:,2));
fprintf('%d gidariaren estatistikak %s bidean:\n Batez besteko abiadura: %.2f (Desbiderazio estandarra: %.2f)\n' ,gid, num{1}, Abiadura, DesbEst)
fprintf(' Abiadura minimoa: %.2f\n Abiadura maximoa: %.2f\n\n', AbiaMin, AbiaMax)
end 

irudiZenb=2;
legend('1.Gidaria','2.Gidaria')

end

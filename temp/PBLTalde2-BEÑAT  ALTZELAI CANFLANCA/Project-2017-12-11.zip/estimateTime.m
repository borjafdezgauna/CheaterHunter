function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
  estimatedTime=0
  m  = toMeters(kms)
  bukaera=m(1,end)
  aldakuntza_t=bukaera/numSlices
   msSpeed = toMetersPerSecond( speedKmH );
 
for i=1:numSlices
  t=(i-1)*aldakuntza_t;
  interpolatedY=interpolateLinearly(m,msSpeed,t)
  estimatedTime= estimatedTime + interpolatedY/aldakuntza_t;
  end
  disp(estimatedTime)
  end
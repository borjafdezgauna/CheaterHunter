%% Errepideen fitxategietako datu guztiak jaso %%
file={'n1-height.csv','a1-height.csv'};
%% ----------- Grafikoak ------------- %%

%%-------ALTUERA------%%

for i=file
Errepideak_info=dlmread(i{1},',',1,0);
subplot(1,2,1)
plot (Errepideak_info(:,4), Errepideak_info(:,3));
hold on
end
title('Errepideen profila');
xlabel ('Distantzia KM');
ylabel ('Altuera M');
legend ('N1', 'A1')

%%------IBILBIDEA ------%
for i=file
Errepideak_info=dlmread(i{1},',',1,0);
subplot (1,2,2)
plot (Errepideak_info(:,1),Errepideak_info(:,2));
hold on
end
title('Ibilbideak');
xlabel('Latitudea');
ylabel('Longitudea');
legend ('N1', 'A1')

%%  Estadistikak kalkulatu  %%
for Errepide_Izena= {'n1', 'a1'}
fitxategia= sprintf ('%s-height.csv',Errepide_Izena{1});
Errepideak_info=dlmread(fitxategia,',',1,0);
Batazbestekoa_altuera = mean(Errepideak_info(:,3)); 
Desbiderapena = std (Errepideak_info(:,3));
Max_altuera = max(Errepideak_info(:,3));
Min_altuera = min(Errepideak_info(:,3));  

%%Estadistikak pantailaratu%%
fprintf ('%s route statistics:\n Mean height: %.2f    (sd: %.2f)\n Heigth range: [%.2f , %.2f]\n\n',Errepide_Izena{1}, Batazbestekoa_altuera,Desbiderapena ,Min_altuera, Max_altuera);
end

 

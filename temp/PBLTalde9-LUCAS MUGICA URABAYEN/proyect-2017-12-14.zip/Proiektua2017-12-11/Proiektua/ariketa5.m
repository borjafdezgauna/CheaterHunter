for gidaria={'driver1','driver2'}
    
   fitxategia = sprintf('a1-%s-log.csv', gidaria{1});
   kmsDatuak=dlmread('a1-speed-limit.csv',';');
   limitKms=kmsDatuak(:,1);
   limitSpeeds=kmsDatuak(:,2);
   datuak=dlmread(fitxategia,',');
   driverLogKm=datuak(:,1);
   driverLogSpeed=datuak(:,2);
   numSlices=10000;
   
  [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices);
  
   if percentAboveSpeedLimit>=10
   arriskua= sprintf('HIGH INFRACTION RISK') ;
     fprintf('Analyzing:  Driver= %s, Route= a1\n %s: Kms above the speed limit=%.02f (%.02f%% of the route)\n\n',gidaria{1},arriskua,kmsAboveSpeedLimit,percentAboveSpeedLimit );
   elseif percentAboveSpeedLimit<10 && percentAboveSpeedLimit>0
       arriskua=sprintf('Mild infraction risk');
         fprintf('Analyzing:  Driver= %s, Route= a1\n %s: Kms above the speed limit=%.02f (%.02f%% of the route)\n\n',gidaria{1},arriskua,kmsAboveSpeedLimit,percentAboveSpeedLimit );
   else 
      
         fprintf('Analyzing:  Driver= %s, Route= a1\n No risk of infraction\n\n',gidaria{1});
 
   end
end
for gidaria={'driver1','driver2'}
   fitxategia = sprintf('n1-%s-log.csv', gidaria{1});
   kmsDatuak=dlmread('n1-speed-limit.csv',';');
   limitKms=kmsDatuak(:,1);
   limitSpeeds=kmsDatuak(:,2);
   datuak=dlmread(fitxategia,',');
   driverLogKm=datuak(:,1);
   driverLogSpeed=datuak(:,2);
   numSlices=10000;
   
  [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices);
  
   if percentAboveSpeedLimit>=10
   arriskua= sprintf('High infraction risk') ;
     fprintf('Analyzing:  Driver= %s, Route= n1\n %s: Kms above the speed limit=%.02f (%.02f%% of the route)\n\n',gidaria{1},arriskua,kmsAboveSpeedLimit,percentAboveSpeedLimit );
   elseif percentAboveSpeedLimit<10 && percentAboveSpeedLimit>0
       arriskua=sprintf('Mild infraction risk');
         fprintf('Analyzing:  Driver= %s, Route= n1\n %s: Kms above the speed limit=%.02f (%.02f%% of the route)\n\n',gidaria{1},arriskua,kmsAboveSpeedLimit,percentAboveSpeedLimit );
   else 
      
         fprintf('Analyzing:  Driver= %s, Route= n1\n No risk of infraction\n\n',gidaria{1});
 
   end
   
end
input('sakatu enter programa amaitzeko');
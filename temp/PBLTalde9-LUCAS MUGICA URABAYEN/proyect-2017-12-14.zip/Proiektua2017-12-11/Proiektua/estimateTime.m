function [estimatedTime]=estimateTime(kms,speedKmH,numSlices)
  estimatedTimeOrdu=0;
  distantzia = (kms(end) -kms(1))/numSlices;
  for x = linspace(kms(1), kms(end), numSlices)
    [interpolatedAbiadura]=interpolateLinearly(kms,speedKmH,x);
    if interpolatedAbiadura==0
      denbora=0;
    else
    denbora=distantzia/interpolatedAbiadura;
   end
   estimatedTimeOrdu=estimatedTimeOrdu+denbora;
   
    end
     estimatedTime=estimatedTimeOrdu*3600;
    
    end
    
    
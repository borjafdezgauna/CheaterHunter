clear 
clc
opcion=input('#######MENU#######\n1. Muestra las graficas y estadisticas de las rutas\n2. Muestra las graficas y estadisticas de los conductores\n3. Calculos de tiempo para cada conductor y ruta\n4. Comprobar los limites de velocidad\n5. Calculo de consumo de combustible para cada conductor y ruta\n6. Salir\nElige una opcion:\n');
while opcion~=6
    if opcion<1 || opcion>6
    disp('Opcion incorrecta: debe ser un n�mero entre 1 y 6')
    elseif opcion=1 
    elseif opcion=2
    elseif opcion=3
    elseif opcion=4
    elseif opcion=5
    end
opcion=input('#######MENU#######\n1. Muestra las graficas y estadisticas de las rutas\n2. Muestra las graficas y estadisticas de los conductores\n3. Calculos de tiempo para cada conductor y ruta\n4. Comprobar los limites de velocidad\n5. Calculo de consumo de combustible para cada conductor y ruta\n6. Salir\nElige una opcion:\n');
end
%Tarea 1: 1) Graficas de las alturas de ambas rutas y guardar la imagen.

clear
clc


datos_a1=dlmread('datos/a1-height-corregido.csv');
datos_n1=dlmread('datos/n1-height-corregido.csv');

subplot(1,2,1)
plot(datos_a1(:,4),datos_a1(:,3))
    xlabel('Distancia (km)')
    ylabel('Altura (m)')
    title('Alturas A-1')
    
subplot(1,2,2)
plot(datos_n1(:,4),datos_n1(:,3))
    xlabel('Distancia (km)')
    ylabel('Altura (m)')
    title('Alturas N-1')

print('route-elevations','-dpng')   


%Tarea 1: 2) Calcular y mostrar como texto media, desviaci�n estandard,
%            elevaci�n m�xima y m�nima.

%Estadisticas A-1

altitudes_a1=datos_a1(:,3);
suma_alturas_a1=sum(altitudes_a1);
num_datos_a1=length(altitudes_a1);
media_alturas_a1=suma_alturas_a1/num_datos_a1;
desviacion_alturas_a1=std(altitudes_a1);
valor_min_a1=min(altitudes_a1);
valor_max_a1=max(altitudes_a1);

fprintf('Estad�sticas de la ruta A-1:\n');
fprintf('Altura media: %.2f (sd: %.2f)\n',media_alturas_a1,desviacion_alturas_a1);
fprintf('Rango de alturas:[%.2f, %.2f]\n',valor_min_a1,valor_max_a1);


%Estadisticas N-1

altitudes_n1=datos_n1(:,3);
suma_alturas_n1=sum(altitudes_n1);
num_datos_n1=length(altitudes_n1);
media_alturas_n1=suma_alturas_n1/num_datos_n1;
desviacion_alturas_n1=std(altitudes_n1);
valor_min_n1=min(altitudes_n1);
valor_max_n1=max(altitudes_n1);

fprintf('\nEstad�sticas de la ruta N-1:\n');
fprintf('Altura media: %.2f (sd: %.2f)\n',media_alturas_n1,desviacion_alturas_n1);
fprintf('Rango de alturas:[%.2f, %.2f]\n',valor_min_n1,valor_max_n1);


    
    
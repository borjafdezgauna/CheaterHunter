clear
clc

t=0;
v=[10 20];
x=[1 2];
c=0;

for i=1:length(x)
    t=((x(i)-c)/v(i))+t;
    c=x(i);
    %mins=t*60;
end
mins=t*60
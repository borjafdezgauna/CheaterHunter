function [estimateTime]=estimateTime(kms,speedKmH,numSlices)

    for i=1:length(kms)
        for j=1:numSlices
            interpolateLinearly(kms,speedKmH,j) %Mal, incompleto
            
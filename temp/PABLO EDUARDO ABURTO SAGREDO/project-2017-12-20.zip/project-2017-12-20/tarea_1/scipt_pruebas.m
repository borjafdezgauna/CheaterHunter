subplot(1,2,1)
plot(datos_a1(:,4),datos_a1(:,3))
    xlabel('Distancia (km)')
    ylabel('Altura (m)')
    title('Alturas A-1')
    
subplot(1,2,2)
plot(datos_n1(:,4),datos_n1(:,3))
    xlabel('Distancia (km)')
    ylabel('Altura (m)')
    title('Alturas N-1')
    
    
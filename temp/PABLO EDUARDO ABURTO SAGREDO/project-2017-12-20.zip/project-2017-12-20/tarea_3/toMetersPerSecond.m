function[msSpeed]=toMetersPerSecond(speedKmH)

%Funcion para pasar de Km/h a m/s .

    msSpeed=speedKmH./3.6;
end
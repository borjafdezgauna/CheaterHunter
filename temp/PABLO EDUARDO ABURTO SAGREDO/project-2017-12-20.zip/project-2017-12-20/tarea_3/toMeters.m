function [m]=toMeters(km)

%Funcion para pasar de kilometros a metros.

    m=km.*1000;
end

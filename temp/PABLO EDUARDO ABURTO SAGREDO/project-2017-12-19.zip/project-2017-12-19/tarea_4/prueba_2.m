
clear
clc

velocidades=[40 50 40 30];
speedKmH=toMetersPerSecond(velocidades);
numSlices=1000;
kms=[0 1000 2000 3000];

t=0;
x=1:length(speedKmH);
d=0;

for i=linspace(0,length(speedKmH),numSlices+1)
    if i~=0
    velocidad=interpolateLinearly(x,speedKmH,i);
    distancia=interpolateLinearly(x,kms,i);
    t=(distancia/velocidad)+t;
    end
end
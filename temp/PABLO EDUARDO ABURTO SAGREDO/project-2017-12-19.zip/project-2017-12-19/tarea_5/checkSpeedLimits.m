function [kmsAboveSpeedLimit,percentAboveSpeedLimit]=checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)


for i=length(driverLogKm)
    if driverLogKm(i)>=0 && driverLogKm(i)<limitSpeeds(2,1)
        limite_velocidad=interpolateToTheLeft(limitKms,limitSpeeds,driverLogKm(i));
        j=i-1;
        if driverLogSpeed(i)>limite_velocidad
            distancia=driverLogKm(i)-driverLogKm(j)+distancia;
        end
    elseif driverLogKm(i)>=limitSpeeds(2,2) && driverLogKm(i)<limitSpeeds(2,3)
        limite_velocidad=interpolateToTheLeft(limitKms,limitSpeeds,driverLogKm(i));
        j=i-1;
        if driverLogSpeed(i)>limite_velocidad
            distancia=driverLogKm(i)-driverLogKm(j)+distancia;
        end
    else 
        limite_velocidad=limitSpeeds(length(limitSpeeds));
        j=i-1;
        if driverLogSpeed(i)>limite_velocidad
            distancia=driverLogKm(i)-driverLogKm(j)+distancia;
          end
    end
end
            
clc
fprintf('####### MENU ########:\n1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit\n')
OPTION=input('Choose an option:');
if isinteger(OPTION) && OPTION>=1 && OPTION<=6
    elseif OPTION==1 
        clc
        TASK1
        input('Press any key to continue','s');
        TASK3
    elseif OPTION==2
        clc
        TASK2
        input('Press any key to continue','s');
        TASK3
    elseif OPTION==3 
        clc
        TASK4
        input('Press any key to continue','s');
        TASK3
    elseif OPTION==4 
        clc
        TASK5
        input('Press any key to continue','s');
        TASK3
    elseif OPTION==5 
        clc
        TASK6
        input('Press any key to continue','s');
        TASK3
    elseif OPTION==6 
        clc
else
    fprintf('Incorrect option: it must be  between 1 and 6')
end
    
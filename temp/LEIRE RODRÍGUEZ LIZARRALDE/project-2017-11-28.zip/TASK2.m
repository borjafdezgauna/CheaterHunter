%Read the files
hold off
for num=1:2
    filename1=sprintf('a1-driver%d-log.csv',num);
    routea1=dlmread(filename1,','); 
    distancea1=routea1(:,1);
    speeda1=routea1(:,2);
    
    subplot(1,2,1)
    plot(distancea1,speeda1)
    xlabel('distance(km)')
    ylabel('speed(km/h)')
    title('routeA1')
    hold on
    Meana1=mean(speeda1);
    SdDeviationa1=std(speeda1);
    Maxa1=max(speeda1);
    Mina1=min(speeda1);
    fprintf('driver%d statistics in route a1:\nMean speed:%02f(sd:%02f)\nMin-Max speed: [%02f,%02f]\n\n',num,Meana1,SdDeviationa1,Mina1,Maxa1);
    
end
legend('driver1','driver2')
for num=1:2
    filename2=sprintf('n1-driver%d-log.csv',num);
    routen1=dlmread(filename2,',');
    distancen1=routen1(:,1);
    speedn1=routen1(:,2);
    subplot(1,2,2)
    plot(distancen1,speedn1)
    xlabel('distance(km)')
    ylabel('speed(km/h)')
    title('routeN1')
    hold on
    Meann1=mean(speedn1);
    SdDeviationn1=std(speedn1);
    Maxn1=max(speedn1);
    Minn1=min(speedn1);
    fprintf('driver%d statistics in route n1:\nMean speed:%02f(sd:%02f)\nMin-Max speed: [%02f,%02f]\n\n',num,Meann1,SdDeviationn1,Minn1,Maxn1);
end
legend('driver1','driver2')
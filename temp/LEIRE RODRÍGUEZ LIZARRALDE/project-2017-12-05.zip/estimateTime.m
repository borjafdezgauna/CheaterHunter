function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
Slices=linspace(kms(:,1),kms(:,length(kms)),numSlices)
for slices=Slices
interpolatedY(kms,speedKmH,slices)
end



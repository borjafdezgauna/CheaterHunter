SpeedLimita1=dlmread('a1-speed-limit.csv',';');
SpeedLimitn1=dlmread('n1-speed-limit.csv',';') ; 
for num=1:2
    filename1=sprintf('a1-driver%d-log.csv',num);
    routea1=dlmread(filename1,','); 
    distancea1=routea1(:,1);
    speeda1=routea1(:,2);
    [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( distancea1, speeda1, SpeedLimita1(:,1), SpeedLimita1(:,2), 10000)
    fprintf('Analysing: Driver= driver%d, Route= n1\nMild infraction risk')
end
for num=1:2
    filename2=sprintf('n1-driver%d-log.csv',num);
    routen1=dlmread(filename2,',');
    distancen1=routen1(:,1);
    speedn1=routen1(:,2);
    [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( distancen1, speedn1, SpeedLimitn1(:,1), SpeedLimitn1(:,2), 10000)
end


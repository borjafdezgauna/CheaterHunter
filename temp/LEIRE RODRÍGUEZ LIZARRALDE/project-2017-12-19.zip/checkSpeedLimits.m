function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
Slices=linspace(driverLogKm(1),driverLogKm(end),numSlices);
lengthslices=(driverLogKm(end)-driverLogKm(1))/numSlices;
         kmsAboveSpeedLimit=0;
         for km=Slices
      %speed
        Speed=interpolateLinearly(driverLogKm,driverLogSpeed,km);
        SpeedLimit=interpolateToTheLeft(limitKms,limitSpeeds,km);

    if Speed>SpeedLimit
        kmsAboveSpeedLimit=kmsAboveSpeedLimit+1;
    end
    end

percentAboveSpeedLimit=(kmsAboveSpeedLimit*100)/driverLogKm(end)
end
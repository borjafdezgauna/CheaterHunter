for num=1:2
    filename2=sprintf('n1-driver%d-log.csv',num);
    routen1=dlmread(filename2,',');
    distancen1=routen1(:,1);
    speedn1=routen1(:,2);
    Time=estimateTime( distancen1, speedn1, 10000);
    Timen1=toHMS(Time);
    fprintf('Estimated time for driver%d in routen1: %s\n',num,Timen1)
end
 for num=1:2
    filename1=sprintf('a1-driver%d-log.csv',num);
    routea1=dlmread(filename1,','); 
    distancea1=routea1(:,1);
    speeda1=routea1(:,2);  
    TIME=estimateTime( distancea1, speeda1, 10000);
    TIMEa1=toHMS(TIME);
    fprintf('Estimated time for driver%d in routea1: %s\n',num,TIMEa1)
end
function [estimatedTime] = estimateTime( kms, speedKmH, numSlices)
Slices=linspace(kms(1),kms(end),numSlices);
lengthslices=(kms(end)-kms(1))./numSlices;
estimatedTime=0;
for slices=Slices
      %speed
    Speed=interpolateLinearly(kms,speedKmH,slices);
    if Speed~=0
        Time=lengthslices(:,1)/Speed;
    else 
    Time=0;
     end
    estimatedTime=estimatedTime+Time;
   
end
estimatedTime=estimatedTime*3600;
end
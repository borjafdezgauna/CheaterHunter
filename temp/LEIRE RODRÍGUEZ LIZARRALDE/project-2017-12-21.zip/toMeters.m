%METERSTOKM
function [ m ] = toMeters( km )
m=km*1000;
end
%We use this simple funciton so we can calculate easily distance calculated in 
%meters to kilometers.
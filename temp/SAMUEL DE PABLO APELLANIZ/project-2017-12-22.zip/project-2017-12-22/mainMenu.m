clc
script
while x>=1 && x<=6
  if x==1
  heights
   disp('Press any key to continue')
     pause
  clc
  script
 elseif x==2
  speeds
   disp('Press any key to continue')
     pause
  clc
  script
 elseif x==3
     timesroutes
     disp('Press any key to continue')
     pause
     clc
  script
 elseif x==4
      disp('Press any key to continue')
     pause
     clc
  script
 elseif x==5
      disp('Press any key to continue')
     pause
     clc
 script
  else
    x=a; 
    % I did this because as we put number 6 inside the "while", so that we
    % make the loop end
  end
end
 if x==a
     disp('exit')
 else
  sprintf('incorrect option: it must be between 1 and 6')
 end
 
  
  
  
  
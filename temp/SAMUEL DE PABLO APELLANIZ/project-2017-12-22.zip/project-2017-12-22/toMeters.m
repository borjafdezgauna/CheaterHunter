function [ m ] = toMeters( km )
  m=km*1000
  end
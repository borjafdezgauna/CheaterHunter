function [ hms ] = toHMS( seconds )
  
  secs=rem(seconds,60);
  m=fix(seconds/60);
  mins=rem(m,60);
  hours=fix(m/60);
  
  sprintf('%02d:%02d:%02d', hours, mins, secs)
  end
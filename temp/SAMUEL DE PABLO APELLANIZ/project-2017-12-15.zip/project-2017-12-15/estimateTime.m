function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)

duration=length(kms);
delta_km=duration/numSlices;


for i=1:numSlices
  km= (i-1)*delta_km;
  estimatedSpeed= interpolateLinearly(length(kms),length(speedKmH),km);
  estimatedTime= delta_km/estimatedSpeed
end
    end
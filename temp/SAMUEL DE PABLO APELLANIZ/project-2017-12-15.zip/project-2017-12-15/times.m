
    a1driver1=dlmread('project-files/a1-driver1-log.csv',',');
    a1driver2=dlmread('project-files/a1-driver2-log.csv',',');
    n1driver1=dlmread('project-files/n1-driver1-log.csv',',');
    n1driver2=dlmread('project-files/n1-driver2-log.csv',',');

timea= estimateTime(a1driver1(:,1),a1driver1(:,2),length(a1driver1(:,1)))
timeb= estimateTime(a1driver2(:,1),a1driver2(:,2),length(a1driver2(:,1)))
timec= estimateTime(n1driver1(:,1),n1driver1(:,2),length(n1driver1(:,1)))
timed= estimateTime(n1driver2(:,1),n1driver2(:,2),length(n1driver2(:,1)))


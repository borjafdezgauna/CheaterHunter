clc
mainMenu
while x>=1 && x<=6
  sprintf('incorrect option: it must be between 1 and 6')
 elseif x==1
  heights
  clc
  mainMenu
 elseif x==2
  speeds
  clc
  mainMenu
 elseif x==3
  mainMenu
 elseif x==4
  mainMenu
 elseif x==5
  mainMenu
 elseif x==6
  fprintf('exit')
 end
 
  
  
  
  
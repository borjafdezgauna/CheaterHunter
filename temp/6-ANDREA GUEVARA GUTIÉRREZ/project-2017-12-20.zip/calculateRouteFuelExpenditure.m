function [ fuelExpenditure ] =
calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,num
Slices )


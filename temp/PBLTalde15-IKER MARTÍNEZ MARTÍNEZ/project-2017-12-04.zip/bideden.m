function [ denbora ] = bideden(distantziak,abiadurak,tarteak)
distantziak=KmtoM(distantziak);
abiadurak=KmstoMs(abiadurak);
diferentzia=distantziak(length(distantziak))/tarteak;
denbora=0;
for i=0:diferentzia:distantziak(length(distantziak))
v=interpolazioa(distantziak,abiadurak,i);
if v==0
 t=0; 
else
  t=diferentzia/v;
end
denbora=denbora+t;
end
end
function [ metroak ] = KmtoM( kilometroak)
metroak=kilometroak*1000;
end


function x=MenuZenbakia(MenuOption)
if MenuOption==1 || MenuOption==2 || MenuOption==3 || MenuOption==4 || MenuOption==5 || MenuOption==6
x=MenuOption;
else
fprintf('�Aukera ezegokia: 1 eta 6 artean egon behar da�\n')
x=0;
end
end
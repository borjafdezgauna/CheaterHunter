%%funtzio honek kilometroak metrotan bihurtzen ditu

function [ metroak ] = toMeters( kilometroak)
metroak=kilometroak*1000;
end


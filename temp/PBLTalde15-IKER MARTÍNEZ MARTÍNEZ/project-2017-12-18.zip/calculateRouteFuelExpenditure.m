function  [ fuelExpenditure ] =calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices )
routeMs= KmtoM(routeKms);
logMs= KmtoM(logKms);
logSpeeds=KmstoMs(logSpeeds);
diferentzia=logMs(end)/numSlices;
fuelExpenditure=0;
for i=linspace(logMs(1),logMs(end),numSlices)
    if i~=0
    vf=interpolazioa(logMs,logSpeeds,i);
    v0=interpolazioa(logMs,logSpeeds,i-0.001);
    t=0.001/((vf+v0)/2);
    a=(vf-v0)/t;
    altAldaketa=interpolazioa(routeMs,routeHeights,i)-interpolazioa(routeMs,routeHeights,i-diferentzia);
    theta=asin(altAldaketa/diferentzia);
    Kontsumoa=calculateFuelExpenditure(vf,a,theta,diferentzia);
    fuelExpenditure=fuelExpenditure+Kontsumoa;
    end
end
end


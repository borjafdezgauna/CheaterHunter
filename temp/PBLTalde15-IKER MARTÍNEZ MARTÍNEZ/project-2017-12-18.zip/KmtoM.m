%%funtzio honek kilometroak metrotan bihurtzen ditu

function [ metroak ] = KmtoM( kilometroak)
metroak=kilometroak*1000;
end


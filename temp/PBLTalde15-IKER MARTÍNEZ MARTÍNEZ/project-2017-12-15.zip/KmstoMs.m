function [ metroseg ] = KmstoMs( kmordu )
metroaordu= KmtoM(kmordu);
metroseg=metroaordu/3600;
end


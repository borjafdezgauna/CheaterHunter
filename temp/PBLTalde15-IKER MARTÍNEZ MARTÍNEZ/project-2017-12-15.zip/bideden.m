function [ denbora ] = bideden(distantziak,abiadurak,tarteak)
distantziak=KmtoM(distantziak);
abiadurak=KmstoMs(abiadurak);
diferentzia=distantziak(length(distantziak))/tarteak;
denbora=0;
for i = linspace(distantziak(1), distantziak(end), tarteak)
v=interpolazioa(distantziak,abiadurak,i);
if v==0
 t=0; 
else
  t=diferentzia/v;
end
denbora=denbora+t;
end
end
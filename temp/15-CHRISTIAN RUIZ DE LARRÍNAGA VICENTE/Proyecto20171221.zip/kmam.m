function metros= kmam(kilometros)
metros=kilometros*1000;
end

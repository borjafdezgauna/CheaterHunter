clc
clear all

kilometros=input('Dame la distancia en kil�metros:');
metros=kmam(kilometros);
fprintf('%.1f kil�metros son %.0f metros\n', kilometros,metros);
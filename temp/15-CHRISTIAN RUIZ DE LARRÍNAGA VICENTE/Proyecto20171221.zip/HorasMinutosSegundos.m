clear all
clc

seconds=input('Dame una cantidad de segundos: ');
hms=toHMS(seconds)



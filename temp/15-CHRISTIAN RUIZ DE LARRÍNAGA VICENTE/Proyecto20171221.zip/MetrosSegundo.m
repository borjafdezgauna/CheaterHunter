function [msSpeed]= MetrosSegundo(kilometroshora)
msSpeed=(kilometroshora*1000/3600);
end

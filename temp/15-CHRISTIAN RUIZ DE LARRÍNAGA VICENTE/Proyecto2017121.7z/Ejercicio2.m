clear all
clc
hold on
for ruta={'n1','a1'}
    subplot(2,1,1)
    f=sprintf('%s-driver1-log.csv',ruta{1});
    a=dlmread(f,',',1,0); %carga el archivo de los datos
    distancia=a(:,1);
    velocidad=a(:,2);
    
    title('conductor 1')
    xlabel('distancia (d)'); %T�tulo para el eje x
    ylabel('velocidad (v)'); %T�tulo para el eje y
    plot(distancia,velocidad);
    hold on  
    
    subplot(2,1,2);
    y=sprintf('%s-driver2-log.csv',ruta{1});
    b=dlmread(y,',',1,0); %carga el archivo de los datos
    distancia2=b(:,1);
    velocidad2=b(:,2);
    hold on

    
    
    title('Conductor2 ');
    xlabel('distancia 2(m)'); %T�tulo para el eje x
    ylabel('velocidad 2'); %T�tulo para el eje y
    plot(distancia2,velocidad2);
   
   
   
    
end
saveas(gcf,'route-elevations.png')

for file={'n1','a1'}
    for i= 1:2
    filename= sprintf ('%s-drive%d-log.csv',file{1}, i);
    data=dlmread(filename,',');
    plot(data(:,1),data(:,2))
    title('Distantzia-Km/h')
    xlabel ('Distantzia(m)')
    ylabel('abiadura(Km/h)')
end
end
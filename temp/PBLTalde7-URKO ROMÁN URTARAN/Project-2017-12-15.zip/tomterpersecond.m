function [msSpeed]= tomterpersecond(abiadura)
msSpeed= abiadura*3;6;
end


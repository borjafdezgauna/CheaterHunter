function [hms] = toHMS(seconds)

   H=floor(seconds/3600); %"floor" coge el entero de los segundos y muestra la hora
   M=floor((seconds-(3600*H))/60); %Da como resultado la hora  
   S=floor(seconds-((H*3600)+(M*60))); %Da como resultado los segundos

  hms=sprintf('%02d:%02d:%02d',H,M,S); %Muestra en pantalla las Horas, Minutos y Segundos

end

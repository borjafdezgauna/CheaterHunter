function [estimatedTime]=estimateTime(kms, speedKmH, numSlices) 
      t=0;
      final=kms(end)-kms(1); %kmfinales menos los iniciales
      inter=final/numSlices; %Utilizando el resultado anterior y el numero de pedazos de integracion interpolar se obtiene el intervalo de Velocidad
      
   for i=kms(1):inter:kms(end) %Recorre todo
      Velo=interpolateLinearly(kms,speedKmH,i); %Interpola el Intervalo de Velocidad
       t=t+toMeters(inter)/toMetersPerSecond(Velo); %Pasa el Intervalo de Velocidad a metros
    end
   estimatedTime=t;
end 
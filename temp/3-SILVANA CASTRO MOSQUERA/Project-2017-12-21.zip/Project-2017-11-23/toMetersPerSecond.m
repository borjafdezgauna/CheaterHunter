function [msSpeed] = toMetersPerSecond(speedKmH)  
    if speedKmH>0 %Si la velocidad es mayor que 0   
        msSpeed=(speedKmH*1000)/3600; %Pasa Km/H a m/s
    end
end    

function [m] = toMeters(km)
  if km>0 %Km mayor que 0
   m=1000*km; %Pasa de Km a m
  end
end 
    
  
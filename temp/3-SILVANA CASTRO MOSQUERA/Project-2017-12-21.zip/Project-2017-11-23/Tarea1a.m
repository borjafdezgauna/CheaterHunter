clc;
clear;
for ruta={'n1','a1'} %Ficheros de las n1(Ruta Nacional 1) y de a1(Ruta Autopista 1)
      fichero=sprintf('%s-height.csv',ruta{1}); %Se alternan los datos de las dos rutas  
      disp(fichero);
      Alturas=dlmread(fichero,',',1,0);%Se cargan los ficheros para n1,a1 
     
      subplot(1,2,1); %Se posiciona la grafica
      hold on  %Se mantiene la grafica en pantalla 
      plot(Alturas(:,4),Alturas(:,3)); %Grafica de Distancia vs Altura
      ylabel('Distancia') %Se nombra el eje Y de la grafica
      xlabel('Altura') %Se nombre el eje X de la grafica
      title('Grafica2') %Titulo de la grafica
      
      subplot(1,2,2); %Se posiciona la matriz de la grafica en pantalla
      plot(Alturas(:,2),Alturas(:,1)); %Grafica de Longitud vs Latitud
      hold on %Se mantiene la grafica en pantalla
      ylabel('Latitud') %Se nombra el eje Y de la grafica
      xlabel('Longitud')  %Se nombre el eje X de la grafica
      title('Grafica1')  %Titulo de la grafica
      
      
end
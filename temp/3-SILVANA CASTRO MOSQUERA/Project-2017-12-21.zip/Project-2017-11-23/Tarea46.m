clc;
clear;
     for ruta={'n1','a1'} %Ficheros de las rutas n1(Nacional 1) y a1(Autopista 1) 
        for conductor={'driver1','driver2'} %Ficheros de los condcutores
          fichero1=sprintf('%s-%s-log.csv',ruta{1},conductor{1});  %Se alternan los datos de los conductores y las rutas
          fichero2=dlmread(fichero1,',',1,0); %Se cargan los ficheros
          tiempo = estimateTime(fichero2(:,1), fichero2(:,2), 1000); %Se calcula el tiempo estimado para cada Conductor y Ruta
          hms = toHMS(tiempo); %Convierte el tiempo estimado a un formato de Hora:Minutos:Segundos          
          fprintf('Tiempo estimado para el %s in la ruta %s: %s\n',conductor{1},ruta{1},hms) %Muestra por pantalla dichos valores
         
        end
      end
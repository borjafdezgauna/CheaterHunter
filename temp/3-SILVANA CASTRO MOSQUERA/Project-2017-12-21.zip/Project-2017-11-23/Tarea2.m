clc;
clear;
 for ruta={'n1','a1'} %Ficheros de las rutas n1(Nacional 1) y a1(Autopista 1)
  lado=1; %3 dato que se va a almacenar en el subplot 
   for conductor={'driver1','driver2'} %Ficheros de los condcutores
      fichero1=sprintf('%s-%s-log.csv',ruta{1},conductor{1}); %Se alternan los datos de los conductores y las rutas
      fichero2=dlmread(fichero1,',',1,0); 
      subplot(1,2,lado); %Se posiciona la matriz de la grafica en pantalla, teniendo en cuenta "lado" el cual cambia 
      plot(fichero2(:,1),fichero2(:,2)); % Velocidad vs Distancia
      hold on  %Se mantiene la grafica en pantalla
      ylabel('Distancia') %Se nombra el eje Y de la grafica
      xlabel('Velocidad') %Se nombre el eje X de la grafica
      title('Conductores') %Titulo de la grafica
                           
      V=fichero2(:,1); %Con la columna 1 de cada fichero(Velocidades) calculamos los valores estadisticos respecto los conductores y ruta      
      Media=mean(V); %Utilizando "mean", se calcula la media de la columna de velocidades respecto los conductores y ruta
      Maximo=max(V); %Utilizando "max", se calcula el punto maximo de la columna de velocidades respecto los conductores y ruta
      Minimo=min(V); %Utilizando "min", se calcula el punto minimo de la columna de velocidades respecto los conductores y ruta
      fprintf('Estadisticas de la Ruta %s y el conductor %s:\n Velocidad Media:%f\n  Rango de Velocidad :[%.1f,%.1f]\n',ruta{1},conductor{1},Media,Minimo,Maximo)
      %Sacamos por pantalla dichos valores 
       lado=lado+1; %3 dato que se va a almacenar en el subplot el cual aumenta en cada valor
    end
 end

clc;
clear;
Media=0; 
for ruta={'n1','a1'} %Ficheros de las n1(Ruta Nacional 1) y de a1(Ruta Autopista 1)
      fichero=sprintf('%s-height.csv',ruta{1}); %Se alternan los datos de las dos rutas     
      Alturas=dlmread(fichero,',',1,0); %Se cargan los ficheros de a1, n1  
      
      subplot(1,2,1); %Se posiciona la matriz de la grafica en pantalla
      hold on  %Se mantiene la grafica en pantalla
      plot(Alturas(:,4),Alturas(:,3)); % Grafica de Alturas Relativas a la Distancia 
 
      ylabel('Distancia')% Nombre de los Ejes y el titulo de la grafica
      xlabel('Altura')
      title('Grafica2')

      subplot(1,2,2); %Se posiciona la matriz de la grafica en pantalla
      plot(Alturas(:,2),Alturas(:,1)); % Grafica de la longitud contra latitud
      hold on %Se mantiene la grafica en pantalla
      
      ylabel('Latitud') % Nombre de los Ejes y el titulo de la grafica
      xlabel('Longitud')
      title('Grafica1')
      
      A=Alturas(:,3); %Con la columna 3 de cada fichero(Alturas) calculamos los valores estadisticos      
      Media=mean(A); %Utilizando "mean", se calcula la media de la columna de alturas de los ficheros
      DesviacionEstandar = std(A); %Utilizando "std", se calcula la desviacion Estandar de la columna de alturas del fichero
      Maximo=max(A); %Utilizando "max", se calcula el punto maximo de la columna de alturas del fichero
      Minimo=min(A); %Utilizando "min", se calcula el punto minimo de la columna de alturas del fichero
      fprintf('Estadisticas de la Ruta %s:\n Altura Media:%f\n Desviacion Estandar:%f\n Rango de Alturas :[%.1f,%.1f]\n',ruta{1},Media,DesviacionEstandar,Minimo,Maximo)
      %Sacamos por pantalla dichos valores 
end



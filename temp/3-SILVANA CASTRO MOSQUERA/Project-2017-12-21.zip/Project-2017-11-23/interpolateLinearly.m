function [interpolatedY] = interpolateLinearly(xVector, yVector , x)
 i=1;
 while i<length(xVector) && x >= xVector(i) %Recibe los valores de X e Y, recorre la longitud del vector
    i=i+1; %Recorre todas las posiciones del vector
  end
  i=i-1; %Posicion en la que se esta 
  interpolatedY=((x-xVector(i))*(yVector(i+1)-yVector(i))/(xVector(i+1)-xVector(i)))+yVector(i);  %Operacion correspondiente 
end     
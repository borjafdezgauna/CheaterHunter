% Calculamos el tiempo que tarda entre puntos
vx=[0 20 40 60]
vy=[0 30 50 30]
for i=1:length(vx)
   if vx(i)==0 && vy(i)==0
       a(i)=0
   else
       t=(vx(i))/(vy(i))
       %% Metemos cada valor del tiempo en una matriz para poder guardar los valores
       a(i)=t
   end
end
%%calculamos el timepo total
tiempototal = sum(a)
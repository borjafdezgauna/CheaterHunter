a=input('numero')

while a<6 && a>0
    disp ('si')
    if a==6
        disp('salir')
        end
    elseif a<0 || a>6
            disp('no')
        end
     a=input('numero')
end

        

####### MEN� ########:
1. Muestra las gr�ficas y estad�sticas de las rutas
2. Muestra las gr�ficas y estad�sticas de los conductores
3. C�lculos de tiempo para cada conductor y ruta
4. Comprobar los l�mites de velocidad
5. C�lculo de consumo de combustible para cada conductor y
ruta
6. Salir
Elige una opci�n:
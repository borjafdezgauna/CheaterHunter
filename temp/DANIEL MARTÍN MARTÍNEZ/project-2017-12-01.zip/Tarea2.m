% leemos los datos de los archivos y los guardamos en variables
primera={'a','n'}
segunda=[1,2]
for j=1:length (segunda)
    for i=1:length (primera)
        hold on
        a= sprintf ('%s1-driver%d-log.csv', primera {i},segunda(j));
        datos=dlmread(a,',');
        datos(1,1)=0;
        datos(1,2)=0;
        subplot (1,2,segunda(j));
        plot (datos(:,1),datos(:,2));
        xlabel ('Ruta')
        ylabel ('Velocidad')
        y= sprintf ('C%d', segunda (j));
        title (y)
        axis([0 200 0 140])
        
        media=mean(datos(:,2));
        desviacion=std(datos(:,2));
   
        max1=max(datos(:,2));
      
        min1=min(datos(:,2));
        hold on
        fprintf ('Estadisticas del conductor %d de la ruta %s1: \n Velocidad media: %.2f (sd: %.2f) \n Rango de velocidades: [%.2f, %.2f] \n',segunda(j),primera {i},media, desviacion, min1, max1);
    end
end
       
       
       
saveas (gcf,'route-speed','png');

% 
% 
% % Generamos una grafica con dos subgraficas
% % La linea azul representa la ruta de la Autopista y la linea roja
% % representa la ruta de la Nacional.
% 
% % De los dos archivos, la 1� columna son Latitudes y la 2� son Longitudes
% % subplot (2,2,2);
% % plot (datosa1 (:,2), datosa1 (:,1),datosn1 (:,2), datosn1 (:,1))
% % xlabel ('Longitud')
% % ylabel ('Latitud')
% % title ('Ruta')
% % 
% % 
% % a=datosa1(:,3);
% % b=datosn1(:,3);
% % subplot (2,2,1);
% % plot ((1:length (a)),a,'b',(1:length(b)),b,'r');
% % xlabel ('Ruta')
% % ylabel ('Elevacion')
% % title ('Altura')
% % 
% 
% % Vamos a guardar la imagen como "route-elevations.png"
% saveas (gcf,'route-elevations','png');
% 
% 
% % Calculamos los valores estadisticos.
% mediaa1=mean(datosa1(:,3));
% median1=mean(datosn1(:,3));
% 
% 
% desviaciona1=std(datosa1(:,3));
% desviacionn1=std(datosn1(:,3));
% 
% 
% maxa1=max(datosa1(:,3));
% mina1=min(datosa1(:,3));
% maxn1=max(datosn1(:,3));
% minn1=min(datosn1(:,3));
% 
% 
% % Mostrar texto
% fprintf ('Estadisticas de la ruta n1: \n Altura media: %.2f (sd: %.2f) \n Rango de alturas: [%.2f, %.2f] \n',median1, desviacionn1, minn1, maxn1);
% fprintf ('Estadisticas de la ruta a1: \n Altura media: %.2f (sd: %.2f) \n Rango de alturas: [%.2f, %.2f] \n',mediaa1, desviaciona1, mina1, maxa1);
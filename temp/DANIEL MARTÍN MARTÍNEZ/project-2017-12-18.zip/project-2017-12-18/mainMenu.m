a=input('numero');
if a==6
    disp('salir')
else
while a==~6
    switch a
    case 1
       disp ('si')
    case 2
        
    case 3
        
    case 4
        
    case 5
        
  
    otherwise
        disp ('error')

    end
end

end 




if a<6 && a>0 && rem(a,1)==0
    while a<6 && a>0 && rem(a,1)==0
    disp ('si')
    a=input('numero: ')
    end  
 if a==6
    disp('salir')
else
    disp('error')
 end
end
 
 
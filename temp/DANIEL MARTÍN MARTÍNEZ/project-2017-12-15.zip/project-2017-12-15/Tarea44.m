
primera={'a','n'}
segunda=[1,2]
numSlices = input ('Introduce el numero de slices: ');

for j=1:length (segunda)
    for i=1:length (primera)
        hold on
        a= sprintf ('%s1-driver%d-log.csv', primera {i},segunda(j));
        datos=dlmread(a,',');
        datos(1,1)=0;
        datos(1,2)=0;
        kms=datos(:,1)
        speedKmH = datos(:,2)
        
        x = linspace (1,kms(end),numSlices)
        for i=1:length (x)
        interpolatedY(i)=interpolateLinearly (kms,speedKmH,x(i))
         
       a= estimateTime (kms,speedKmH, numSlices)
       disp (a)
        end
       
        end
        
    end
end
function [interpolatedY]= interpolateLinearly (xVector, yVector, x)
i=1
while ~(x>=xVector(i) && x<=xVector(i+1))
        i=i+1 
end

m= (yVector(i+1)-yVector(i))/(xVector(i+1)-xVector(i))
interpolatedY=m*(x-xVector(i))+yVector(i)
    
end

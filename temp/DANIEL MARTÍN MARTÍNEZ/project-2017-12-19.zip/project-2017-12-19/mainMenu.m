
    
    a=input('numero: ');
while ~(a==6)
     
    switch a
    case 1
         disp ('Mostrando las gr�ficas y estad�sticas de las rutas')
         run Tarea1.m
    case 2
          disp ('Mostrando las gr�ficas y estad�sticas de los conductores')
          run Tarea2.m
    case 3
          disp ('C�lculos de tiempo para cada conductor y ruta')
           run Tarea4.m
    case 4
          disp ('Comprobar los l�mites de velocidad')
    case 5
          disp ('Calculo de consumo de combustible para cada conductor y ruta')
  
    otherwise
        disp ('Opci�n incorrecta: debe ser un n�mero entero entre 1 y 6')

    end
    a=input('numero: ');
end

disp ('Exit ')


function [ tiempoestimado ] = prueba( kms, speedKmH, numslices )
x = linespace (kms(1),kms(end),numSlices)
for i = 1: length(x)
    intY = interpolateLinearly (kms, speedKmH, x)
    t = ((x(i+1)-x(i))^2)/(intY(i+1)-int(i))
end
    
    

end


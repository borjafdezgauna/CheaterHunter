function [estimatedTime] = estimateTime (kms,speedkmH, numSlices)


% Calculamos el tiempo que tarda entre puntos
vx=kms
vy=speedkmH
for i=1:length(vx)
   if vx(i)==0 && vy(i)==0
       a(i)=0
   else
       t=(vx(i))/(vy(i))
       %% Metemos cada valor del tiempo en una matriz para poder guardar los valores
       a(i)=t
   end
end
%%calculamos el timepo total
tiempototal = sum(a)
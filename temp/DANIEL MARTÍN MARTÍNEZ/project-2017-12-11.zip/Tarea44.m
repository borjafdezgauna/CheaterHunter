
primera={'a','n'}
segunda=[1,2]
for j=1:length (segunda)
    for i=1:length (primera)
        hold on
        a= sprintf ('%s1-driver%d-log.csv', primera {i},segunda(j));
        datos=dlmread(a,',');
        datos(1,1)=0;
        datos(1,2)=0;
        kms=datos(:,1)
        speedKmH(:,2)
        
        for i=1:lenght (x)
        interpolateLinearly (kms,speedKmH,x(i))
        
        end
        
    end
end
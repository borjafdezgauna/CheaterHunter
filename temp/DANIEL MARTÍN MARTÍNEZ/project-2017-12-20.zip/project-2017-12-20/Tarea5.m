clear
clc
primera={'a','n'};
segunda=[1,2];
numSlices = input ('Introduce el numero de slices: ');

for i=1:length (primera)
     b= sprintf ('%s1-speed-limit.csv', primera {i});
       datos1=dlmread(b);
       limitKms=datos1(:,1);
       limitSpeeds = datos1(:,2);
       
    for j=1:length (segunda)
        a= sprintf ('%s1-driver%d-log.csv', primera {i},segunda(j));
        datos=dlmread(a,',');
        datos(1,1)=0;
        datos(1,2)=0;
        driverLogKm=datos(:,1);
        driverLogSpeed = datos(:,2);
        kmsAboveSpeedLimit =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices);
%         kmsAboveSpeedLimit= c(1)  
%         percentAboveSpeedLimit=c(2)
        fprintf ('Analyzing: Driver= driver1, Route= n1 Mild infraction risk: Kms abover the speed limit= %s',kmsAboveSpeedLimit )
        end
end


    
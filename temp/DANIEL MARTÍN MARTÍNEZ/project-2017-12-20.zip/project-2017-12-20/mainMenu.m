
    fprintf('          ####### MEN� ######## \n 1. Muestra las gr�ficas y estad�sticas de las rutas \n 2. Muestra las gr�ficas y estad�sticas de los conductores \n 3. C�lculos de tiempo para cada conductor y ruta \n 4. Comprobar los l�mites de velocidad \n 5. C�lculo de consumo de combustible para cada conductor ruta \n 6. Salir \n ')
    a=input('Elige una opci�n: ');
while ~(a==6)
     
    switch a
    case 1
         disp ('Mostrando las gr�ficas y estad�sticas de las rutas')
         run Tarea1.m
    case 2
          disp ('Mostrando las gr�ficas y estad�sticas de los conductores')
          run Tarea2.m
    case 3
          disp ('C�lculos de tiempo para cada conductor y ruta')
           run Tarea4.m
    case 4
          disp ('Comprobar los l�mites de velocidad')
    case 5
          disp ('Calculo de consumo de combustible para cada conductor y ruta')
  
    otherwise
        disp ('Opci�n incorrecta: debe ser un n�mero entero entre 1 y 6')

    end
     
    fprintf('Pulsa una tecla para continuar: \n');
    pause
     fprintf('          ####### MEN� ######## \n 1. Muestra las gr�ficas y estad�sticas de las rutas \n 2. Muestra las gr�ficas y estad�sticas de los conductores \n 3. C�lculos de tiempo para cada conductor y ruta \n 4. Comprobar los l�mites de velocidad \n 5. C�lculo de consumo de combustible para cada conductor ruta \n 6. Salir \n ')
     a=input('Elige una opci�n: ');
end

disp ('Exit ')


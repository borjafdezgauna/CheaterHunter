x=input('Dame los valores del vectorX: '); 
y=input('Dame los valores del vectorY: '); 
xx=input('Dame el valor x: ');
yy=interpolateLinearly(x,y,xx);
fprintf('El valo interpolado es %d\n', yy);
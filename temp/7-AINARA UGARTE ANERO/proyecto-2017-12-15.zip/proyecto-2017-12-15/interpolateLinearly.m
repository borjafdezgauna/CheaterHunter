function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
  interpolatedY=interp1(xVector,yVector,x,'linear');
end
%(con el porcentaje a mi me sale error)
%habr�a que mirar si hay alguna de pedir directamente un vector
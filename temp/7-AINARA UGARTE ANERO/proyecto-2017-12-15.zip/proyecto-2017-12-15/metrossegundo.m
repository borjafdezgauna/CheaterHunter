x=input('Dame la velocidad en km/h: ');
res=toMetersPerSecond(x);
fprintf('Esta velocidad en m/s es %d\n',res);
clc
####### MEN� ########:
1. Muestra las gr�ficas y estad�sticas de las rutas
2. Muestra las gr�ficas y estad�sticas de los conductores
3. C�lculos de tiempo para cada conductor y ruta
4. Comprobar los l�mites de velocidad
5. C�lculo de consumo de combustible para cada conductor y
ruta
6. Salir
opcionelegida=disp('Elige una opci�n: ')
if  opcionelegida= 1 or 2 or 3 or 4 or 5 or 6
elseif opcionelegida=1
      resultado= (route-elevations.png)
elseif opcionelegida=2
      resultado= (velocidades.png)
elseif opcionelegida=3
      resultado= (Tarea2.m)
elseif opcionelegida=6
      clc
      clear
else
disp('Opci�n incorrecta: debe ser un n�mero entre 1 y 6')
end
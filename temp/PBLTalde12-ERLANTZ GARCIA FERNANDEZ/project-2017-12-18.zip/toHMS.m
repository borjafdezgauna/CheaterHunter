function [hms] = toHMS(seconds)
 
horas = floor(seconds/3600);
if seconds >= 3600
minutos = floor(horas/60);
end
if seconds < 3600
minutos = floor(seconds/60);
end
segs = seconds-(horas*3600)-(minutos*60);
 
toHMS = sprintf('%0.2d:%0.2d:%0.2d',horas,minutos,segs)

end
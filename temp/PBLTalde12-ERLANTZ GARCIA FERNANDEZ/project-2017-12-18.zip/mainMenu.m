function zenb = mainMenu()
  disp('####### MENU ########:')
  disp('1. Show route plots/statistics')
  disp('2. Show driver plots/statistics')
  disp('3. Time calculations for each driver/route')
  disp('4. Check speed limits')
  disp('5. Fuel consumption calculations for each driver/route')
  disp('6. exit')
  zenb = input('Eman zenbaki bat\n');
  
  while zenb > 6
    clear
    clc
    zenb = input('Eman zenbaki bat 1 eta 6 bitartean\n');
    end
  
  if zenb == 1
    clear
    clc
    a1n1
    mainMenu
   
      
    
  elseif zenb == 2
    clear
    clc
    ataza2
    mainMenu
    
  
  elseif zenb == 3
    clear
    clc
    mainMenu
  elseif zenb == 4
    clear
    clc
    mainMenu
  elseif zenb == 5
    clear
    clc
    mainMenu
    
  
    
  elseif zenb == 6
    clear
    clc
    
    
    end
    
    end
    
    
    
    
  
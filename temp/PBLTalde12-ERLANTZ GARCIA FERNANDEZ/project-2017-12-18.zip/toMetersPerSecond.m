function [msSpeed] = toMetersPerSecond(speedKmH)
  toMetersPerSecond = speedKmH*1000/3600
  end
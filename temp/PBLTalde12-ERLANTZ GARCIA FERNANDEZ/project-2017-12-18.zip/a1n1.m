
n1 = dlmread('n1-height.csv',',',1,0);
plot(n1(:,4),n1(:,3))
xlabel('distantzia(km)')
ylabel('altuera(m)')
title('nazionala eta autopista')

hold on
a1 = dlmread('a1-height.csv',',',1,0);
plot(a1(:,4),a1(:,3))
hold off

a = n1(:,3);
meanheight1 = mean(a)
sd1 = std(a)
z1 = max(a);
m1 = min(a);
minmaxheight1 = [m1 z1]

b = a1(:,3);
Meanheight2 = mean(b)
sd2 = std(b)
z2 = max(b);
m2 = min(b);
minmaxheight2 = [m2 z2]

saveas(gcf,'a1n1.png');



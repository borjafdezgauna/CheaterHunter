function ms= toMetersPerSecond(kmH)
  ms=(kmH*1000)/3600;
end
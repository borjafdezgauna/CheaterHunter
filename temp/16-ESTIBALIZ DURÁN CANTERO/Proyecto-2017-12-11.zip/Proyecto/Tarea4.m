xVector=input('dame un vector x');%variable
yVector=input('dame un vector y');
x=input('dame una x')
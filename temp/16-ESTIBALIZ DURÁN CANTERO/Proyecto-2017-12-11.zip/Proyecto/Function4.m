function [interpolatedY]=interpolateLinearly(xvector,yvector,x)
while xvector<x
    
end
clc;
interpolateLinearly([10 20 40],[120 150 130],10)
interpolateLinearly([10 20 40],[120 150 130],15)
interpolateLinearly([10 20 40],[120 150 130],25)
interpolateLinearly([10 20 40],[120 150 130],40)
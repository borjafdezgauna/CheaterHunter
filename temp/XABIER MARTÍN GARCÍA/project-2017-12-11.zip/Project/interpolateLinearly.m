function [interpolatedY] = interpolateLinearly(xVector, yVector, x)

index=1;

while xVector(index) <= x
    index= index + 1;
end

y2 = yVector(index);
y1 = yVector(index - 1);
x2 = xVector(index);
x1 = xVector(index - 1);

slope = (y2-y1)/(x2-x1);

interpolatedY = y1 + slope*(x - x1);

end

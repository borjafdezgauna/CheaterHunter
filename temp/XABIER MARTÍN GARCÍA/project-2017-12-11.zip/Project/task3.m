input_Option = 0

while input_Option == 0
    clc
    fprintf('####### MENU ########: \n 1. Show route plots/statistics \n 2. Show driver plots/statistics \n 3. Time calculations for each driver/route \n 4. Check speed limits \n 5. Fuel consumption calculations for each driver/route \n 6. Exit\n')
    input_Option = input('Choose an option:    ')
    if input_Option <= 6 && input_Option >= 1
        if input_Option == 1    
            task1.m
        elseif input_Option == 2
            task2.m
        elseif input_Option == 3
            tesk4.m
        else 
            fprintf('Incorrect option: it must be between 1 and 6')
            input_Option = 0
        end
    end
end
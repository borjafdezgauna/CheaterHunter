
%We used a function to calculate the speed in m/s.

function [msSpeed] = toMetersPerSecond(speedKmH)
    msSpeed = speedKmH/3600*1000;
end


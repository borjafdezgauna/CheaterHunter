
%We used a function to calculate distance in meters.

function [ m ] = toMeters( km )
    m = km*1000;
end
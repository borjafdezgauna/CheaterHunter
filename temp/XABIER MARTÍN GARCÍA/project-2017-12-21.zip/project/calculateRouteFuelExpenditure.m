function [ fuelExpenditure ] = calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices)
loop = 0;
index = length(routeKms);
slice_Size = toMeters(routeKms(index)/numSlices);
index1 = 0;

for loop = 0:slice_Size:routeKms(index)
    %We are calculating the speed, acc, and theta in every point
    %(based on numSlices) to input them in the formula and sum them up
    
    index1 = index1 + 1
    
    current_Speed_Mt = toMetersPerSecond(interpolateLinearly(logKms, logSpeeds, logKms(index1)))
    
    %We get the speed at a certain point, and the speed at a close point.
    %Speed change divided by time difference equals acceleration at that point.
    
    close_To_Current_Speed_Mt = current_Speed_Mt - 0.01
    delta_V = current_Speed_Mt/close_To_Current_Speed_Mt
    
    current_Time_S = estimateTime()
    close_To_Current_Time_S = estimateTime(logKms, logSpeeds, 1000)
    delta_T = current_Time_S - close_To_Current_Time_S
    
    current_Acceleration = delta_V/delta_T
    
    %Slope: one point divided by other point, gives us the slope. 
    %Arctan of slope equals radians of slope.
    
    y2 = routeHeights(index);
    y1 = routeHeights(index - 1);

    x2 = routeKms(index);
    x1 = routeKms(index - 1);
    
    current_Slope_Rads = arctan((y2 - y1)/(x2 - x1));
    
end

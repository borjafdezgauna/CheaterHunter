for route = {'a1','n1'}
        for driver = {'1','2'}
           index = 1;
           speed_Limits_File = sprintf('Data/%s-speed-limit.csv',route{1});
           driver_Log_File = sprintf('Data/%s-driver%s-log.csv', route{1}, driver{1});
           data_File = dlmread(log_File,',',1,0);
           [total_Illegal_Kms, illegal_Percentage_Kms] = checkSpeedLimits(driver_Log_File(:,1), driver_Log_File(:,2), speed_Limits_File(:,1), speed_Limits_File(:,2), 10000);
           if illegal_Percentage_Kms >=10
               fprintf('Analyzing: Driver%s, Route = %s \n HIGH INFRACTION RISK: Kms above the seped limit = %d (%.d% of the route)', driver{1}, route{1}, total_Illegal_Kms, illegal_Percentage_Kms)
           elseif illegal_percentage_Kms == 0
               fprintf('Analyzing: Driver%s, Route = %s \n No risk of infraction', driver{1}, route{1})
           else
               fprintf('Analyzing: Driver%s, Route = %s \n Mild infraction Risk: Kms above the seped limit = %d (%.d% of the route)', driver{1}, route{1}, total_Illegal_Kms, illegal_Percentage_Kms)
           end
        end
end
%This function checks wether the x value is or isn't between
%0 and X kms. If that's true, interpolatedY gets the value
%of the "n-1"th vector, the speed limit at that km.

function [ interpolatedY ] = interpolateToTheLeft( xVector, yVector , x)
index = 1;
while x >= xVector(index) 
    index = index + 1;
end
index = index - 1;
interpolatedY = yVector(index);
end


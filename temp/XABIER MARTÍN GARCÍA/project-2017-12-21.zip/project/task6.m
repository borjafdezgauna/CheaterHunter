for route = {'a1','n1'}
    for driver = {'1','2'}
       log_File = sprintf('Data/%s-driver%s-log.csv', route{1}, driver{1});
       data_File = dlmread(log_File,',');
       
    end
end
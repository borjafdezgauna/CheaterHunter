function [estimatedTime] = estimateTime(kms, speedKmH, numSlices)
    
    index = length(kms);
    slice_Size = kms(index)/numSlices;
    time = 0;
    loop = 0;
    
    
    for loop = 0:slice_Size:kms(index)
        interpolated_Speed = interpolateLinearly(kms, speedKmH, loop)
        time = time + slice_Size/interpolated_Speed*3600
    end
        
    estimatedTime = time
      
end


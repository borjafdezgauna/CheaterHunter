function [msSpeed] = toMetersPerSecond(speedKmH)
    msSpeed = speedKmH/3600*1000
end


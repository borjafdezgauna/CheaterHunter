function [hms] = toHMS(seconds)
    seconds = fix(seconds);
    
    ho = 0;
    min = 0;
    sec = 0;
    
    ho = fix(seconds/3600);
    min = fix((seconds/3600 - ho)*60);
    sec = fix((((seconds/3600 - ho)*60) - fix(min))*60);
    
    hms = sprintf('%02d:%02d:%02d:', ho, min, sec)
end
    


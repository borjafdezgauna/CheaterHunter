total_Kms_Driver1_A1 = 0;
total_Kms_Driver2_A2 = 0;
total_Kms_Driver1_N1 = 0;
total_Kms_Driver2_N2 = 0;

for route = {'a1','n1'}
        for driver = {'1','2'}
           log_File = sprintf('Data/%s-driver%s-log.csv', route{1}, driver{1});
           data_File = dlmread(log_File,',');
           if data_File = 
        end
end
function [ interpolatedY ] = interpolateToTheLeft( xVector, yVector , x)
index = 1

while xVector(index) <= x
    index = index + 1;
    if xVector(index) == x
        interpolatedY = yVector(index)
    end
end
end
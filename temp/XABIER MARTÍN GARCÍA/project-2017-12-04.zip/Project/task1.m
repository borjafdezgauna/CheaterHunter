all_Data = [];
bulk_Data = [];

for heights = {'a1', 'n1'}
        bulk_Data = sprintf('Data/%s-height.csv', heights{1});
        all_Data = dlmread(bulk_Data , ',' , 1 , 0);
        
        fprintf('Range: %.2d - %.2d\n',min(all_Data(:,3)), max(all_Data(:,3)))
        fprintf('Mean height: %.2d\n', mean(all_Data(:,3)))
        
        subplot(1,2,1)
            title('A1/N1 Height-Distance');            
            ylabel('Elevation (m)');
            xlabel('Distance from Origin (kms)');  
            plot(all_Data(:,4),all_Data(:,3))
            hold on
        
        subplot(1,2,2)
            title('A1/N1 Latitude-Longitude');
            ylabel('Longitude');
            xlabel('Latitude');       
            plot(all_Data(:,2),all_Data(:,1))
            hold on

end

saveas(gcf,'route-elevations.png')

fprintf('Press any key to continue...')
pause
task3.m
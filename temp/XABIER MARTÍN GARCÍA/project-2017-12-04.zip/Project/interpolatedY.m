function [retval] = interpolatedY (xVector, yVector , x)

    

endfunction

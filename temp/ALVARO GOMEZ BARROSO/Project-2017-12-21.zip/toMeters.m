%Esta funci�n convierte una cantidad de kil�metros introducida, a metros.

function [ m ] = toMeters( km )
m=km*1000;
end
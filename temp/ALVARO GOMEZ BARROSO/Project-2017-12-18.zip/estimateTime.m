function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
x=linspace(kms(1),kms(length(kms)),numSlices);
for i=1:length(speedKmH)
    y(i)= interpolateLinearly( xVector, yVector , x);   
end
for i=1:length(speedKmH) 

estimatedTime=(length(x)-x(1))/length(i);

end
function [ hms ] = toHMS( t )
hours = floor(t / 3600);
t1 = t - hours * 3600;
mins = floor(t1 / 60);
secs = floor(t1 - mins * 60);

fprintf('%.2d:%.2d:%.2d\n',hours,mins,secs)
%en el fprintf si se pone ".2d" no pone los 2 decimales y si pones ".2f" si

end


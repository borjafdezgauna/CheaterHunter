clear
clc
Ruta={'a','n'};
Conductor={'1','2'};

for i=1:length(Ruta)
    for j=1:length(Conductor)
        velocidad=sprintf('%s1-driver%s-log.csv',Ruta{i},Conductor{j});
        z=dlmread(velocidad,',',1,0);
        
        subplot(2,2,j)
        hold on
        plot(z(:,1),z(:,2));
        title('registro velocidad')
        xlabel('distancia km')
        ylabel('velocidad km/h')
        hold off
        
        velocidad=mean(z(:,2));
        sd=std(z(:,2));
        minimo=min(z(:,2));
        maximo=max(z(:,2));
        disp(sprintf('\nEstad�sticas del conductor%s en la ruta %s1:',Conductor{j},Ruta{i}));
        fprintf('velocidadmedia: %.2f (sd: %.2f)\nRango de velocidades[%.2f , %.2f]\n',velocidad,sd,minimo,maximo)   
    end
end
subplot(2,2,1)
legend('a1','n1')
subplot(2,2,2)
legend('a1','n1')

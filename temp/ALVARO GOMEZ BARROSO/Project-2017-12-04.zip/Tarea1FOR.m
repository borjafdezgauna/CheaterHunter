% Este script analiza los perfiles de elevaci�n de ambas rutas:

%(Con for)

Ruta={'a','n'};
for i=1:length(Ruta)
    a=sprintf('%s1-height.csv',Ruta{i});
    
    subplot(2,2,1);
    plot(a(:,4),a(:,3),'k')
    title('Altura1')
    xlabel('Distancia (kilometros)')
    ylabel('Altura (metros)')
    hold on
    plot(a(:,4),a(:,3),'b');
    title('Altura')
    xlabel('Distancia (kilometros)')
    ylabel('Altura (metros)')
    hold off
    legend('a1','n1')
end
%Para la subgrafica de las longitudes y latitudes

% Este script analiza los perfiles de elevaci�n de ambas rutas:

%(Sin for)

%Para la subgrafica de las alturas
%hold on para sobreescribir dos graficos en el mismo


alturaautopista=dlmread('a1-height.csv',',',1,0);
alturanacional=dlmread('n1-height.csv',',',1,0);

subplot(2,2,1);
plot(alturaautopista(:,4),alturaautopista(:,3),'k')
title('Altura1')
xlabel('Distancia (kilometros)')
ylabel('Altura (metros)')
hold on
plot(alturanacional(:,4),alturanacional(:,3),'b');
title('Altura')
xlabel('Distancia (kilometros)')
ylabel('Altura (metros)')
hold off

legend('a1','n1')
%Para la subgrafica de las longitudes y latitudes

rutaautopista=dlmread('a1-height.csv',',',1,0);
rutanacional=dlmread('n1-height.csv',',',1,0);

subplot(2,2,2);
plot(rutaautopista(:,2),rutaautopista(:,1),'k');
title('Ruta1')
xlabel('Longitud')
ylabel('Latitud')
hold on
plot(rutanacional(:,2),rutanacional(:,1),'b');
title('Ruta')
xlabel('Longitud')
ylabel('Latitud')
hold off

legend('a1','n1')

disp('Estadisticas de la ruta n1:')
Alturamedia=sum(alturanacional(:,3))/3895;
sd=std(alturanacional(:,3));
max1=max(alturanacional(:,3));
min1=min(alturanacional(:,3));
fprintf('Altura media: %.2f (sd: %.2f)\nRango de alturas: [%.2f, %.2f]\n',Alturamedia,sd,min1,max1);

disp('Estadisticas de la ruta a1:')
Alturamedia2=sum(alturaautopista(:,3))/3687;
sd2=std(alturaautopista(:,3));
max2=max(alturaautopista(:,3));
min2=min(alturaautopista(:,3));
fprintf('Altura media: %.2f (sd: %.2f)\nRango de alturas: [%.2f, %.2f]\n',Alturamedia2,sd2,min2,max2);

saveas(gcf,'route-elevations1.png')
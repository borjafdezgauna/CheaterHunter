clc
clear all
opcion=input('Elige una opci�n:');
while opcion~=6;
if opcion<1 && opcion>6
    disp('Opci�n incorrecta: debe ser un n�mero entre 1 y 6')
elseif opcion==1
        disp('Muestra las gr�ficas y estad�sticas de las rutas')
elseif opcion==2
        disp('Muestra las gr�ficas y estad�sticas de los conductores')
elseif opcion==3 
        disp('C�lculos de tiempo para cada conductor y ruta')
elseif opcion==4
        disp('Comprobar los l�mites de velocidad')
elseif opcion==5
        disp('C�lculo de consumo de combustible para cada conductor y ruta')
else 
        disp('salir')
end
end

    
        


        
        
        
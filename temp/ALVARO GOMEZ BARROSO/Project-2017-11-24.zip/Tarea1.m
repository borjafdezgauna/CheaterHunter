% Este script analiza los perfiles de elevaci�n de ambas rutas:

%(Sin for)

%Para la subgrafica de las alturas
%hold on para sobreescribir dos graficos en el mismo

alturaautopista=dlmread('a1-height.csv',',',1,0);
alturanacional=dlmread('n1-height.csv',',',1,0);
subplot(2,2,1);
plot(alturaautopista(:,4),alturaautopista(:,3));
title('Altura')
xlabel('Distancia (kilometros)')
ylabel('Altura (metros)')
subplot(2,2,2);
plot(alturanacional(:,4),alturanacional(:,3));
title('Altura')
xlabel('Distancia (kilometros)')
ylabel('Altura (metros)')

%Para la subgrafica de las longitudes y latitudes

rutaautopista=dlmread('a1-height.csv',',',1,0);
rutanacional=dlmread('n1-height.csv',',',1,0);
subplot(2,2,3);
plot(rutaautopista(:,2),rutaautopista(:,1));
title('Ruta')
xlabel('Longitud')
ylabel('Latitud')
subplot(2,2,4);
plot(rutanacional(:,2),rutanacional(:,1));
title('Ruta')
xlabel('Longitud')
ylabel('Latitud')
function [ hms ] = toHMS( seconds )
 if seconds>60
     b=rem(seconds,60)
     if b>60
         c=rem(b,60)
     else
         d
     end
 end
 fprintf('%d:%d:%d',b,c,d)
     
 
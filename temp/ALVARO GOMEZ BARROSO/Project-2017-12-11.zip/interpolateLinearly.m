function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x) 
while 
end
velocidada1driver1=dlmread('a1-driver1-log.csv',',',1,0);
velocidada1driver2=dlmread('a1-driver2-log.csv',',',1,0);
velocidadn1driver1=dlmread('n1-driver1-log.csv',',',1,0);
velocidadn1driver2=dlmread('n1-driver2-log.csv',',',1,0);

subplot(2,2,1)
plot(velocidada1driver1(:,1),velocidada1driver1(:,2),'k');
hold on
plot(velocidadn1driver1(:,1),velocidadn1driver1(:,2),'b');
title('registro velocidad driver 1')
xlabel('distancia km')
ylabel('velocidad km/h')
hold off
legend('a1','n1')

subplot(2,2,2)
plot(velocidada1driver2(:,1),velocidada1driver2(:,2),'k');
hold on
plot(velocidadn1driver2(:,1),velocidadn1driver2(:,2),'b');
title('registro velocidad driver 2')
xlabel('distancia km')
ylabel('velocidad km/h')
hold off
legend('a1','n1')

velocidad=mean(velocidadn1driver1(:,2));
sd=std(velocidadn1driver1(:,2));
minimo=min(velocidadn1driver1(:,2));
maximo=max(velocidadn1driver1(:,2));
disp('Estad�sticas del conductor1 en la ruta n1:');
fprintf('velocidadmedia: %.2f (sd: %.2f)\nRango de velocidades[%.2f , %.2f]\n',velocidad,sd,minimo,maximo)

velocidad1=mean(velocidadn1driver2(:,2));
sd1=std(velocidadn1driver2(:,2));
minimo1=min(velocidadn1driver2(:,2));
maximo1=max(velocidadn1driver2(:,2));
disp('Estad�sticas del conductor2 en la ruta n1:');
fprintf('velocidadmedia: %.2f (sd: %.2f)\nRango de velocidades[%.2f , %.2f]\n',velocidad1,sd1,minimo1,maximo1)

velocidad2=mean(velocidada1driver1(:,2));
sd2=std(velocidada1driver1(:,2));
minimo2=min(velocidada1driver1(:,2));
maximo2=max(velocidada1driver1(:,2));
disp('Estad�sticas del conductor1 en la ruta a1:');
fprintf('velocidadmedia: %.2f (sd: %.2f)\nRango de velocidades[%.2f , %.2f]\n',velocidad2,sd2,minimo2,maximo2)

velocidad3=mean(velocidada1driver2(:,2));
sd3=std(velocidada1driver2(:,2));
minimo3=min(velocidada1driver2(:,2));
maximo3=max(velocidada1driver2(:,2));
disp('Estad�sticas del conductor2 en la ruta a1:');
fprintf('velocidadmedia: %.2f (sd: %.2f)\nRango de velocidades[%.2f , %.2f]\n',velocidad3,sd3,minimo3,maximo3)

saveas(gcf,'route-elevations2.png')
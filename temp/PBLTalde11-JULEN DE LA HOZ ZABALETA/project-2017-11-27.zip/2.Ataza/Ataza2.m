for file = {'a1-speed.csv', 'n1-speed.csv'}
  abiaduraInformazioa = dlmread( file{1}, ',', 1,0);
  subplot (1,2,1)
  hold on;
  plot(abiaduraInformazioa(:,1), abiaduraInformazioa(:,2))
  xlabel('distantzia (km)');
  ylabel('abiadura (km/h)');
  title('A1 errepideko gidariaren abiadura');
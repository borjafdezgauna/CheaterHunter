function [ kmsAboveSpeedLimit, percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
deltaDriverLogKm=(driverLogKm(length(driverLogKm))/numSlices);
distance= (0: deltaDriverLogKm: driverLogKm(length(driverLogKm)));
speed = [];
speedlimit=[];
kmsAboveSpeedLimit=0;
for a=distance
    s = interpolatedlinearly (driverLogKm, driverLogSpeed, a );
    speed= [speed, s];    %%%%%Bestela hemen speed aurretik zer den zehaztu behar dugu. goian bektore gisa jarri dugu eta gero bektore =[bektore, kte]
    sp = interpolateToTheLeft ( limitKms,  limitSpeeds, a);
    speedlimit= [speedlimit, sp];
if speed > speedlimit %%%%Errorea hemen dago, ezin dugu hau ipini bektoreak direlako, haien posizioa zehaztu behar da.
   kmsAboveSpeedLimit= kmsAboveSpeedLimit + deltaDriverLogKm;
end
end
percentAboveSpeedLimit= (kmsAboveSpeedLimit)*100/(distance(length(distance)));
end


function [ kmsAboveSpeedLimit, percentAboveSpeedLimit ] = checkSpeedLimitss( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
deltaDriverLogKm=(driverLogKm(length(driverLogKm))/numSlices);
distance= (0: deltaDriverLogKm: driverLogKm(length(driverLogKm)));
speed = [];
speedlimit=[];
i=0;
kmsAboveSpeedLimit=0;
for a=distance
    s = interpolatedlinearly (driverLogKm, driverLogSpeed, a );
    speed= [speed, s];
    sp = interpolateToTheLeft ( limitKms,  limitSpeeds, a);
    speedlimit= [speedlimit, sp];
if speed(i) > speedlimit(i) %%%%Errorea hemen dago
   kmsAboveSpeedLimit= kmsAboveSpeedLimit + deltaDriverLogKm;
end
i=i+1;
end

percentAboveSpeedLimit= (kmsAboveSpeedLimit)*100/(distance(length(distance)));
end

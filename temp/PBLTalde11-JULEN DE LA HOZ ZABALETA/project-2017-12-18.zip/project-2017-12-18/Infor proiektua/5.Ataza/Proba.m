function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
i=1;
errepidea={'n1', 'a1'};
gidaria={'1','2'};
for x=errepidea
for y=gidaria
    gidarieninf= sprintf('%s-driver%s-log.csv', x{1} ,y{1});
    abiadurainformazioa= dlmread(gidarieninf , ',');
    
    driverLogKm= abiadurainformazioa(:,1);
    driverLogSpeed= abiadurainformazioa(:,2);
    numSlices= length(abiadurainformazioa(:,1));
    
    
end
i = i+1;
end
end

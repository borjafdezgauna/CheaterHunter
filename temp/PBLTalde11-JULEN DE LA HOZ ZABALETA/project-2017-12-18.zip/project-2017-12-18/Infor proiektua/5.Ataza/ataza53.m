i=1;
errepidea={'n1', 'a1'};
gidaria={'1','2'};
for x=errepidea
for y=gidaria
    gidarieninf= sprintf('%s-driver%s-log.csv', x{1} ,y{1});
    abiadurainformazioa= dlmread(gidarieninf , ',');
    abiaduralim=sprintf('%s-speed-limit.csv', x{1});
    limiteinf= dlmread(abiaduralim, ';');
    [R,r]=checkSpeedLimits(abiadurainformazioa(:,1),abiadurainformazioa(:,2),limiteinf(:,1),limiteinf(:,2),length(abiadurainformazioa(:,1)));
   
    if r==0
        A=sprintf('Ez dago infrakzio arriskurik.');
    elseif 0<r && r<10
            A=sprintf('Infrakzio arrisku moderatua: km kopurua abiadura gainetik: %f.2 (%f.2 of the route)', R,r);
    elseif r>10
                 A=sprintf('INFRAKZIO ARRISKU ALTUA: km kopurua abiadura gainetik: %f.2 (%f.2 of the route)', R,r);
    end
           
    

fprintf('Analizatzen:  Gidaria%s, Errepidea=%s\n%s\n\n',y{1},x{1},A);
end
   i = i+1;
  if i==2
  
  end
end
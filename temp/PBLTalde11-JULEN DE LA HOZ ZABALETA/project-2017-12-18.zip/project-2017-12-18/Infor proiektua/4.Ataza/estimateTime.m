function [ estimatedtime ]= estimateTime (kms, speedKmH, numSlices)
deltakm = (kms(length(kms))/ numSlices);
distance = (0:deltakm:kms(length(kms)));
speed = [];

for a=distance
    s= interpolatedlinearly (kms, speedKmH, a);
    speed=[speed, s];
end

bb = mean (speed);
estimatedtimeh= kms(length(kms))/bb;
estimatedtime= estimatedtimeh*3600;
end


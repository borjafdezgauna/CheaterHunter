
i=1;
errepidea={'n1', 'a1'};
gidaria={'1','2'};
for x=errepidea
for y=gidaria
    gidarieninf= sprintf('%s-driver%s-log.csv', x{1} ,y{1});
    abiadurainformazioa= dlmread(gidarieninf , ',');
    kms= abiadurainformazioa(:,1);
    speedKmH= abiadurainformazioa(:,2);
    numSlices= length(abiadurainformazioa(:,1));
   
    Est= toHMS(estimateTime (kms, speedKmH, numSlices));
    fprintf('Esperotako denbora %s.gidariarentzat %s bidean: %s\n', y{1},x{1},Est) 
end
   i = i+1;
end







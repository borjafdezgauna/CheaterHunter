for file = {'a1-height.csv', 'n1-height.csv'}
  errepideenInformazioa = dlmread( file{1}, ',', 1,0);
  
  subplot(1,2,1);
  hold on;
  plot(errepideenInformazioa(:,1), errepideenInformazioa(:,2))
  xlabel('latitude (�)');
  ylabel('longitudea (�)');
  title('Errepideen ibilbidea');
  legend('N1','A1');
 
  subplot(1,2,2);
  hold on;
  plot(errepideenInformazioa(:,4) ,errepideenInformazioa (:,3))
  xlabel('distantzia (Km)');
  ylabel('altuera (m)');
   title('Errepideen altuerak');
  legend('N1','A1');
end
n1informazioa=dlmread('n1-height.csv',',', 1,0); 
n1altuerabatazbestekoa= mean(n1informazioa (:,3));
a1informazioa=dlmread('a1-height.csv',',', 1,0); 
a1altuerabatazbestekoa= mean(a1informazioa (:,3));
n1altuerarendesbiderazioestandarra= std(n1informazioa (:,3));
a1altuerarendesbiderazioestandarra= std(a1informazioa (:,3)); 
n1min=min(n1informazioa (:,3));
n1max=max(n1informazioa (:,3));
a1min=min(a1informazioa (:,3)); 
a1max=max(a1informazioa (:,3)); 

fprintf ('N1 errepidearen informazioa:\nBatazbesteko altuera:%.2f (Desbiderazio estandarra:%.2f)\nAltuera tartea: [%.2f,%.2f] \nA1 errepidearen informazioa:\nBatazbesteko altuera:%.2f (Desbiderazio estandarra: %.2f)\nAltuera tartea: [%.2f,%.2f]\n',n1altuerabatazbestekoa,n1altuerarendesbiderazioestandarra,n1min,n1max,a1altuerabatazbestekoa,a1altuerarendesbiderazioestandarra,a1min,a1max)


    
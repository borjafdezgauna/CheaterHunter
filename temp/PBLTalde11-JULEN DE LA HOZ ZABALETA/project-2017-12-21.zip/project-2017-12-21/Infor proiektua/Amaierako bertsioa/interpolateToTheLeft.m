function [interpolatedY] = interpolateToTheLeft (xVector, yVector, x)

i=2;
while i< length(xVector) && xVector(i) < x

    i=i+1;
 end
interpolatedY = yVector(i-1);

end



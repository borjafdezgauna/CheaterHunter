function [ kmsAboveSpeedLimit, percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
deltaDriverLogKm=(driverLogKm(length(driverLogKm))/numSlices);
distance= (0: deltaDriverLogKm: driverLogKm(length(driverLogKm)));

kmsAboveSpeedLimit=0;
for a=distance
    s = interpolatedlinearly (driverLogKm, driverLogSpeed, a );
       sp = interpolateToTheLeft ( limitKms,  limitSpeeds, a);
      
    if s > sp 
        
   kmsAboveSpeedLimit= kmsAboveSpeedLimit + deltaDriverLogKm;
    end 
   

end
percentAboveSpeedLimit= (kmsAboveSpeedLimit)*100/(distance(length(distance)));
end


menu= sprintf('\t ####### MENU ########: \n 1. Erakutsi bideen plotak eta estadistikak \n 2. Erakutsi gidarien plot eta estadistikak \n 3. Denbora kalkulua gidari eta bide bakoitzeko \n 4. Konprobatu abiadura limiteak errepide bakoitzeko \n 5. Erregai kontsumoa gidari eta errepide bakoitzeko \n 6. Irten');
clc
disp(menu)
aukera= input('Aukeratu opzio bat: '); 
while aukera~=6
    switch aukera
 
     case 1
         clc
        Ataza1 
        input('Sakatu enter menura bueltatzeko')
        clc
        disp (menu)
         aukera= input('Aukeratu opzio bat:');
        
    case 2
        clc
        Ataza21
        Ataza22
        input('Sakatu enter menura bueltatzeko')
      clc
        disp (menu)
         aukera= input('Aukeratu opzio bat: ');
        
     case 3
         clc
        disp('Denbora kalkulua gidari eta bide bakoitzeko')
        Ataza46
       
        input('Sakatu enter menura bueltatzeko')
        clc
        disp (menu)
         aukera= input('Aukeratu opzio bat: ');
         
     case 4
         clc
        disp('Konprobatu abiadura limiteak errepide bakoitzeko')
        Ataza53
     
        input('Sakatu enter menura bueltatzeko')
        clc
        disp (menu)
        aukera= input('Aukeratu opzio bat: ');
         
    case 5
        clc
        i=1;
        while i<=4
        disp ('loading...' )
        pause(2)
        i=i+1;
        end
        disp('error404  ....  file not found')
        pause(3)
        disp('ez dugu egin lasai ez digu denborarik eman')
        input('Sakatu enter menura bueltatzeko')
        clc
        disp (menu)
         aukera= input('Aukeratu opzio bat: ');
        
    
        otherwise
       clc
            disp('Aukeratu 1 eta 6 arteko zenbaki bat')
            
              disp (menu)
            aukera= input('Aukeratu opzio bat: (Menura bueltatzeko sakatu "enter")');
    
    end
          

end
clc
disp('Agur, ondo ibili ;-)')
%INTENTO DE CONSEGUIR QUE ME LEA LOS DATOS DE LAS DOS RUTAS

%USAR EL HOLD ON PARA QUE NO ME BORRE LA OTRA GRAFICA, DONDE PONERLO??
for route={'a1','n1'}
  
   filename=sprintf('%s-height.csv',char(route));
  
   heightsvector=dlmread(filename,',',1,0);
   plot(heightsvector)
   
                subplot(2,2,1);
                hold on
                plot(heightsvector(:,1),heightsvector(:,2));
                title('ROUTES');
                xlabel('Longitudes(km)');
                ylabel('Latitudes(km)');
                
                
                subplot(2,1,2); 
                plot(heightsvector(:,4),heightsvector(:,3));
                title('ROUTE ELEVATIONS');
                xlabel('Distance from the origin(km)');
                ylabel('Height(m)');
             
        vectormeanheight=heightsvector(:,3);
        meanheight=mean(vectormeanheight);
        standard=std(vectormeanheight);
        minn=min(vectormeanheight);
        maxx=max(vectormeanheight);
        fprintf('\n %s route statistics:\n Mean height: %.2f (sd: %.2f)\n Height range:[%.2f, %.2f]',route,meanheight,standard,minn,maxx)
                
end
                
    
      



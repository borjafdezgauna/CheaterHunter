

for route={'a1','n1'}

        getrouteinformation(route);
         
        
end
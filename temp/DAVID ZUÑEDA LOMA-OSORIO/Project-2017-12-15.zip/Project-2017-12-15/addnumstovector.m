v=zeros(1,10);
 i=1;
for x=1:length(v)
   temp=i;
   v(x)=temp;
   i=i+1;
   
    
end
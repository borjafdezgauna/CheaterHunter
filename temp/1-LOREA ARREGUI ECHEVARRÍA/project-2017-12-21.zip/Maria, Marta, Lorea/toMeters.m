
%Creamos una funcion para pasar los kms a metros 
function[m]=toMeters(km)

 m=km*1000;
 
 end
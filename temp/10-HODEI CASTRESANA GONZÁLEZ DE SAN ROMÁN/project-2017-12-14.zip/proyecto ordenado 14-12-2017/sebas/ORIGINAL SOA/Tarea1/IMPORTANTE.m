% TAREA 1

for ruta={'a1','n1'}
    filename = sprintf('%s-height.csv',ruta{1}) ;
    M = dlmread (filename,',',1,0);


      distancia1= M(:,4);
     
      lactitude=M(:,1);
      
      elevation_a1=M(:,3);
      
      gradiante_1=M(:,5);
      
      longitud=M(:,2);
      
      subplot(1,2,1);
      
    hold on


    p1 = plot(distancia1,elevation_a1);

%    set(p1,'color','red','linewidth',2)
%    set(p2,'color','blue','linewidth',1)

    ylabel('x');
    xlabel('y');
    title('grafica')


    subplot(1,2,2)
    hold on
    p2 = plot(longitud,lactitude);
    
    ylabel('x');
    xlabel('y');
    title('secondgrafica')
end
function [t,h] = simulate_free_fall (h_0, total_time , delta_t)
num_steps=1+(total_time/delta_t);
h=zeros(num_steps,1);
t=zeros(num_steps,1);
h(1)=h_0;
t(1)=0;
g=9.8;
v=0;
for i=2:num_steps
    t(i)=t(i-1)+delta_t;
    v=v+g*delta_t;
    h(i)=h(i-1)-v*delta_t;
    if (h(i)<0)
        h(i)=0;
    end
end
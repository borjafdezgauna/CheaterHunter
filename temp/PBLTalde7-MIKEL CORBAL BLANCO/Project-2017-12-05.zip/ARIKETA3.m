 fprintf('#### MENU #####\n');
 fprintf('1. show route plots/statistics\n');
 fprintf('2. show driver plots/static\n');
 fprintf('3. time calculations for each driver/route\n');
 fprintf('4. check speed limit\n');
 fprintf('5. fuel consumption calculation\n');
fprintf('6. exit\n');
a= input('choose an option');
while a~=6
    if a== 1
    Ariketa1
elseif a==2
    bueno
elseif a>=7
    input('1tik 6rako zenbaki bat erabili behar da')
end

fprintf('#### MENU #####\n');
 fprintf('1. show route plots/statistics\n');
 fprintf('2. show driver plots/static\n');
 fprintf('3. time calculations for each driver/route\n');
 fprintf('4. check speed limit\n');
 fprintf('5. fuel consumption calculation\n');
fprintf('6. exit\n');
a= input('choose an option');
end
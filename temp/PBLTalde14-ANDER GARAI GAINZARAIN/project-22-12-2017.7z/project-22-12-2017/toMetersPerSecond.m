function [ msSpeed ] = toMetersPerSecond( speedKmH )

    msSpeed=(speedKmH*1000)/3600; %metro segundutara pasatzeko formula idatzi

end
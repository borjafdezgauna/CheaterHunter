function [ m ] = toMeters( km )

    metroak=km*1000; %metroetara pasatzeko formula
    m=metroak;
    
end
function [ msSpeed ] = toMetersPerSecond( speedKmH ) 
  toMetersPerSecond = speedKmH*10^3/3600
  end
%read data

%subplots


for road={'n1','a1'}
   for i=1:2
   driver_name=sprintf('%s-driver%d-log.csv',road{1},i);
   driver_data=dlmread(driver_name,',');
   driver_name_title=sprintf('driver%d',i);
   subplot(1,2,i)
   plot(driver_data(:,1),driver_data(:,2))
   title(driver_name_title)
   xlabel('Distance(Km)')
   ylabel('Speed(Km/h) ')
   hold on
%statistics
   avg=sum(driver_data(:,2))/length(driver_data(:,2));
   standard_deviation = std(driver_data(:,2));
   min_speed=min(driver_data(:,2));
   max_speed=max(driver_data(:,2));
   fprintf('Driver%d statistics in route %s \n Mean speed::%f  km/h (sd:%f) \n Min-Max speed:[%f,%f] \n \n', i,road{1},avg,standard_deviation, min_speed,max_speed)
    end
end

function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
i=1;
while x>xVector(i)
    i=i+1
end

if i==1
    interpolatedY=yVector(i)
else
    interpolatedY=(yVector(i-1)*(xVector(i)-x)+yVector(i)*(x-xVector(i-1)))/(xVector(i)-xVector(i-1));
end

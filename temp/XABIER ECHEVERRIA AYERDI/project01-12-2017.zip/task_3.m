fprintf('####### MENU ########: \n 1. Show route plots/statistics \n 2. Show driver plots/statistics \n 3. Time calculations for each driver/route \n 4. Check speed limits \n 5. Fuel consumption calculations for each driver/route \n 6. Exit \n ')
input_number= input('Choose an option ');
while input_number~=6
    
    switch input_number
        
        case 1
            task_1   
            a=input('Press any key to continue');
        case 2
            task_2
            a=input('Press any key to continue');
        case 3
           
        case 4
            
        case 5
            
        case 6
            
        otherwise 
            disp('Number must be between 0-6')
            
    end
    fprintf('####### MENU ########: \n 1. Show route plots/statistics \n 2. Show driver plots/statistics \n 3. Time calculations for each driver/route \n 4. Check speed limits \n 5. Fuel consumption calculations for each driver/route \n 6. Exit \n ')
    input_number= input('Choose an option ');
end

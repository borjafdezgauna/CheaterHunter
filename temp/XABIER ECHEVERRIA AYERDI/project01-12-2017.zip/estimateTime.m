function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
m=toMeters( kms );
ms=toMetersPerSecond( speedKmH );
estimatedTime=0
vp=[]
vp(1)=0


for i=2:numSlices
    
    p=interpolateLinearly( m, ms , i)
    vp(i)=p
    ds=m(i)-m(i-1)
    
    dv=vp(i)-vp(i-1)
    dt=ds./dv
    estimatedTime=estimatedTime+dt
    
    
end

    
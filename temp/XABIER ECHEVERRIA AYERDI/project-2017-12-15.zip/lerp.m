function [interpolatedY] = lerp (xvalues, yvalues,x)

%Find between which two points is x
i=1;
while xvalues(i)<=x
i= i+1;
end

y2= yvalues(i);
y1= yvalues(i-1);
x2= xvalues(i);
x1= xvalues(i-1);

slope= (y2-y1)/(x2-x1);

interpolatedY= y1 + slope * (x-x1);

end

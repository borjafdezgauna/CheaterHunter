 function [ m ] = toMeters( km )      %be sure that it is positive(with negatives will work as well)
m=km*1000;
end
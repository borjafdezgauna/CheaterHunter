temperatures= dlmread('temperatures.txt',' ');
flightlog= dlmread('flight-log.txt',',');
duration= flightlog(end,1);

delta_t=100;
avgTemp= 0;
numSlices= duration/delta_t;

for i=1:numSlices
  t= (i-1)*delta_t;
  interpolatedHeight= lerp(flightlog(:,1),flightlog(:,2),t);
  interpolatedTemp= lerp(temperatures(:,1),temperatures(:,2),interpolatedHeight);
  
  avgTemp= avgTemp + interpolatedTemp*delta_t;
end
  avgTemp= avgTemp / duration;

  fprintf('The average temperature is %.2f\n',avgTemp);
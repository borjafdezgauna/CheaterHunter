function [ fuelExpenditure ] = calculateFuelExpenditure(v,a,theta,d)
speed=toMetersPerSecond(v);
s=toMeters(d);
fuelExpenditure= (s*(0.00009*speed+(0.021*a+0.087*theta)^2))/33;

end
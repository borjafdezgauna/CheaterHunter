function [ fuelExpenditure ] =calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices )
routemeters=toMeters(routeKms);
routeHeight=toMeters(routeHeights);
routeemeters=toMeters(logKms);
routespeed=toMetersPerSecond(logSpeeds);
position=2;
as(1)=0;
heights(1)=routeHeight(1);
diff=max(routeemeters)/numSlices;
fuelExpenditure=0
%calculations for the data we want
for p=linspace(min(logKms),max(logKms),numSlices)
speed= interpolateLinearly(logKms,logSpeeds,p)
as(position)=speed
a=(as(position)-as(position-1))/diff
heights(position)=interpolateLinearly(routemeters,routeHeight,p)
y=heights(position)-heights(position-1)
theta=atan(y/diff)
fuel=calculateFuelExpenditure(speed,a,theta,p)
fuelExpenditure=fuelExpenditure+fuel
position=position+1
end
end
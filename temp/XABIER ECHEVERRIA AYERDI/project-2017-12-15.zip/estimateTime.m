function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
m=toMeters( kms );
ms=toMetersPerSecond( speedKmH );
estimatedTime=0;
ds=(max(m)-min(m))/numSlices;

for i = linspace(ds,max(m),numSlices-1)
    interpolatedSpeed=interpolateLinearly( m, ms , i); %This is correct
    dt=ds/interpolatedSpeed;
    estimatedTime=estimatedTime+dt; %Looks correct
    
    
end

end


%1.ATAZA

artxiboarenizena={'a1-height.csv','n1-height.csv'}
for i=artxiboarenizena
data=dlmread(i{1},',',1,0);
latitude=data(:,1);
longitud=data(:,2);
altuera=data(:,3);
distantzia=data(:,4);
hold on 
subplot(2,1,1);
plot(distantzia,altuera)
title('errepideen erliebeak')
xlabel('distantzia')
ylabel('altuera')
hold off
hold on
subplot(2,1,2);
plot(latitude,longitud)
title('errepideen bideak')
xlabel('latituidea')
ylabel('longitudea')
hold off
saveas(gcf,'route-elevations.png')
mediaAltuera= mean(altuera)
desbideratzeEstandarraAltuera= std(altuera)
maxAltuera= max(altuera)
minAltuera= min(altuera)
fprintf('%f\n',mediaAltuera);
fprintf('%f\n',desbideratzeEstandarraAltuera);
fprintf('%f\n',maxAltuera);
fprintf('%f\n',minAltuera);
end




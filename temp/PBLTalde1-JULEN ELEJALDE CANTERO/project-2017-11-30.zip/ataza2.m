
%2.ATAZA
id=1;
lehenengoa={'a1','n1'}
bigarrena={'driver1','driver2'}
for i = lehenengoa
    for j = bigarrena
        izena=sprintf('%s-%s-log.csv',i{1},j{1})
        data1=dlmread(izena);
        distantzia1=data1(:,1);
        abiadura1=data1(:,2);
      hold on
        subplot(1,2,id);
        plot(distantzia1,abiadura1)
        title('Distantzia/abiadura')
        xlabel('distantzia1(km)')
        ylabel('abiadura1(m/s)')
      hold off
        mediaabiadura1= mean(abiadura1)
        desbideratzeEstandarraabiadura1= std(abiadura1)
        maxabiadura1= max(abiadura1)
        minabiadura1= min(abiadura1)
        fprintf('%f\n',mediaabiadura1);
        fprintf('%f\n',desbideratzeEstandarraabiadura1);
        fprintf('%f\n',maxabiadura1);
        fprintf('%f\n',minabiadura1);
    end 
    id=id+1
end
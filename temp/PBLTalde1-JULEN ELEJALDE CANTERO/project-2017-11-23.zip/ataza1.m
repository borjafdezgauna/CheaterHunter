archiboarenizena={'a1-height.csv','n1-height.csv'}
for i=archiboarenizena
data=dlmread(i{1},',',1,0);
latitude=data(:,1);
longitud=data(:,2)
altuera=data(:,3);
distantzia=data(:,4);
subplot(1,2);
plot(altuera,distantzia,'b-')
plot(altitudea,longitudea,'g-')
end




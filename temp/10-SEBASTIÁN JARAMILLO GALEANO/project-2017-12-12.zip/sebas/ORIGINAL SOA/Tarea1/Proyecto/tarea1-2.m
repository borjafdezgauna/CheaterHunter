%Tarea 1.2

for ruta={'a1','n1'}
    filename = sprintf('%s-height.csv',ruta{1}) ;
    M = dlmread (filename,',',1,0);


%Estad�sticas de la ruta n1:
mediatotaln1=mean(M=dlmread('n1-height.csv',',',1,0));
Alturamedia =mediatotaln1(M(:,3));
desviacionn1 =std(M(:,3));
Rangodealturas=[min(M(:,3)),max(M(:,3))];



%Estad�sticas de la ruta a1:
mediatotala1= mean('a1-height.csv');
AlturaMedia =mediatotala1(M(:,3));
Desviaciona1 =std(M(:,3));
RangoDeAlturas=[min(M(:,3)),max(M(:,3))];
end
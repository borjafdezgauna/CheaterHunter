function y=interpolateLinearly(xv,yv,x)
      i=1;
      while x>=xv(i) && i<=(length(xv)-1)
         i=i+1;
      end
      y1=yv(i-1);
      y2=yv(i);
      x1=xv(i-1);
      x2=xv(i);
      slope=(y2-y1)/(x2-x1);
      y=y1+slope*(x-x1);
end
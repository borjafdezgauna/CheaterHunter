clc;
clear;

d1n1=dlmread('project-files/n1-driver1-log.csv',',');

n1=dlmread('project-files/n1-speed-limit.csv',';');



slc=abs((d1n1(end,1)-d1n1(1,1))*toMeters(mean(diff(d1n1(:,1)))));

[dist,percent]=checkSpeedLimits(d1n1(:,1)',d1n1(:,2)',n1(:,1)',n1(:,2)',slc)
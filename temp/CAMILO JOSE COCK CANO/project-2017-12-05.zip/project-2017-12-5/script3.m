clc;
routes={'n1','a1'};

for i=1:2
   f1=sprintf('project-files/%s-driver1-log.csv',routes{i});
   f2=sprintf('project-files/%s-driver2-log.csv',routes{i});
   
   d1=dlmread(f1,',');
   d2=dlmread(f2,',');
   
   slc1=abs((d1(end,1)-d1(1,1))*toMeters(mean(diff(d1(:,1)))));
   
   slc2=abs((d2(end,1)-d2(1,1))*toMeters(mean(diff(d2(:,1)))));

   td1=toHMS(estimateTime(d1(:,1)',d1(:,2)',slc1));
   td2=toHMS(estimateTime(d2(:,1)',d2(:,2)',slc2));

   fprintf('Estimated time for driver 1 in route %s: %s\n',routes{i},td1);
   fprintf('Estimated time for driver 2 in route %s: %s\n',routes{i},td2);
end
function [dist,percent]=checkSpeedLimits(drivx,drivspd,distlim,spdlim,slices)
   dx=drivx(1,end)/slices;
   x=drivx(1);
   d=0;
   for i=1:slices
      ydriv=interpolateLinearly(drivx,drivspd,x);
      ylim=interpolateToTheLeft(distlim,spdlim,x);
      if ydriv>ylim
         d=d+1;
      end
      x=x+dx;
   end
   dist=d;
   percent=(dist/abs((drivx(end,1)-drivx(1,1))))*100;
end
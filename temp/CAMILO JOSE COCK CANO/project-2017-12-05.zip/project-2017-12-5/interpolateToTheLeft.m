function y=interpolateToTheLeft(xv,yv,x)
   if x>=xv(1,end)
   	y=yv(1,end);
   else
   	i=1;
      while x>=xv(i) && i<=(length(xv)-1)
         i=i+1;
      end
      y=yv(i-1);
   end
end
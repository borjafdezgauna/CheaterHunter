function [eTime]=estimateTime(kms,speedKmH,numSlices)

delta_x=kms(1,end)/numSlices;
eTime=0;

for i=1:numSlices
  x=(i-1)*delta_x;
  iTime=interpolateLinearly(kms,speedKmH,x);
  eTime=eTime+iTime*delta_x;
end

end
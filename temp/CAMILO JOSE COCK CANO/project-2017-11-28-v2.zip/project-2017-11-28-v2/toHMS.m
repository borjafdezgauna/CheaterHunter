function [hms]=toHMS(secs)

   h=fix(secs/3600);
   m=fix((rem(secs,3600))/60);
   s=fix((rem(secs,60)));

   hms=sprintf('%02d:%02d:%02d',h,m,s);

end
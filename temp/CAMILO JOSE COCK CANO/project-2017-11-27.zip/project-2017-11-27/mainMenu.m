clear;
clc;

option=0;

while option~=6
   option=input('####### MENU ########:\n 1. Show route plots/statistics\n 2. Show driver plots/statistics\n 3. Time calculations for each driver/route\n 4. Check speed limits\n 5. Fuel consumption calculations for each driver/route\n 6. Exit\nChoose an option: ');
   if option>6 || option<1
      fprintf('Incorrect option: it must between 1 and 6.\n')
   end
   switch option   
      case 1
         task1
      case 2
         task2
   end
   clc;
end
function y = interpolateLinearly(xv, yv, x)
i = length(xv) - 1;
while x < xv(i)
   i = i - 1;
end
y1 = yv(i);
y2 = yv(i+1);
x1 = xv(i);
x2 = xv(i+1);
slope = (y2 - y1) / (x2 - x1);
y = y1 + slope * (x - x1);
end
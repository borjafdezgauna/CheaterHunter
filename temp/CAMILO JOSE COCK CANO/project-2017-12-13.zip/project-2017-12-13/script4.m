clc;
routes = {'n1', 'a1'};
drvs = {'driver1', 'driver2'};
anamsg = ('Analyzing: Driver= %s, Route= %s\n');
risk0 = ('No risk of infraction\n\n');
risk1 = ('Mild infraction risk: Kms above the speed limit= %.2f (%.2f%% of the route)\n\n');
risk2 = ('HIGH INFRACTION RISK: Kms above the speed limit= %.2f (%.2f%% of the route)\n\n');
for i = 1:2
   rf = sprintf('project-files/%s-speed-limit.csv', routes{i});
   rd = dlmread(rf, ';');
   for b = 1:2
      file = sprintf('project-files/%s-%s-log.csv', routes{i}, drvs{b});
      data = dlmread(file, ',');
      slc = fix(toMeters(data(end, 1)));
      [dist, percent] = checkSpeedLimits(data(:, 1)', data(:, 2)', rd(:, 1)', rd(:, 2)', slc);
      fprintf(anamsg, drvs{b}, routes{i});
      if percent > 0 && percent <= 10
         fprintf(risk1, dist, percent);
      elseif percent == 0
         fprintf(risk0);
      else
         fprintf(risk2, dist, percent);
      end
   end
end
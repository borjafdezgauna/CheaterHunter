clc;
routes = {'n1', 'a1'};
drvs = {'driver1', 'driver2'};
anamsg = ('Analyzing: Driver= %s, Route= %s\n');
msg = ('Estimated fuel consumption: %f liters of fuel\n\n');
for i = 1:2
   rf = sprintf('project-files/%s-height.csv', routes{i});
   rd = dlmread(rf, ',', 1, 0);
   slc = fix(toMeters(rd(end, 4)));
   for j = 1:2
      file = sprintf('project-files/%s-%s-log.csv', routes{i}, drvs{j});
      data = dlmread(file, ',');
      rfuelExp = calculateRouteFuelExpenditure(rd(:, 4)', rd(:, 3)', data(:, 1)', data(:, 2)', slc);
      fprintf(anamsg, drvs{j}, routes{i});
      fprintf(msg, rfuelExp);
   end
end
function [dist, percent] = checkSpeedLimits(drivx, drivspd, distlim, spdlim, slc)
dx = drivx(1, end) / slc;
x = drivx(1);
d = 0;
for i = 1:slc
   ydriv = interpolateLinearly(drivx, drivspd, x);
   ylim = interpolateToTheLeft(distlim, spdlim, x);
   if ydriv > ylim
      d = d + 1;
   end
   x = x + dx;
end
dist = d / 1000;
percent = (d / slc) * 100;
end
clear;
clc;
opt = 0;
menu = ('####### MENU ########:\n1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit\nChoose an option: ');
cont = ('\nPress any key to continue');
while opt ~= 6
   clc;
   opt = input(menu);
   if opt > 6 || opt < 1
      clc;
      fprintf('\nIncorrect option: it must between 1 and 6.\n')
      input(cont);
   end
   switch opt
      case 1
         script1
         input(cont);
      case 2
         script2
         input(cont);
      case 3 
         script3
         input(cont);
      case 4
         script4
         input(cont);
      case 5
         script5
         input(cont);
   end
end
clear;
clc;
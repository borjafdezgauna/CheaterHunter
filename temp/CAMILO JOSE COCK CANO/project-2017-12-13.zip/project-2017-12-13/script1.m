clc;
clf;
routes = {'n1', 'a1'};
msg = ('\n%s route statistics:\nMean height: %.2f (sd: %.2f)\nHeight range: [%.2f, %.2f]\n');
subplot(1, 2, 1);
title('Elevation/Distance'); xlabel('Distance (km)'); ylabel('Elevation (m)');
subplot(1, 2, 2);
title('Route'); xlabel('Logitude'); ylabel('Latitude');
for i = 1:2
   filename = sprintf('project-files/%s-height.csv', routes{i});
   data = dlmread(filename, ',', 1, 0);
   subplot(1, 2, 1);
   hold on
   plot(data(:, 4), data(:, 3));
   subplot(1, 2, 2);
   hold on
   plot(data(:, 2), data(:, 1));
   rstats = [mean(data(:, 3)), std(data(:, 3)), min(data(:, 3)), max(data(:, 3))];
   fprintf(msg, routes{i}, rstats(1), rstats(2), rstats(3), rstats(4));
end
saveas(gcf, 'route-elevations.png');
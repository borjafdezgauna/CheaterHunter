clc;
routes = {'n1', 'a1'};
drvs = {'driver1', 'driver2'};
for i = 1:2
   for j = 1:2
      file = sprintf('project-files/%s-%s-log.csv', routes{i}, drvs{j});
      data = dlmread(file, ',');
      slc = fix(toMeters(data(end, 1)));
      rt = toHMS(estimateTime(data(:, 1)', data(:, 2)', slc));
      fprintf('Estimated time for %s in route %s: %s\n', drvs{j}, routes{i}, rt);
   end
end
function rfuelExp = calculateRouteFuelExpenditure(rKms, rHeights, logKms, logSpeeds, slc)
xD = rKms(1, end) / slc;
rfuelExp = 0;
x1 = rKms(1);
h1 = rHeights(1);
d = toMeters(xD);
for i = 1:slc
   x2 = x1 + xD;
   h2 = interpolateLinearly(rKms, rHeights, x2);
   theta = atan((h2 - h1)/(toMeters(x2) - toMeters(x1)));
   s1 = toMetersPerSecond(interpolateLinearly(logKms, logSpeeds, x1));
   s2 = toMetersPerSecond(interpolateLinearly(logKms, logSpeeds, x2));
   a = s2 - s1;
   f = calculateFuelExpenditure(s1, a, theta, d);
   rfuelExp = rfuelExp + f;
   x1 = x1 + xD;
   h1 = interpolateLinearly(rKms, rHeights, x1);
end
end
function y = interpolateToTheLeft(xv, yv, x)
i = length(xv);
while x < xv(i)
   i = i - 1;
end
y = yv(i);
end
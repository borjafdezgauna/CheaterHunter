clc;
clf;
routes = {'n1', 'a1'};
drvs = {'driver1', 'driver2'};
msg = ('\n%s statistics in route %s:\nMean speed: %.2f km/h (sd: %.2f)\nMin-Max speed: [%.2f, %.2f]\n');
for i = 1:2
   for j = 1:2
      file = sprintf('project-files/%s-%s-log.csv', routes{i}, drvs{j});
      data = dlmread(file, ',');
      subplot(1, 2, i);
      hold on
      plot(data(:, 1), data(:, 2));
      stats = [mean(data(:, 2)), std(data(:, 2)), min(data(:, 2)), max(data(:, 2))];
      fprintf(msg, drvs{1}, routes{i}, stats(1), stats(2), stats(3), stats(4));
   end
   titl = sprintf('%s(Speed/Distance)', routes{i});
   subplot(1, 2, i);
   title(titl); xlabel('Distance (km)'); ylabel('Speed (km/h)'); legend('Driver 1', 'Driver 2');
end
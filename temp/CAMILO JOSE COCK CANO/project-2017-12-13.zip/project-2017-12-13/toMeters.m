function m = toMeters(km)
m = 1000 * km;
end
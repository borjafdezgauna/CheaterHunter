function hms = toHMS(sec)
h = fix(sec/3600);
m = fix(rem(sec, 3600)/60);
s = fix(rem(sec, 60));
hms = sprintf('%02d:%02d:%02d', h, m, s);
end
clear; % Clear the workspace (delete all variables to avoid any errors)
clc; % Clear the console

opt=0; % Set an initial value for the variable containing the variable

% String containing the menu text
menu=('####### MENU ########:\n1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit\nChoose an option: ');

% String containing the continue message
cont=('\nPress any key to continue');

while opt~=6 % Infite loop used to show the main menu and execute tasks, it ends when the user inputs the command "6"
   
   clc; % Clear console
   
   opt=input(menu); % Print the menu in console and prompt the user for an option
   
   % The option must be inside the menu range, otherwise it'll show an eror message
   if opt>6 || opt<1
      clc;
      fprintf('\nIncorrect option: it must between 1 and 6.\n')
      input(cont);
   end
   
   switch opt  % Switch structure that executes the command corresponding to the users input 
      
      case 1 % Show route plots/statistics
         script1
         input(cont); % Pause and wait for the user to continue
         
      case 2 % Show driver plots/statistics
         script2
         input(cont); % Pause and wait for the user to continue
         
      case 3 % Time calculations for each driver/route
         script3
         input(cont); % Pause and wait for the user to continue
   end 
   
end

clear; % Clear workspace after finishing the program
clc;  % Clear console
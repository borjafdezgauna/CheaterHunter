clc;  % Clear console
clf;  % Clear graph data

routes={'n1','a1'}; % String vector containing the route names

% String containing the console message
msg=['\n%s route statistics:\nMean height: %.2f (sd: %.2f)\nHeight range: [%.2f, %.2f]\n'];

%Set title and labels for both plots (subplot(1,2,n)=1 row and 2 plot columns)
subplot(1,2,1); %Plot 1
title('Elevation/Distance');xlabel('Distance (km)');ylabel('Elevation (m)');
subplot(1,2,2); %Plot 2
title('Route');xlabel('Logitude');ylabel('Latitude');

for i=1:2 %Loop used to generate both plots and console messages for the data files
   %Build the string that contains the file name
   filename=sprintf('project-files/%s-height.csv',routes{i});
   
   %Read the data from the height file as a matrix inside "data", skipping the first row, as it contains headers
   data=dlmread(filename,',',1,0);
   
   %Plot height vs elevation in the first subplot
   subplot(1,2,1);
   hold on
   plot(data(:,4),data(:,3));
   
   %Plot latitude vs longitude in the second plot
   subplot(1,2,2);
   hold on
   plot(data(:,2),data(:,1));
   
   %Calculate height statistics and save them in the "rstats" vector
   rstats=[mean(data(:,3)) std(data(:,3)) min(data(:,3)) max(data(:,3))];
   
   %Console output using the string inside "msg", the route name and the stats inside "rstats"
   fprintf(msg,routes{i},rstats(1),rstats(2),rstats(3),rstats(4));
end

%Save the plotted data as a .png file
saveas(gcf,'route-elevations.png');
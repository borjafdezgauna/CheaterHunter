function ms=toMetersPerSecond(kmh)
   ms=kmh/3.6;
end
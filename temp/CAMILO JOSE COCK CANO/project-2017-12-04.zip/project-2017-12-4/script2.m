clc; % Clear console
clf; % Clear graph data

routes={'n1','a1'}; %String vector containing the route names

drvrs={'Driver 1','Driver 2'}; %String vector containing the driver names

%Set title and labels for both plots (subplot(1,2,n)=1 row and 2 plot columns)
subplot(1,2,1); %Plot 1
title('N1(Speed/Distance)');xlabel('Distance (km)');ylabel('Speed (km/h)');
subplot(1,2,2); %Plot 2
title('A1(Speed/Distance)');xlabel('Distance (km)');ylabel('Speed (km/h)');

%String containing the console message
msg=('%s statistics in route %s:\nMean speed: %.2f km/h (sd: %.2f)\nMin-Max speed: [%.2f, %.2f]\n\n');

for i=1:2 %Loop used to generate both plots and console messages for the data files
   %Build the string that contains the file name for the driver 1 log
   f1=sprintf('project-files/%s-driver1-log.csv',routes{i});
   %Build the string that contains the file name for the driver 2 log
   f2=sprintf('project-files/%s-driver2-log.csv',routes{i});
   
   %Read the data from the driver 1 log file as a matrix inside "d1"
   d1=dlmread(f1,',');
   %Read the data from the driver 2 log file as a matrix inside "d2"
   d2=dlmread(f2,',');
   
   %Plot distance vs speed for each driver on the corresponding route plot
   subplot(1,2,i);
   hold on
   plot(d1(:,1),d1(:,2));
   plot(d2(:,1),d2(:,2));
   legend('Driver 1','Driver 2');
   
   %Calculate driver 1 statistics and save them in the "d1s" vector
   d1s=[mean(d1(:,2)) std(d1(:,2)) min(d1(:,2)) max(d1(:,2))];
   
   %Calculate driver 2 statistics and save them in the "d2s" vector
   d2s=[mean(d2(:,2)) std(d2(:,2)) min(d2(:,2)) max(d2(:,2))];
   
   %Console output using the string inside "msg" and the driver 1 stats inside "d1s"
   fprintf(msg,drvrs{1},routes{i},d1s(1),d1s(2),d1s(3),d1s(4));
   
   %Console output using the string inside "msg" and the driver 2 stats inside "d2s"
   fprintf(msg,drvrs{2},routes{i},d2s(1),d2s(2),d2s(3),d2s(4));
end
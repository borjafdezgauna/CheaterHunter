function et=estimateTime(x,v,slices)
   dx=x(1,end)/slices;
   et=0;
   x1=x(1);
   for i=1:slices
     x2=x1+dx;
     y=interpolateLinearly(x,v,x2);
     t=(toMeters(x2)-toMeters(x1))/toMetersPerSecond(y);
     et=et+t;
     x1=x1+dx;
   end
end
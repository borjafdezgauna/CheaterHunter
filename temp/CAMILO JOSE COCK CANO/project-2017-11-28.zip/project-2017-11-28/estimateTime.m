function [estimatedTime]=estimateTime(kms,speedKmH,numSlices)

totalx=kms(end,1);
delta_x=totalx/numSlices;

for i=1:numSlices
  x=(i-1)*delta_x;
  interpolatedTime=interpolateLinearly((kms(i)),(speedKmH(i)),x);
  estimatedTime=estimatedTime+interpolatedTime*delta_x;
end

end
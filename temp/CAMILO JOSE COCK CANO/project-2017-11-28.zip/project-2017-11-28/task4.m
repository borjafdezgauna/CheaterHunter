clc;

d1n1=dlmread('n1-driver1-log.csv',',');
d1a1=dlmread('a1-driver1-log.csv',',');
d2n1=dlmread('n1-driver2-log.csv',',');
d2a1=dlmread('a1-driver2-log.csv',',');

estimateTime([0 1 2 3],[40 50 40 30],1000)
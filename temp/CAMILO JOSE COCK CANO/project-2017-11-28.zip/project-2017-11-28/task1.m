clc;
n1=dlmread('n1-height.csv',',',1,0);
a1=dlmread('a1-height.csv',',',1,0);
subplot(1,2,1);
hold on
plot(n1(:,4),n1(:,3));
plot(a1(:,4),a1(:,3));
title('Elevation/Distance');
xlabel('Distance (km)');
ylabel('Elevation (m)');
subplot(1,2,2);
hold on
plot(n1(:,2),n1(:,1));
plot(a1(:,2),a1(:,1));
title('Route');
xlabel('Logitude');
ylabel('Latitude');
saveas(gcf,'routeelevations.png');
avgn1=mean(n1(:,3));
sdn1=std(n1(:,3));
minn1=min(n1(:,3));
maxn1=max(n1(:,3));
avga1=mean(a1(:,3));
sda1=std(a1(:,3));
mina1=min(a1(:,3));
maxa1=max(a1(:,3));
fprintf('n1 route statistics:\n Mean height: %.2f (sd: %.2f)\n Height range: [%.2f, %.2f]\n\n',avgn1,sdn1,minn1,maxn1);
fprintf('a1 route statistics:\n Mean height: %.2f (sd: %.2f)\n Height range: [%.2f, %.2f]\n\n',avga1,sda1,mina1,maxa1);

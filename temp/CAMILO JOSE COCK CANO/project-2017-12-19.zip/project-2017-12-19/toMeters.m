function m = toMeters(km)
% This function gets a value in km and converts it to m
m = 1000 * km;
end
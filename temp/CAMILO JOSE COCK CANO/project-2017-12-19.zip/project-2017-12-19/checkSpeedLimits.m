function [dist, percent] = checkSpeedLimits(drivx, drivspd, distlim, spdlim, slc)

% This function gets vectors for the positions/speed for the driver, positions/speed for the speed limits
% and calculates the total amount of meters the driver drove over the limit

xD = drivx(1, end) / slc; % Calculates the xD (xDifferential) used in the for loop
x = drivx(1); % Set initial x value from the x vector
d = 0; % Set an initial value for the total distance calculation

for i = 1:slc
   vdriv = interpolateLinearly(drivx, drivspd, x); % Calculates the interpolated driver speed
   vlim = interpolateToTheLeft(distlim, spdlim, x); % Calculates the speed limit for that position
   
   if vdriv > vlim % Compares the driver speed vs the speed limit and if it is over the limit
                   % adds 1 meter to the total speed, because we divided the distance in "slc" slices
                   % which is calculated to be te amount of meters in the trip
      d = d + 1;
   end
   x = x + xD; % Calculates the next position for the integration
end
dist = d / 1000; % Converts the distance to km
percent = (d / slc) * 100; % Calculates the distance percentage
end
function y = interpolateLinearly(xv, yv, x)
% This function calculates the interpolated value for the entered x

% The i variable is the index used for the vector elements
% It works by comparing the entered x value and comparing it to the second x vector value
% if the x vector value is bigger it increases the i by 1 and continues searching.
i = 1;
while x >= xv(i+1) && i<(length(xv)-1)
   i = i + 1;
end

% Values from the x and y vector for the slope calculation
y1 = yv(i);
y2 = yv(i+1);
x1 = xv(i);
x2 = xv(i+1);
slope = (y2 - y1) / (x2 - x1);

% Calculate the interpolated y
y = y1 + slope * (x - x1);
end
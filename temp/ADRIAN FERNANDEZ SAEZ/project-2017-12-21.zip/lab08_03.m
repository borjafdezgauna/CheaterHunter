clear;
clc;
p1 = 'data/data-%02d.csv';
n = 12;
p2 = 'plots/plot_data-%02d.png';
analyzeDifferentDataFiles(p1, n, p2);
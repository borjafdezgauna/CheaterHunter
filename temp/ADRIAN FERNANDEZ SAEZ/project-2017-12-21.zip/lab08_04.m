function[sumValues biggerThan9500]=sensorValuesOperations(fileName)
fileName=dlmread(raw_data.csv);
r1=(1,:);
r2=(,:2)


c=unique(a)

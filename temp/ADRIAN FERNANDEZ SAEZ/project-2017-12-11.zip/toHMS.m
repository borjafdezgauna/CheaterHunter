function [ hms ] = toHMS( seconds )
h=(seconds/3600);
e= floor(h);
q= ((h-e)*60);
t= floor(q);
s= ((q-t)*60);
hms=sprintf('%2.0f:%2.0f:%2.0f',e,t,s);
end



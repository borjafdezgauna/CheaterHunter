function [ hms ] = toHMS( seconds )
h=rat(seconds/3600);
m=rat((seconds/60)-(h*60));
s=rat(seconds-(m*60+h*3600));
hms=sprintf('%s-%s-%s',h,m,s);
end

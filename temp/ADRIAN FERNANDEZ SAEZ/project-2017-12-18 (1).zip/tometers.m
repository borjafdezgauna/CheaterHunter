function [m] = tometers(km)
m = km*1000;
end

ruta=[n a];
driver=[1 2];

for i=1:length(ruta)
    for k=1:length(driver)
        sprintf('Estimated time for driver%d in route %s1',driver(k),ruta(i))
    end 
end

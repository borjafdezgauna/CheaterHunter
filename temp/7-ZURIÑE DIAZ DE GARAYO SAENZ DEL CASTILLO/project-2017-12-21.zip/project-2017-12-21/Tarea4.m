clc 
clear

for ruta={'n1','a1'}  
      rutaelegida=1;
           for conductor={'driver1','driver2'}
       
                ficheros=sprintf('%s-%s-log.csv',ruta{1},conductor{1});
                leerficheros=dlmread(ficheros,',',1,0);
                kms=leerficheros(:,1);
                speedKmH= leerficheros(:,2);
                
                numSlices=1000;
                estimatedTime = estimateTime(kms, speedKmH,numSlices);
                tiempoestimado=toHMS(estimatedTime);
                
            fprintf('Estimated time for %s in route %s: %s\n', conductor{1}, ruta{1}, tiempoestimado)
               
            rutaelegida=(rutaelegida + 1);
            
           end
      rutaelegida=1;
end   
disp('pulse una tecla') 
  pause        
function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
    t=0;
 
    e=(kms(end)-kms(1))/numSlices;
    
 
    for d= kms(1):e:kms(end)
       
        interpolatedSpeed= interpolateLinearly(kms,speedKmH,d);
        Time= toMeters(e)/ toMetersPerSecond(interpolatedSpeed);

        t= t+Time;

    end    
    estimatedTime=t;
end

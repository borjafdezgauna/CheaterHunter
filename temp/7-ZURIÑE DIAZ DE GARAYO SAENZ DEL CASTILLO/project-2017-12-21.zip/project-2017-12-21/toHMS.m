function [hms] = toHMS(s);
    horas=fix(s/3600);
    minutos =fix((s-(horas * 3600))/60);
    segundos =fix(s-(horas * 3600)-(minutos*60));
    hms=sprintf('%02d:%02d:%02d',horas, minutos, segundos);
end
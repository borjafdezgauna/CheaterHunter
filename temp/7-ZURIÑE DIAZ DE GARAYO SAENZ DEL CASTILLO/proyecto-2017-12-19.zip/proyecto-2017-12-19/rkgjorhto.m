 s=input('dame unos segundos')
 hms  = toHMS( s )
 
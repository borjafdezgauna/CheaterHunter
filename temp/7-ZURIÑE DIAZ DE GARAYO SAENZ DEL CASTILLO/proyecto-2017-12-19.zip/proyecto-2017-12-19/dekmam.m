x=input('Dame los kilometros');
res=toMeters(x);
fprintf('Esta distancia en metros es %d\n',res);
 s=input('dame unos segundos');
 res= toHMS( s );
 disp(res);
  
xVector=[10 20  40];
yVector=[120 150 130];
x=10;
res=interpolateLinearly (xVector, yVector , x);
fprintf('El valor interpolado es %d\n',res);
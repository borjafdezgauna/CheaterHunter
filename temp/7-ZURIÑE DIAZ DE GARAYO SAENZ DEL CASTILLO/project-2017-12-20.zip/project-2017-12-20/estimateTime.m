function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
 
    m=toMeters(kms);
    speedMS=toMetersPerSecond(speedKmH);
    interpolatedSpeed= interpolateLinearly(m,speedMS,numSlices);
    e=((kms(end))-0)/numSlices;
    estimatedTime=sum(e/interpolatedSpeed)
    
end

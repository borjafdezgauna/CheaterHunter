function [media,sd,rango]=valoresestadisticos(x)
   media=mean(x);
   sd=std(x);
   rango=iqr(x);%hay que cambiar algo
end
   
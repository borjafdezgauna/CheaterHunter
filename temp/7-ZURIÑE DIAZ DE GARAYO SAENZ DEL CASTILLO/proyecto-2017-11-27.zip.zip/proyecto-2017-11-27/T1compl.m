clc
clear
a1=dlmread('a1-height.csv',',',1,0);
n1=dlmread('n1-height.csv',',',1,0);

LatitudA1=a1(:,1);
LongitudA1=a1(:,2);
AlturaA1=a1(:,3);
DistanciaA1=a1(:,4);

LatitudN1=n1(:,1);
LongitudN1=n1(:,2);
AlturaN1=n1(:,3);
DistanciaN1=n1(:,4);

subplot(1,2,1)
Alturas=plot(DistanciaA1, AlturaA1, DistanciaN1, AlturaN1)
ylabel('altura')
xlabel('distancia')
title('alturas relativas a la distancia desde el origen')
legend('A1 route','N1 route')

subplot(1,2,2)
Latitudes=plot(LongitudA1, LatitudA1, LongitudN1, LatitudN1)
ylabel('latitud')
xlabel('longitud')
title('longitudes contra latitudes')
legend('A1 route','N1 route')

disp('Estad�sticas de la ruta n1')
[media,sd,rango]=valoresestadisticos(AlturaN1)
fprintf('Altura media:%f (sd.:%f)\n Rango de alturas:%f',media, sd, rango)
disp('Estad�sticas de la ruta a1')
[media,sd,rango]=valoresestadisticos(AlturaA1)
fprintf('Altura media:%f (sd.:%f)\n Rango de alturas:%f',media, sd, rango)
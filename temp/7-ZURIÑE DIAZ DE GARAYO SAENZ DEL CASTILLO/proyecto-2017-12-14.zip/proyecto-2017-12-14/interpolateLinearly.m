function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)

interpolatedY=  y0+(yVector/xVector)*(x-x0);

end
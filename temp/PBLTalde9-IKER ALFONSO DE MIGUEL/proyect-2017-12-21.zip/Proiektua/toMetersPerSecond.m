function [msSpeed]=toMetersPerSecond(speedKmH)
%%kilometro ordutik metro segunduetara pasatu 
msSpeed=speedKmH/3.6;
  end
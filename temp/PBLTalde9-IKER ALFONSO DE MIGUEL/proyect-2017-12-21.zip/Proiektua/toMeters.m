function [m]=toMeters(km)
%%kilometroak metroetara pasatzen dituen funtzioa  
m=km*1000;
  end
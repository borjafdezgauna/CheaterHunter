function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] =checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
  distantzia = (driverLogKm(end) -driverLogKm(1))/numSlices;
 kmsAboveSpeedLimit=0;
  for x = linspace(driverLogKm(1), driverLogKm(end), numSlices)
    [abiaduraLimitea]=interpolateToTheLeft(limitKms,limitSpeeds,x);
      [interpolatedAbiadura]=interpolateLinearly(driverLogKm,driverLogSpeed,x);
    if interpolatedAbiadura>=abiaduraLimitea
     kmsAboveSpeedLimit=kmsAboveSpeedLimit+distantzia;
    end
   
   percentAboveSpeedLimit =(kmsAboveSpeedLimit/driverLogKm(end))*100;
   
   
    
    end
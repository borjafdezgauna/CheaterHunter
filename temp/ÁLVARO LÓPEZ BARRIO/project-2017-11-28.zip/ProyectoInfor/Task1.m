%Task1: Write a script that analyzes the elevation profiles of both routes
n1_height=dlmread('n1-height.csv',',',1,0); %Load n1-height.csv skipping first line 
a1_height=dlmread('a1-height.csv',',',1,0); %Load a1-height.csv skipping first line
%Create each variable:
Latitude_n1=n1_height(:,1);
Longitude_n1=n1_height(:,2);
Elevation_n1=n1_height(:,3);
Distance_n1=n1_height(:,4);
Latitude_a1=a1_height(:,1);
Longitude_a1=a1_height(:,2);
Elevation_a1=a1_height(:,3);
Distance_a1=a1_height(:,4);
%Create the plot
PlotImage=figure();
subplot(1,2,1)
plot(Distance_n1,Elevation_n1);
title('n1');
xlabel('distance(km)');
ylabel('heights (m)');
subplot(1,2,2)
plot(Distance_a1,Elevation_a1);
title('a1');
xlabel('distance(km)');
ylabel('heights (m)');
saveas(PlotImage,'routeelevations.png');
%Calculate and display statistics
En1_mean=mean(Elevation_n1);
Ea1_mean=mean(Elevation_a1);
En1_std=std(Elevation_n1);
Ea1_std=std(Elevation_a1);
En1_min=min(Elevation_n1);
Ea1_min=min(Elevation_a1);
En1_max=max(Elevation_n1);
Ea1_max=max(Elevation_a1);
fprintf('n1 route statistics:\nMean height: %0.2f (sd: %0.2f)\nHeight range: [%0.2f, %0.2f]\n\na1 route statistics:\nMean height: %0.2f (sd: %0.2f)\nHeight range: [%0.2f, %0.2f]',En1_mean,En1_std,En1_min,En1_max,Ea1_mean,Ea1_std,Ea1_min,Ea1_max);



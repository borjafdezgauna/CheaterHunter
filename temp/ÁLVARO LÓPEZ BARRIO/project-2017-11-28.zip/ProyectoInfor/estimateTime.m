function [ estimatedTime ] = estimateTime(kms, speedKmH, numSlices)
m=toMeters(kms);
msSpeed=toMetersPerSecond(speedKmH);
a=linspace(m(1,1),m(end,1),numSlices); 
interpolatedSpeed=interpolateLinearly(m, msSpeed, a);



v=[];
option=1;    
    while option~=6
        clc
        for a=['######MENU######','1. Show route plots/statistics','2. Show driver plots/statistics',]
        disp();
        disp();
        disp();
        disp('3. Time calculations for each driver/route');
        disp('4. Check speed limits');
        disp('5. Fuel consumption calculations for each driver/route');
        disp('6. Exit');
        option=input('Choose an option: ');
        switch option
            case 1
                run('Task1.m'); 
            case 2
                run('Task2.m');
            case 3
                run('Task4.m');
            case 4 
                run('Task5.m');
            case 5
                run('Task6.m');         
        end
         if option<1 || option>6
            disp('Incorrect option: it must be between 1 and 6');
        end
        if option~=6
            disp('Press any key to continue...');
            pause
        end
    end
    

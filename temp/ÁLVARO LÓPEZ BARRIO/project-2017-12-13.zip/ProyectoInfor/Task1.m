%Task1: Write a script that analyzes the elevation profiles of both routes
    PlotImage=figure();
for road=['n' 'a']    
        filename=sprintf('%s1-height.csv',road);
        road_height=dlmread(filename,',',1,0); %Load n1-height.csv skipping first line 
        %Create each variable:
        Latitude=road_height(:,1);
        Longitude=road_height(:,2);
        Elevation=road_height(:,3);
        Distance=road_height(:,4);
        %Calculate and display statistics
        Emean=mean(Elevation);%Calculate the mean
        Estd=std(Elevation);%Calculate the standard deviation
        Emin=min(Elevation);%Calculate the minimum value
        Emax=max(Elevation);%Calculate the maximum value
        fprintf('%s1 route statistics:\nMean height: %0.2f (sd: %0.2f)\nHeight range: [%0.2f, %0.2f]\n\n',road,Emean,Estd,Emin,Emax)
        %Create the plot
        subplot(1,2,)
        plot(Distance,Elevation);
        title([road,'1']);
        xlabel('distance(km)');
        ylabel('heights (m)');
        saveas(PlotImage,'routeelevations.png');%We save the plot in a png file 
end

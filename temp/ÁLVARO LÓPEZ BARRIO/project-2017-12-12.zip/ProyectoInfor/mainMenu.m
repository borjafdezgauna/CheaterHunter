   'MENU:';
'1. Show route plots/statistics';
'2. Show driver plots/statistics';
'3. Time calculations for each driver/route';
'4. Check speed limits';
'5. Fuel consumption calculations for each driver/route';
'6. Exit';
a=input('Choose an option:');
if a<1 || a>6
   disp('Incorrect option: it must be between 1 and 6');
else
   for a=1:6
       
    


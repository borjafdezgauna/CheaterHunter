function [ m ] = toMeters( km )
    m=km*1000;%Pass from km to m
end

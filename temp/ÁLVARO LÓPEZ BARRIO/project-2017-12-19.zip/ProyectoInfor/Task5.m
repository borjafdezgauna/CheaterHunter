for road = ['n' 'a']
    for driver = 1:2 %Define driver variable
        filename=sprintf('%s1-driver%d-log.csv', road, driver);
        driver_kmh=dlmread(filename,','); %Load files
        [kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits();
        if percentAboveSpeedLimit >= 10
           infractionRisk='HIGH INFRACTION RISK'; 
        elseif percentAboveSpeedLimit<10 && >0
           infractionRisk='Mild infraction risk';
        else 
           infractionRisk='No risk of infraction';
        end

        fprintf('Analyzing: Driver= driver%d, Route= %s1
%s: Kms above the speed limit=  (5.64% of
the route)
');
    end
end
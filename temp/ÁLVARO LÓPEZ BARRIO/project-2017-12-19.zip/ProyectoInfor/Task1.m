%Task1: Write a script that analyzes the elevation profiles of both routes
PlotImage=figure(); %We create a empty image window
x=1; %We set the variable x for using the subplot
for road=['n' 'a']  
    filename=sprintf('%s1-height.csv',road);
    road_height=dlmread(filename,',',1,0); %Load n1-height.csv skipping first line 
    
    %Create each variable:
    Latitude=road_height(:,1);
    Longitude=road_height(:,2);
    Elevation=road_height(:,3);
    Distance=road_height(:,4);
   
    %Calculate and display statistics
    Emean=mean(Elevation);
    Estd=std(Elevation);
    Emin=min(Elevation);
    Emax=max(Elevation);
    fprintf('n1 route statistics:\nMean height: %0.2f (sd: %0.2f)\nHeight range: [%0.2f, %0.2f]\n\n',Emean,Estd,Emin,Emax);
    
    %We create the plot
    subplot(1,2,x);
    hold on; %We use hold on to keep the previous plot
    plot(Distance,Elevation);
    title([road, '1']); 
    xlabel('distance(km)');
    ylabel('heights (m)');

    x=x+1; %We add 1 to variable x to be a 2 in the next subplot
end
    saveas(PlotImage, 'routeelevations.png'); %We save the subplot in an image file (name: 'routeelevations.png')
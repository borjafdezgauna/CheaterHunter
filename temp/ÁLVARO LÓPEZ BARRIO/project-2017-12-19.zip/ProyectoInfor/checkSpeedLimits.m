function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
    for i=1:numSlices
      interpolatedSpeedLimit=interpolateToTheLeft(limitKms, limitSpeeds, i);
      interpolatedSpeed=interpolateLinearly(driverLogKm,driverLogSpeed,i);
      if interpolatedSpeed>interpolatedSpeedLimit
         kmsAboveSpeedLimit=
      end
    end
end
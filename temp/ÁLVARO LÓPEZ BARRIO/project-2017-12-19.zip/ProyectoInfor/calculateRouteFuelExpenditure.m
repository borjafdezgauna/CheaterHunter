function fuelExpenditure=calculateRouteFuelExpenditure(routeKms,routeHeights,logKms,logSpeeds,numSlices)
  routeMeters=toMeters(routeKms);
  routeHeightsMeters=toMeters(routeHeights);
  logMeters=toMeters(logKms);
  logSpeeds=toMetersPerSecond(logSpeeds);
  for
    theta=arctan
end

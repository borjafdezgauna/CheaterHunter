hold off;%we erase the previous plot
v=[];
u=[];
    for driver_n1 = 1:2 %Define driver variable
        filename1=sprintf('n1-driver%d-log.csv', driver_n1);
        driver_kmh1=dlmread(filename1,','); %Load files
        Distance1=driver_kmh1(:,1);%Define Distance 1 as a 1 column matrix
        Speed1=driver_kmh1(:,2);%Define Speed 1 as a 1 column matrix
        v=[v Distance1];
        u=[u Speed1];
        n1_mean=mean(Speed1);%Calculate the mean
        n1_std=std(Speed1);%Calculate the standar derivation 
        n1_min=min(Speed1);%Calulate the min value
        n1_max=max(Speed1);%Calulate the max value
        fprintf('driver statistics in route n1\nMean speed: %0.2f (sd. %0.2f)\nMin-Max speed: [%0.2f,%0.2f]\n\n',n1_mean,n1_std,n1_min,n1_max);
    end
w=[];
x=[];
    for driver_a1 = 1:2 %Define driver variable
        filename2=sprintf('a1-driver%d-log.csv', driver_a1);
        driver_kmh2=dlmread(filename2,','); %Load files
        Distance2=driver_kmh2(:,1);
        Speed2=driver_kmh2(:,2);
        w=[w Distance2];
        x=[x Speed2];
        a1_mean=mean(Speed2);
        a1_std=std(Speed2);
        a1_min=min(Speed2);
        a1_max=max(Speed2);
        fprintf('driver statistics in route a1\nMean speed: %0.2f (sd. %0.2f)\nMin-Max speed: [%0.2f,%0.2f]\n\n',a1_mean,a1_std,a1_min,a1_max);
    end
subplot(1,2,1);
plot(v,u);
title('Drivers in n1');
xlabel('distance(km)');
ylabel('speed(km/h)');
legend('Driver 1','Driver 2');
subplot(1,2,2);
plot(w,x);
title('Drivers in a1');
xlabel('distance(km)');
ylabel('speed(km/h)');
legend('Driver 1','Driver 2');

for road = ['n' 'a']
    for driver = 1:2 %Define driver variable
        filename=sprintf('%s1-driver%d-log.csv', road, driver);
        driver_kmh=dlmread(filename,','); %Load files
        estimateTime=estimateTime(driver_kmh(:,1),driver_kmh(:,2));
        time=toHMS(estimateTime);%Time: hours:minutes:seconds
        frintf('Estimated time for driver%d in route %s1: %s', driver, road, time);
    end
end
      
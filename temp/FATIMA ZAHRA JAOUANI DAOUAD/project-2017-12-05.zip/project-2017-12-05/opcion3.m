clear
clc

%leemos los archivos
autopista=csvread('a1-height.csv', 1)
nacional=csvread('n1-height.csv', 1)
conductora1=csvread('a1-driver1-log.csv')
conductora2=csvread('a1-driver2-log.csv')
conductorn1=csvread('n1-driver1-log.csv')
conductorn2=csvread('n1-driver2-log.csv')
clear
clc

function [ m ] = toMeters( km )
m=km*1000;
disp(m)
end
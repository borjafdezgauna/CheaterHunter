for route={'n1','a1'};
  for number=1:2;
    filename=sprintf('%s-driver%d-log.csv',route{1},number); 
    i=dlmread(filename,',',1,0);
     estimatedTime  = estimateTime( i(:,1), i(:,2), 10000);
 hms=toHMS(estimatedTime);
 fprintf('Estimated time for driver%d in route %s: %s\n',number,route{1},hms);
  end
end
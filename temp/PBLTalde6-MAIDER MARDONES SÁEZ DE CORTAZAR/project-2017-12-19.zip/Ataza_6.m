for number=1:2;
  for route={'n1','a1'};
    fileheight=sprintf('%s-height.csv',route{1});
    altuera=dlmread(fileheight,',');
    filespeed=sprintf('%s-driver%d-log.csv',route{1},number);
    abiadura=dlmread(filespeed,',');
[fuelExpenditure]=calculateRouteFuelExpenditure (altuera(:,1),altuera(:,3),abiadura(:,1),abiadura(:,2),1000);
fprintf('Analyzing: Driver= driver%d, Route=%s\nEstimated fuel cunsumption: %f liters of fuel\n\n',number,route{1},fuelExpenditure);
end
end

function [interpolatedY]=interpolateLinearly(xVector,yVector,x)
i=1;
while i<length(xVector) && xVector(i)<x
 i=i+1;
 end
 if i==1
  i=i+1;
  end
 x0=xVector(i-1);
 x1=xVector(i);
 y0=yVector(i-1);
 y1=yVector(i);
interpolatedY=y0+((y1-y0)/(x1-x0))*(x-x0);
end
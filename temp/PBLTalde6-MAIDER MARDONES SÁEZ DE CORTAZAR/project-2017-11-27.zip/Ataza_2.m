 for driver=1:2
 k=1;
  for route={'n1','a1'}
filename=sprintf('%s-driver%d-log.csv',route{1},driver);  
i=dlmread(filename,',',1,0);
subplot(1,2,k);
hold on
plot(i(:,1),i(:,2));
xlabel('Distantzia(km)');
ylabel('Abiadura(km/h)');
legend('n1','a1');
 title('Abiadura jatorrarekiko');
k=k+1;
maxspeed=max(i(:,2)); 
minspeed=min(i(:,2));
meanspeed=mean(i(:,2));
standardspeed=std(i(:,2));
fprintf('driver%d statistics in route %s:\nMean speed: %.2f km/h (sd. %.2f)\nMin-Max Speed: [%.2f %.2f]\n\n',driver,route{1},meanspeed,standardspeed,maxspeed,minspeed);
  end
end
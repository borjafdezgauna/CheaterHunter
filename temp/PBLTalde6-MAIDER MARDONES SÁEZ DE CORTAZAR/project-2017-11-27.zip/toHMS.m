function [ hms ] = toHMS( seconds )
HH=fix(seconds/3600);
MM=fix(((seconds/3600)-HH)/60);
SS=fix((seconds/60)-MM);
fprintf('%d%d%d',HH,MM,SS);
end
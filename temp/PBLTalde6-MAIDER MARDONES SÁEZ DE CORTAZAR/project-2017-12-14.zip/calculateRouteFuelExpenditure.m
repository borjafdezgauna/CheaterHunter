function[fuelExpenditure]?=calculateRouteFuelExpenditure (routeKms, routeHeights,logKms,logSpeed,numSlices)
fuelExpenditure=0;
route=linspace(routeKms(0),routeKms(length(Kms)),numSlices);
v=linspace(logKms(0),logKms(length(Kms)),numSlices);
h=zeros(1,numSlices);
speed=zeros(1,numSlices);
for i=1:length(u)
  interpolatedY=interpolateLinearly(routeKms,routeHeights,route(i));
  h(i)=interpolatedY
  end
  for i=1:length(v)
  interpolatedY=interpolateLinearly(routeKms,routeHeights,v(i));
  speed(i)=interpolatedY
  end
  for j=1:numSlices
 
 
 [fuelExpenditure]=calculateFuelExpenditure(v,a,theta,numSlices)

 for driver=1:2
 k=1;
  for route={'n1','a1'}
filename=sprintf('%s-driver%d-log.csv',route{1},driver);  
i=dlmread(filename,',');
subplot(1,2,k);
hold on
plot(i(:,1),i(:,2));
xlabel('Distantzia(km)');
ylabel('Abiadura(km/h)');
title('Abiadura jatorrarekiko');
k=k+1;
maxspeed=max(i(:,2)); 
minspeed=min(i(:,2));
meanspeed=mean(i(:,2));
standardspeed=std(i(:,2));
fprintf('driver%d statistics in route %s:\nMean speed: %.2f km/h (sd. %.2f)\nMin-Max Speed: [%.2f %.2f]\n\n',driver,route{1},meanspeed,standardspeed,minspeed,maxspeed);
  end
end
subplot(1,2,1);
legend('n1','a1');
subplot(1,2,2);
legend('n1','a1');
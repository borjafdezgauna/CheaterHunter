function[ kmsAboveSpeedLimit,percentAboveSpeedLimit]= checkSpeedLimits(driverLogKm, driverLogSpeed, LimitKms,LimitSpeeds, numSlices)
dx=(driverLogKm(length(driverLogKm))-driverLogKm(1))/numSlices;
kmsAboveSpeedLimit=0;
  u=linspace(driverLogKm(1),driverLogKm(length(driverLogKm)), numSlices);
for i=1:length(u);
    interpolatedY = interpolateToTheLeft(LimitKms, LimitSpeeds, u(i));
     lininterpolatedY=interpolateLinearly(driverLogKm,driverLogSpeed,u(i));
  if lininterpolatedY>interpolatedY;
    kmsAboveSpeedLimit=dx+kmsAboveSpeedLimit;
  end
  end
  percentAboveSpeedLimit=(kmsAboveSpeedLimit/(driverLogKm(length(driverLogKm))-driverLogKm(1)))*100;
  end
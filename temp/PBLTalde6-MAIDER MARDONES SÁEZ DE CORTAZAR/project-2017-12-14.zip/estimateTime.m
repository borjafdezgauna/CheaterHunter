function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices);
   dx=kms(length(kms))/numSlices;
  u=linspace(kms(1),kms(length(kms)), numSlices);
  estimatedTime=0;
for i=1:(length(u));
interpolatedspeedKmH=interpolateLinearly(kms,speedKmH,u(i));
estimatedTime=(dx/interpolatedspeedKmH)+estimatedTime;
  end
  estimatedTime=estimatedTime*3600;
  end
seconds=input('Introduzca una cantidad de segundos: ');
toHMS( seconds )
%Llamada de a la funcion toHMS.
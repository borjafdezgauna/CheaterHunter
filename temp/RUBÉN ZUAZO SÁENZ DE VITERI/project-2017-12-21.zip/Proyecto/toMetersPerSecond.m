function [ msSpeed ] = toMetersPerSecond( speedKmH )
 msSpeed=speedKmH/3.6;
end
%Funcion para hacer el cambio de unidades de km/h a m/s.
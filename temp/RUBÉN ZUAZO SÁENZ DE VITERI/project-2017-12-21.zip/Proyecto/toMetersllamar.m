km=input('Introduzca una posicion en km: ');
m =toMeters(km);
%Llamada a la funcion de cambio de unidades de km a m.
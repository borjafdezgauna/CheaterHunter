speedKmH =input('Introduzca una velocidad en km/h: ');
msSpeed =toMetersPerSecond( speedKmH );
%Llamada a la funcion de cambio de unidades de km/h a m/s


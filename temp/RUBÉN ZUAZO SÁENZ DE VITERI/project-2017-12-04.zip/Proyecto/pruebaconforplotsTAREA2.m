clc
clear all
ruta={'n1','a1'};
conductor={'driver1','driver2'};
for i= 1:length(ruta)
    subplot(2,1,1)
    for j=1:length(conductor)
        file=sprintf('%s-%s-log.csv',ruta{i},conductor{j});
        datos=dlmread(file,',',1,0);
        hold on
       
        plot(datos(:,1),datos(:,2))
        xlabel('distancia(km)')
        ylabel('velocidad(km/h)')
        title('C');
        
%         subplot(2,1,2)
        
        
    end
    
end
%     subplot(2,2,1)')
%     
%  plot(velocidadConductor1RutaA1(:,1),velocidadConductor1RutaA1(:,2))
%  xlabel('distancia(km)')
%  ylabel('velocidad(km/h)')
%  title('Autopista Conductor 1')
% 
%  subplot(2,2,2)
%  plot(velocidadConductor2RutaA1(:,1),velocidadConductor2RutaA1(:,2))
%  xlabel('distancia(km)')
%  ylabel('velocidad(km/h)')
%  title('Autopista Conductor 2')
% 
%  subplot(2,2,3)
%  plot(velocidadConductor1RutaN1(:,1),velocidadConductor1RutaN1(:,2))
%  xlabel('distancia(km)')
%  ylabel('velocidad(km/h)')
%  title('Nacional Conductor 1')
% 
%  subplot(2,2,4)
%  plot(velocidadConductor2RutaN1(:,1),velocidadConductor2RutaN1(:,2))
%  xlabel('distancia(km)')
%  ylabel('velocidad(km/h)')
%  title('Nacional Conductor 2') las rutas')
x=input('Introduce un numero:')
if x==1
    disp('a')
elseif x==2
    disp('b')
elseif x==3
    disp('c')
elseif x==4
    disp('Odo')
elseif x==5
    disp('e')
elseif x==6
    disp('f')
else ~x(0:6)
    disp('NOOOO')
end
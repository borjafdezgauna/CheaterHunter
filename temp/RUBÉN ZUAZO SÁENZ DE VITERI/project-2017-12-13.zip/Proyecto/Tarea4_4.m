velocidadConductor1RutaA1=dlmread('a1-driver1-log.csv');
velocidadConductor2RutaA1=dlmread('a1-driver2-log.csv');
velocidadConductor1RutaN1=dlmread('n1-driver1-log.csv');
velocidadConductor2RutaN1=dlmread('n1-driver2-log.csv');
function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)

numSlices=linspace(0,185,10000)

for i=1:length(kms)
    estimatedTime= numSlices/msSpeed
    
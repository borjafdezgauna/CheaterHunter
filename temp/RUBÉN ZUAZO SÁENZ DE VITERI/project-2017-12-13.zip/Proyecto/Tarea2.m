%tarea 2 sin el for
%cargar los datos de los dos conductores en ambas rutas
 velocidadConductor1RutaA1=dlmread('a1-driver1-log.csv');
 velocidadConductor2RutaA1=dlmread('a1-driver2-log.csv');
 velocidadConductor1RutaN1=dlmread('n1-driver1-log.csv');
 velocidadConductor2RutaN1=dlmread('n1-driver2-log.csv');

 
 
 subplot(2,2,1)
 plot(velocidadConductor1RutaA1(:,1),velocidadConductor1RutaA1(:,2))
 xlabel('distancia(km)')
 ylabel('velocidad(km/h)')
 title('Autopista Conductor 1')

 subplot(2,2,2)
 plot(velocidadConductor2RutaA1(:,1),velocidadConductor2RutaA1(:,2))
 xlabel('distancia(km)')
 ylabel('velocidad(km/h)')
 title('Autopista Conductor 2')

 subplot(2,2,3)
 plot(velocidadConductor1RutaN1(:,1),velocidadConductor1RutaN1(:,2))
 xlabel('distancia(km)')
 ylabel('velocidad(km/h)')
 title('Nacional Conductor 1')

 subplot(2,2,4)
 plot(velocidadConductor2RutaN1(:,1),velocidadConductor2RutaN1(:,2))
 xlabel('distancia(km)')
 ylabel('velocidad(km/h)')
 title('Nacional Conductor 2')
 
  %como hacer Velocidad media y su rango
  %Velocida media y su rango para el Conductor1 en la nacional1 (N1)
fprintf('Estadistica del conductor 1 ruta n1:\n')
mediaVelocidadConductor1RutaN1=mean(velocidadConductor1RutaN1(:,2));
desviacionEstandarConductor1RutaN1=std(velocidadConductor1RutaN1(:,2));
fprintf('Velocidad media: %.2f (sd:%.2f)\n',mediaVelocidadConductor1RutaN1,desviacionEstandarConductor1RutaN1)
minimoDeVelocidadConductor1RutaN1=min(velocidadConductor1RutaN1(:,2));
maximoDeVelocidadConductor1RutaN1=max(velocidadConductor1RutaN1(:,2));
fprintf('Rango de velocidades: [%.2f ,%.2f]\n\n',minimoDeVelocidadConductor1RutaN1,maximoDeVelocidadConductor1RutaN1)

  %Velocida media y su rango para el Conductor2 en la nacional1 (N1)
fprintf('Estadistica del conductor 2 ruta n1:\n')
mediaVelocidadConductor2RutaN1=mean(velocidadConductor2RutaN1(:,2));
desviacionEstandarConductor2RutaN1=std(velocidadConductor2RutaN1(:,2));
fprintf('Velocidad media: %.2f (sd:%.2f)\n',mediaVelocidadConductor2RutaN1,desviacionEstandarConductor2RutaN1)
minimoDeVelocidadConductor2RutaN1=min(velocidadConductor2RutaN1(:,2));
maximoDeVelocidadConductor2RutaN1=max(velocidadConductor2RutaN1(:,2));
fprintf('Rango de velocidades: [%.2f ,%.2f]\n\n',minimoDeVelocidadConductor2RutaN1,maximoDeVelocidadConductor2RutaN1)

  %Velocida media y su rango para el Conductor1 en la autopistaA1 (A1)
fprintf('Estadistica del conductor 1 ruta a1:\n')
mediaVelocidadConductor1RutaA1=mean(velocidadConductor1RutaA1(:,2));
desviacionEstandarConductor1RutaA1=std(velocidadConductor1RutaA1(:,2));
fprintf('Velocidad media: %.2f (sd:%.2f)\n',mediaVelocidadConductor1RutaA1,desviacionEstandarConductor1RutaA1)
minimoDeVelocidadConductor1RutaA1=min(velocidadConductor1RutaA1(:,2));
maximoDeVelocidadConductor1RutaA1=max(velocidadConductor1RutaA1(:,2));
fprintf('Rango de velocidades: [%.2f ,%.2f]\n\n',minimoDeVelocidadConductor1RutaA1,maximoDeVelocidadConductor1RutaA1)

  %Velocida media y su rango para el Conductor2 en la autopistaA1 (A1)
fprintf('Estadistica del conductor 1 ruta n1:\n')
mediaVelocidadConductor2RutaA1=mean(velocidadConductor2RutaA1(:,2));
desviacionEstandarConductor2RutaA1=std(velocidadConductor2RutaA1(:,2));
fprintf('Velocidad media: %.2f (sd:%.2f)\n',mediaVelocidadConductor2RutaA1,desviacionEstandarConductor2RutaA1)
minimoDeVelocidadConductor2RutaA1=min(velocidadConductor2RutaA1(:,2));
maximoDeVelocidadConductor2RutaA1=max(velocidadConductor2RutaA1(:,2));
fprintf('Rango de velocidades: [%.2f ,%.2f]\n\n',minimoDeVelocidadConductor2RutaA1,maximoDeVelocidadConductor2RutaA1)
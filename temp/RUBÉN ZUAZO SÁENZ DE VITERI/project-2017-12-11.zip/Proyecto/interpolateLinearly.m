function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)

y=y1+y2?y1x2?x1(x?x1)y=y1+y2?y1x2?x1(x?x1)


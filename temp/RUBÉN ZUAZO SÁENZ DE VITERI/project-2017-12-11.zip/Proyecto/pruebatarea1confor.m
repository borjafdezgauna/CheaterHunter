%tarea1 parte dos con el for
ruta={'n1','a1'};
for i= 1:length(ruta)
            file=sprintf('%s-height.csv',ruta{i});
            datos=dlmread(file,',',1,0);
            fprintf('Estadistica de la ruta %s:\n',ruta{i})
            media=mean(datos(:,3));
            desviacionEstandar=std(datos(:,3));
            fprintf('Altura media: %.2f (sd:%.2f)\n',media,desviacionEstandar)
            minimoDeAltura=min(datos(:,3));
            maximoDeAltura=max(datos(:,3)); 
            fprintf('Rango de alturas: [%.2f ,%.2f]\n\n',minimoDeAltura,maximoDeAltura)
end






       
 
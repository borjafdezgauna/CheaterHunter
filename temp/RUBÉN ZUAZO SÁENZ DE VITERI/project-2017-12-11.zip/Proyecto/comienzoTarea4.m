clear all
clc
x=input('Introduzca una distancia')
if 0<x<1000
    segundos=x/10
elseif 1000<x<=2000
    segundos=x/20
else
    disp('Introduzca una distancia entre 0 y 2000 metros')
end
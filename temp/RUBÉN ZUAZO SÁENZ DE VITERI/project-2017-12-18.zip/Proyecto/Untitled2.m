function [ interpolatedY ] = interpolateLinearly(km, speedKmH , x)
% x= kilometros interpolados
    i=1
    while i<length(km)  && x>km(i)

        i=i+1

    end
    if i==1
        interpolatedY= speedKmH(i)
    else
        interpolatedY= speedKmH(i-1)+(speedKmH(i)-speedKmH(i-1))/(km(i)-km(i-1))*(km-km(i-1))
    end
    i=d
        while d<=length(km)&& d>=km(1)
            if d==0
                x=0
            else
                xF=d+x(2)
            end
            d=d+xF
            estimateTime=xF/interpolatedY  
        end
    
end


 

ruta={'n1','a1'};
conductor={'driver1','driver2'};

for i= 1:length(ruta)
  for j=1:length(conductor)
            file=sprintf('%s-%s-log.csv',ruta{i},conductor{j});
            datos=dlmread(file);
  end
end
km=datos(:,1);  
numSlices=10000
x=linspace(0,length(km),numSlices)

% function [ interpolatedY ] = interpolateLinearly(km, speedKmH , x)
% % x= kilometros interpolados
%     i=1
%     while i<length(km)  && x>km(i)
% 
%         i=i+1
% 
%     end
%     if i==1
%         interpolatedY= speedKmH(i)
%     else
%         interpolatedY= speedKmH(i-1)+(speedKmH(i)-speedKmH(i-1))/(km(i)-km(i-1))*(km-km(i-1))
%     end
% 
%  end

% i=d
%     while d<=length(km)&& d>=km(1)
%         if d==0
%             x=0
%         else
%             xF=d+x(2)
%         end
%         d=d+xF
%         estimateTime=xF/interpolatedY  
%     end
%    
%     
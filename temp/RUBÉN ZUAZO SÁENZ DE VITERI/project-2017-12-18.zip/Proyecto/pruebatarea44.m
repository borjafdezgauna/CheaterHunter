clc

clear all

ruta={'n1','a1'};
conductor={'driver1','driver2'};

% numSlices=linspace(0,185,10000);

for i= 1:length(ruta)
    for j=1:length(conductor)
            file=sprintf('%s-%s-log.csv',ruta{i},conductor{j});
            datos=dlmread(file);
    end
end


% velocidad de km/h a m/s:
speedKmH =datos(:,2);


% distancia de km a m
km=datos(:,1);


function [ interpolatedY ] = interpolateLinearly(km, speedKmH , x)
% x= kilometros interpolados
    i=1
    while i<length(km)  && x>km(i)

        i=i+1

    end
    if i==1
        interpolatedY= speedKmH(i)
    else
        interpolatedY= speedKmH(i-1)+(speedKmH(i)-speedKmH(i-1))/(km(i)-km(i-1))*(km-km(i-1))
    end

 end

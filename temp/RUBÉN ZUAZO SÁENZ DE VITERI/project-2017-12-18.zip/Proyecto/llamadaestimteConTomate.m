ruta={'n1','a1'};
conductor={'driver1','driver2'};

for j= 1:length(ruta);
    for k=1:length(conductor);
            file=sprintf('%s-%s-log.csv',ruta{j},conductor{k});
            datos=dlmread(file);
            % 
 % velocidad en km/h
speedKmH= datos(:,2);

% %distancia en kms de unidad
km= datos(:,1);
    end
end

estimateTimeConTomate([0 1 2 3],[40 50 40 30],1000)
% estimateTimeConTomate([0 1 2 3],[40 50 40 20],1000) 
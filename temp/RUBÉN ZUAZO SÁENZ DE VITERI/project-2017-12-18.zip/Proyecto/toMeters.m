function [ m ] = toMeters(km)
m=sprintf('toMeters(%.1f)=>%2d',km,km*1000)
end
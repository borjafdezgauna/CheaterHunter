function [ estimatedTime ] = estimateTimeConTomate( km, speedKmH, numSlices)

x=linspace(km(1),km(end),numSlices);
distanciaEntreSlices= km(end)/numSlices;

for l=2:length(x);
  
    interpolatedY=interpolateLinearly( km, speedKmH , x(l));
    y(l) = interpolatedY;
    estimatedTime=x(l)/y(l)
    for m=1:length(estimatedTime)
    end
%         
end

%%%%% velocidad de km/h a m/s:
    msSpeed =toMetersPerSecond(y(l) );
 %%%%% distancia de km a m
    m =toMeters(km);

end
    








function [ estimatedTime ] = estimateTime( km, speedKmH, numSlices)


estimateTime=x/interpolatedY

end

clc
ruta={'n1','a1'};
conductor={'driver1','driver2'};

 for j= 1:length(ruta)
  for k=1:length(conductor)
    file=sprintf('%s-%s-log.csv',ruta{j},conductor{k});
    datos=dlmread(file);
    km= datos(:,1);
    m =toMeters(km);
    speedKmH= datos(:,2);
    msSpeed =toMetersPerSecond(speedKmH);
    seconds=estimateTime(m,msSpeed,10000);
    hms=toHMS(seconds);  
    fprintf('Estimated time for %s in route %s: %s\n',conductor{k},ruta{j},hms);
  
  end
end



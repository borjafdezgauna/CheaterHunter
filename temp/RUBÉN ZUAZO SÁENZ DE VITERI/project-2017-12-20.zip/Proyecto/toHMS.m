function [ hms ] = toHMS( seconds )
horas=fix(seconds/3600);
minutos=fix(rem(seconds,3600)/60);
segundos=fix(rem(rem(seconds,3600),60));
sprintf('%02d:%02d:%02d',horas,minutos,segundos)
end
     
  


clc
ruta={'n1','a1'};
conductor={'driver1','driver2'};

 for j= 1:length(ruta)
  for k=1:length(conductor)
    file=sprintf('%s-%s-log.csv',ruta{j},conductor{k});
    datos=dlmread(file);
    driverLogKm= datos(:,1);
    driverLogSpeed= datos(:,2);   
    archivo= sprintf('%s-speed-limit.csv',ruta{j});
    limites=dlmread(archivo);
    limitKms=limites(:,1);
    limitSpeeds=limites(:,2);
    
    
    checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)
  end
  
 end
 




function [ kmsAboveSpeedLimit,percentAboveSpeedLimit ] = checkSpeedLimits( driverLogKm, driverLogSpeed, limitKms, limitSpeeds, numSlices)

 estimateTime( km, speedKmH, numSlices)
 interpolateToTheLeft( xVector, yVector , x)
 if 
 kmsAboveSpeedLimit
 percentAboveSpeedLimit=(kmsAboveSpeedLimit/driverLogKm(end))*100

end

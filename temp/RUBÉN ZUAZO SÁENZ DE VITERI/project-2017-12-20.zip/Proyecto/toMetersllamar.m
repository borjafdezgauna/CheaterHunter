km=input('Introduzca una posicion en km: ');
m =toMeters(km);

function [ estimatedTime ] = estimateTime( km, speedKmH, numSlices)

x=linspace(km(1),km(end),numSlices);
slice = (km(end)-km(1))/numSlices;
estimatedTime=0;
for i=2:length(x)

    interpolatedY=interpolateLinearly( km, speedKmH , x(i));
    velocidad=interpolatedY;
    estimatedTime=estimatedTime+slice/velocidad;

end


end
    







%Tarea completa poner tarea 1 y 2 las completas
clc 
clear all
x=input('####### MENU ########:\n 1. Muestra las gr�ficas y estad�sticas de las rutas\n 2. Muestra las gr�ficas y estad�sticas de los conductores\n 3. C�lculos de tiempo para cada conductor y ruta\n 4. Comprobar los l�mites de velocidad\n 5. C�lculo de consumo de combustible para cada conductor y ruta\n 6. Salir\n Elige una opcion:')

while x~=6 
  
    if x==1
        Tarea1
        
    elseif x==2
        Tarea2
        
    elseif x==3
        %Tarea4(aun por acabar)  
        
    elseif x==4   
         %Tarea5(aun por acabar)  
       
    elseif x==5   
         %Tarea6(aun por acabar)
        
   
    else        
        disp('Opci�n incorrecta: debe ser un n�mero entre 1 y 6')
        
    end
    x=input('####### MENU ########:\n 1. Muestra las gr�ficas y estad�sticas de las rutas\n 2. Muestra las gr�ficas y estad�sticas de los conductores\n 3. C�lculos de tiempo para cada conductor y ruta\n 4. Comprobar los l�mites de velocidad\n 5. C�lculo de consumo de combustible para cada conductor y ruta\n 6. Salir\n Elige una opcion: ')
    clc
    
end

% COMIENZO TAREA 5
clc
ruta={'n1','a1'};
conductor={'driver1','driver2'};
for j= 1:length(ruta)
  for k=1:length(conductor)
    file=sprintf('%s-%s-log.csv',ruta{j},conductor{k});
    datos=dlmread(file);
    km= datos(:,1);
    m =toMeters(km);
    speedKmH= datos(:,2);
  end
end

   for i= 1:length(ruta) 
    file2=sprintf('%s-speed_limit.csv',ruta{i})
    datosLimites=dlmread(file2)
  end
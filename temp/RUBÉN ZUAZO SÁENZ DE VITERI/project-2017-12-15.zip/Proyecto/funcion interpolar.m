xVector=[10 20 40]
yVector=[120 150 130]
function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
i=1
while x>=xVector(i)  && x<xVector(i+1)
    interpolatedY= y1+(((y2-y1)/(xVector(i+1)-xVector(i)))*(x-xVector(i)))
    i=i+1
end

end

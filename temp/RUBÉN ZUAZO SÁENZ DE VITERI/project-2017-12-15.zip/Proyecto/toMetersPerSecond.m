function [ msSpeed ] = toMetersPerSecond( speedKmH )
 msSpeed=sprintf('toMetersPerSecond(%.f)=>%.4f',speedKmH,speedKmH/3.6)
end
ruta={'n1','a1'};
conductor={'driver1','driver2'};

for j= 1:length(ruta)
    for k=1:length(conductor)
            file=sprintf('%s-%s-log.csv',ruta{j},conductor{k});
            datos=dlmread(file);
            
    end
end

function [ estimatedTime ] = estimateTimeConTomate( km, speedKmH, numSlices)

% velocidad en km/h
speedKmH= datos(:,2);

%distancia en kms de unidad
km= datos(:,1);

% velocidad de km/h a m/s:
msSpeed =toMetersPerSecond( speedKmH );

% distancia de km a m
m =toMeters(km);

x=linspace(0,length(m),numSlices);

interpolateLinearly( m, msSpeed , x)
%  function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
%     i=1
%     while i<length(xVector)  && x>xVector(i)
% 
%         i=i+1
% 
%     end
%     if i==1
%         interpolatedY= yVector(i)
%     else
%         interpolatedY= yVector(i-1)+(yVector(i)-yVector(i-1))/(xVector(i)-xVector(i-1))*(x-xVector(i-1))
%     end
estimatedTime=x/interpolatedY
 end





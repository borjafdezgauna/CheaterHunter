clc
clear all
ruta={'n1','a1'};
conductor={'driver1','driver2'};

for i= 1:length(ruta)
    for j=1:length(conductor)
            file=sprintf('%s-%s-log.csv',ruta{i},conductor{j});
            datos=dlmread(file);
            fprintf('Estadistica del conductor %s ruta %s:\n',ruta{i},conductor{j})
            mediaVelocidad=mean(datos(:,2));
            desviacionEstandar=std(datos(:,2));
            fprintf('Velocidad media: %.2f (sd:%.2f)\n',mediaVelocidad,desviacionEstandar)
            minimoDeVelocidad=min(datos(:,2));
            maximoDeVelocidad=max(datos(:,2));
            fprintf('Rango de velocidades: [%.2f ,%.2f]\n\n',minimoDeVelocidad,maximoDeVelocidad)
    end
end
    


           
            










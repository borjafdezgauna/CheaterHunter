speedKmH =input('Introduzca una velocidad en km/h: ');
msSpeed =toMetersPerSecond( speedKmH );

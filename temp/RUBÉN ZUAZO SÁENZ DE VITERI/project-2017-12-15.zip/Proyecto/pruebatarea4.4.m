clc
clear all

ruta={'n1','a1'};
conductor={'driver1','driver2'};

numSlices=linspace(0,185,10000);

for i= 1:length(ruta)
    for j=1:length(conductor)
            file=sprintf('%s-%s-log.csv',ruta{i},conductor{j});
            datos=dlmread(file);
            speedKmH= datos(:,2);
            % velocidad en km/h
            kms= datos(:,1);
            %distancia en kms de unidad
    end
end


% velocidad de km/h a m/s:
speedKmH =input('Introduzca una velocidad en km/h: ');
msSpeed =toMetersPerSecond( speedKmH );

% distancia de km a m
km=input('Introduzca una posicion en km: ');
m =toMeters(km);

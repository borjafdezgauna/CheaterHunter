function [m] = toMeters(km)
  toMeters = km*1000
  end
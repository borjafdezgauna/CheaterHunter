function [estimatedTime] = estimateTime(kms, speedKmH, numSlices)
 kms = dlmread
 speedKmH = dlmread
z = lerp([kms],[speedKmH],185)
 
 
  end
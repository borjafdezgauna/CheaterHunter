function [interpolatedY] = lerp( xValues, yValues , x)
   
   
   
   
   
 i = 1;
while xValues(i)<x
  i=i+1;
  end
  
  if i == 1;
    i = 2;
    end
  x1 = xValues(i);
  y1 = yValues(i);
  x0 = xValues(i-1);
  y0 = yValues(i-1);
  y = y0+((y1-y0)/(x1-x0))*(x-x0)
  end
  






%%This function gets a vector with x-values and a vector with y-values
%%and returns the interpolated value of y for the given x.
n1= dlmread('n1-height.csv',',',1,0)
plot(n1(:,3),n1(:,4))
title('nazionala')
xlabel('distatzia(km)')
ylabel('altuera(m)')


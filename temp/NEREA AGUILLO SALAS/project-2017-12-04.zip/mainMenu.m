clc
num=input('introduce un numero');
if num <1 && num >6
    disp('el numero introducido tiene que estar entre 1 y 6, porfavor intentelo mas tarde. Gracias');
else 
    if num == 1
        load{'Tarea1.m'};
    elseif num==2
        load{'Tarea2.m'};
   
    elseif num==3
        disp{'tarea2.m'}
    elseif num==4
        disp{'tarea2.m'}
    elseif num==5
        disp{'tarea2.m'}
    elseif num==6

    end
end
        

a=dlmread('Tarea1.2m')
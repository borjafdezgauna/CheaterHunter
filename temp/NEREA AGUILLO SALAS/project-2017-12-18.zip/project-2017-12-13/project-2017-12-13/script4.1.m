if x>=min(xVector) && x<=max(xVector)

    else
    disp(' La posici�n debe estar entre las posiciones del vector')

end
  mi_y=interpolateLinearly( xVector, yVector, x);
         tiempo=(x2-x1)/mi_y;
         estimatedTime=estimatedTime + tiempo;
 for i=1:length(xVector)-1
       %para cada x en mis_x necesito mi_y
         x1=xVector(i);
         x2=xVector(i+1);
         x=(x2-x1);                
         mi_y=interpolateLinearly( xVector, yVector, x);
         tiempo=(x2-x1)/mi_y;
         estimatedTime=estimatedTime + tiempo;
     
    end
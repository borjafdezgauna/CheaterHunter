 num=input('introduce un numero ');
   while num> 1 && num <6
   if num<1 || num>6
       disp('el numero introducido tiene que estar entre 1 y 6, porfavor intentelo mas tarde. Gracias');
        elseif num == 1
        run('Tarea1.m');
        elseif num==2
        run('Tarea1.m');
        elseif num==3
        run('Tarea4.m');
        elseif num==4
        run('Tarea5.m');
        elseif num==5
        run('Tarea6.m');
        elseif num==6
          
    end
        
end
    
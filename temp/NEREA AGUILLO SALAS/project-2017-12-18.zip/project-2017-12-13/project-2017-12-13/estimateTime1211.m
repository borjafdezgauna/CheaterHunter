function [ estimatedTime ] = estimateTime1211( kms, speedKmH, numSlices)
encontrado=false;
i=1;
x=(length(kms)/numSlices;
m=toMeters( kms );
speedMs=toMetersPerSecond( speedKmH );
if x<min(m) || x>max(speedMs)
  disp(' La posici�n debe estar entre las posiciones del vector')
else
  while i<=(length(m)-1) && encontrado==false
     if m(i)==x
        interpolatedY=speedMs(i);
     elseif x>m(i) && x<m(i+1)
        encontrado=true;
        x1=m(i);
        y1=speedMs(i);
        x2=m(i+1);
        y2=speedMs(i+1);
        interpolatedY=y1+(((x-x1)*(y2-y1))/(x2-x1));
        estimatedTime=x/interpolatedY;
     end
    i=i+1;
  end

end
end
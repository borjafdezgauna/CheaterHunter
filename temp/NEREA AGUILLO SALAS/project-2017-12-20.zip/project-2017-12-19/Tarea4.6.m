velocidadAutopista=dlmread('a1-driver1-log.csv', ',', 1,0);
velocidadAutopista2=dlmread('a1-driver2-log.csv', ',', 1,0);
velocidadNacional=dlmread('n1-driver1-log.csv', ',', 1,0);
velocidadNacional2=dlmread('n1-driver2-log.csv', ',', 1,0);

distanciaA=velocidadAutopista(:,1);
distanciaA2=velocidadAutopista2(:,1);

velocidadA=velocidadAutopista(:,2);
velocidadA2=velocidadAutopista2(:,2);

distanciaN=velocidadNacional(:,1);
distanciaN2=velocidadNacional2(:,1);

velocidadN=velocidadNacional(:,2);
velocidadN2=velocidadNacional2(:,2);

numSlices=1000;
secondsa11=estimateTime(distanciaA, velocidadA,numSlices);
tiempoa11=toHMS(secondsa11);
secondsa12=estimateTime(distanciaA2, velocidadA2,numSlices);
tiempoa12=toHMS(secondsa12);
secondsn11=estimateTime(distanciaN, velocidadN,numSlices);
tiempon11=toHMS(secondsn11);
secondsn12=estimateTime(distanciaN2, velocidadN2,numSlices);
tiempon12=toHMS(secondsn12);
%sprintf( Estimated time for driver 1 in route a1: , toHMS(secondsa11), '%s\n')
a=sprintf('Estimated time for driver 1 in route a1: %s%6.0d', toHMS(secondsa11))
sprintf('Estimated time for driver 1 in route a1:tiempoa11','%s%6.0d')
 toHMS(secondsa11)
 sprintf('Estimated time for driver 1 in route a1',':',toHMS(secondsa11))
% a=sprintf('Estimated time for driver 1 in route a1: %s%2d:%2d:%2d', toHMS(secondsa11))
sprintf('Estimated time for driver 1 in route a1: ') && fprintf('toHMS(secondsa11)')
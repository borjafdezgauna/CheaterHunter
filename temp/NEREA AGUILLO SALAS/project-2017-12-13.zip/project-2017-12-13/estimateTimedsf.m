velocidadAutopista=dlmread('a1-driver1-log.csv');
velocidadAutopista2=dlmread('a1-driver2-log.csv');
velocidadNacional=dlmread('n1-driver1-log.csv');
velocidadNacional2=dlmread('n1-driver2-log.csv');
distanciaA=velocidadAutopista(:,1);
distanciaA2=velocidadAutopista2(:,1);
velocidadA=velocidadAutopista(:,2);
velocidadA2=velocidadAutopista2(:,2);
distanciaN=velocidadNacional(:,1);
distanciaN2=velocidadNacional2(:,1);
velocidadN=velocidadNacional(:,2);
velocidadN2=velocidadNacional2(:,2);

%kms=distancias y speedKmH=velocidades 
function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
xVector= kms;
yVector=speedKmH;
x=(max(xVector)-min(xVector))/numSlices;
interpola=interpolateLinearly( xVector, yVector, x);
estimatedTime=sum(interpola);

end





function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
m=toMeters( kms );
speedMs=toMetersPerSecond( speedKmH );
xVector= m;
yVector=speedMs;
trozo=(max(xVector)-min(xVector))/numSlices;
   for i=min(xVector):trozo:max(xVector)
       x=i;
      %for j=1:m:(length(xVector))-1
         interpola=interpolateLinearly( xVector, yVector, x);
         tiempo=x/interpola;
     % end
    end
estimatedTime=sum(tiempo);
end
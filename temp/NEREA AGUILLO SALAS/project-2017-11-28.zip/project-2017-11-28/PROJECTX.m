%ESTO ES LA TAREA 1
autopista=dlmread('a1-height.csv');
nacional=dlmread('n1-height.csv');

latitud=autopista(:,1);
longitud=autopista(:,2);
altura=autopista(:,3);
distancia=autopista(:,4);

latitud2=nacional(:,1);
longitud2=nacional(:,2);
altura2=nacional(:,3);
distancia2=nacional(:,4);

subplot(1,2,1);
alturas=plot(distancia,altura,distancia2,altura2);
ylabel('altura');
xlabel('distancia')
title('Alturas respecto distancia');
subplot(1,2,2);
latitudes=plot(longitud,latitud,longitud2,latitud2);
ylabel('latitud');
xlabel('longitud');
title('Latitud respecto longitud');
 
%ESTO ES LA TAREA 1.2

%Estadisticas de la ruta a1:
mediatotalAutopista= mean(autopista);
mediaAlturaAutopista= mediatotalAutopista(:,3);
desviacionAutopista = std(altura);
RangoAlturasAutopista= [min(altura),max(altura)];

%Estadisticas de la ruta n1:
mediatotalNacional= mean(nacional);
mediaAlturaNacional= mediatotalNacional(:,3);
desviacionNacional = std(altura2);
RangoAlturasNacional= [min(altura2),max(altura2)];

%ESTO ES LA TAREA 2


velocidadAutopista=dlmread('a1-driver1-log.csv');
velocidadAutopista2=dlmread('a1-driver2-log.csv');
velocidadNacional=dlmread('n1-driver1-log.csv');
velocidadNacional2=dlmread('n1-driver2-log.csv');

distanciaA=velocidadAutopista(:,1);
distanciaA2=velocidadAutopista2(:,1);

velocidadA=velocidadAutopista(:,2);
velocidadA2=velocidadAutopista2(:,2);

distanciaN=velocidadNacional(:,1);
distanciaN2=velocidadNacional2(:,1);

velocidadN=velocidadNacional(:,2);
velocidadN2=velocidadNacional2(:,2);

subplot(1,2,1);
alturas_2=plot(distanciaA,velocidadA,distanciaA2,velocidadA2);
ylabel('velocidad');
xlabel('distancia');
title('Velocidad/distancia A');
subplot(1,2,2);
latitudes_2=plot(distanciaN,velocidadN,distanciaN2,velocidadN2);
ylabel('velocidad');
xlabel('distancia');
title('Velocidad/distancia N');

%ESTO ES LA TAREA 2.1

%Estad�sticas del conductor1 en la ruta n1:
mediatotalNacional= mean(velocidadNacional);
mediaVelocidadNacional= mediatotalNacional(:,2);
desviacionNacional = std(velocidadN);
RangoVelocidadessNacional= [min(velocidadN),max(velocidadN)];

%Estad�sticas del conductor2 en la ruta n1:
mediatotalNacional2= mean(velocidadNacional2);
mediaVelocidadNacional2= mediatotalNacional2(:,2);
desviacionNacional2= std(velocidadN2);
RangoVelocidadesNacional2= [min(velocidadN2),max(velocidadN2)];

%Estad�sticas del conductor1 en la ruta a1:
mediatotalAutopista= mean(velocidadAutopista);
mediaVelocidadAutopista= mediatotalAutopista(:,2);
desviacionAutopista = std(velocidadA);
RangoVelocidadesAutopista= [min(velocidadA),max(velocidadA)];

%Estad�sticas del conductor2 en la ruta a1:
mediatotalAutopista2= mean(velocidadAutopista2);
mediaAlturaAutopista2= mediatotalAutopista2(:,2);
desviacionAutopista2 = std(velocidadA2);
RangoAlturasAutopista2= [min(velocidadA2),max(velocidadA2)];

%TRAS INTRODUCIR TODA LA INFORMACION QUE NECESITAMOS EMPEZAMOS CON LA TAREA
%3

clc
num=input('introduce un numero');
if num <1 || num >6
    disp('el numero introducido tiene que estar entre 1 y 6, porfavor intentelo mas tarde. Gracias');
    elseif num == 1
        run('Tarea1.m');
    elseif num==2
        run('Tarea1.m');
   
    elseif num==3
        conductor1_rutaA= (distanciaA/velocidadA);
        disp(conductor1_rutaA)
    elseif num==4
        disp{'tarea2.m'}
    elseif num==5
        disp{'tarea2.m'}
    elseif num==6

    end
end
        
      



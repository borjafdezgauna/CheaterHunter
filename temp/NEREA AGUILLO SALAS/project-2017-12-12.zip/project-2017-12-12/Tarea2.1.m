%Estad�sticas del conductor1 en la ruta n1:
mediatotalNacional= mean(velocidadNacional)
mediaVelocidadNacional= mediatotalNacional(:,2)
desviacionNacional = std(velocidadN)
RangoVelocidadessNacional= [min(velocidadN),max(velocidadN)]

%Estad�sticas del conductor2 en la ruta n1:
mediatotalNacional2= mean(velocidadNacional2)
mediaVelocidadNacional2= mediatotalNacional2(:,2)
desviacionNacional2= std(velocidadN2)
RangoVelocidadesNacional2= [min(velocidadN2),max(velocidadN2)]

%Estad�sticas del conductor1 en la ruta a1:
mediatotalAutopista= mean(velocidadAutopista)
mediaVelocidadAutopista= mediatotalAutopista(:,2)
desviacionAutopista = std(velocidadA)
RangoVelocidadesAutopista= [min(velocidadA),max(velocidadA)]

%Estad�sticas del conductor2 en la ruta a1:
mediatotalAutopista2= mean(velocidadAutopista2)
mediaAlturaAutopista2= mediatotalAutopista2(:,2)
desviacionAutopista2 = std(velocidadA2)
RangoAlturasAutopista2= [min(velocidadA2),max(velocidadA2)]


function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
% m=toMeters( kms );
% speedMs=toMetersPerSecond( speedKmH );
% xVector= m;
% yVector=speedMs;
tiempo_total=0;
mis_x=linspace(kms(1),kms(length(kms)),numSlices);
y = [];

x=(length(mis_x))/numSlices;                
        
    for i=1:length(mis_x)-1
       %para cada x en mis_x necesito mi_y
        % x=x2-x1;
         y(i)=interpolateLinearly( kms, speedKmH, mis_x(i));
         
         tiempo=x/y(i);
         tiempo_total=tiempo_total + tiempo;
     end
estimatedTime=tiempo_total;
end
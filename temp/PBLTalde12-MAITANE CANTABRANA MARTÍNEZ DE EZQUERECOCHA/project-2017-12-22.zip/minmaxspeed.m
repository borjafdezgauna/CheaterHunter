%ataza2-erako funtzio bat datuak garbiago bistaratzeko

function minmaxspeed(m, z)
  fprintf('Min-Max speed: [%.2f,', m);
  %% digituak idatzi
  for dig = z
    fprintf(' %.2f',dig);
    end
  
  %% testua itxi
  fprintf(']\n\n');
  end
  
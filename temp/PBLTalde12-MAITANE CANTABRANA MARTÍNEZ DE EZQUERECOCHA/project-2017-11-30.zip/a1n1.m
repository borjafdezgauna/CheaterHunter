
n1 = dlmread('n1-height.csv',',',1,0);
plot(n1(:,3),n1(:,4))
xlabel('distantzia(km)')
ylabel('altuera(m)')
title('nazionala eta autopista')

hold on
a1 = dlmread('a1-height.csv',',',1,0);
plot(a1(:,3),a1(:,4))
hold off

a = n1(:,3);
meanheight1 = mean(a)
sd1 = std(a)
z1 = max(a);
m1 = min(a);
minmaxspeed1 = [m1 z1]

b = a1(:,3);
Meanheight2 = mean(b)
sd2 = std(b)
z2 = max(b);
m2 = min(b);
minmaxspeed2 = [m2 z2]



%%route-elevations = sprintf('plot-%2d.csv',num);
%%saveas(jpg,route-elevations);

%%saveas aginduarekin grafika bat fitxategi batean gorde daiteke
%%Adibidea
%%f i g u r e ( ' v i s i b l e ' , ' o f f ' ) ;
%%pl o t ( time , h ei g h t ) ;
%%fil e n am e = s p r i n t f ( ' pl o t-%2d . c s v ' ,num) ;
%%s a v e a s ( gc f , fil e n am e ) ;


ax1 = subplot(2,1,1);
x = linspace(0,185);
a11 = dlmread('a1-driver1-log.csv',',');
plot(a11(:,1),a11(:,2))
title('autopista');
ylabel('km/h');
xlabel('km');


hold on
a12 = dlmread('a1-driver2-log.csv',',');
plot(a12(:,1),a12(:,2))
hold off
legend('a11','a12');

ax2 = subplot(2,1,2);
n11 = dlmread('n1-driver1-log.csv',',');
plot(n11(:,1),n11(:,2))
title('nazionala');
ylabel('km/h');
xlabel('km');

hold on
n12 = dlmread('n1-driver2-log.csv',',');
plot(n12(:,1),n12(:,2))
hold off
legend('n11','n12');

a = a11(:,2);
Meanspeed1 = mean(a)
sd1 = std(a)
z1 = max(a);
m1 = min(a);
minmaxspeed1 = [m1 z1]

b = a12(:,2);
Meanspeed2 = mean(b)
sd2 = std(b)
z2 = max(b);
m2 = min(b);
minmaxspeed2 = [m2 z2]

c = n11(:,2);
Meanspeed3 = mean(c)
sd3 = std(c)
z3 = max(c);
m3 = min(c);
minmaxspeed3 = [m3 z3]

d = n12(:,2);
Meanspeed4 = mean(d)
sd4 = std(d)
z4 = max(d);
m4 = min(d);
minmaxspeed4 = [m4 z4]





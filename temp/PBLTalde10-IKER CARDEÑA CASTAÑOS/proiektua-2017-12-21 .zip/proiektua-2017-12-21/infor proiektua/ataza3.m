zenbakia=1;
%%hau jarri dugu whilean dagoen parametroa definituta egoteko
while  zenbakia~=6
  %%if-ak bakarrik zenbaki hauen artean daudenean ejekutatzeko
  zenbakia=input('Eman zenbaki bat');
  %%zenbakia eskatu
  if zenbakia==1
    ataza1
    ataza12
    input('Sakatu edozein tekla jarraitzeko','s');
    close all
  elseif zenbakia==2
   ataza2 
   ataza22
       input('Sakatu edozein tekla jarraitzeko','s');
   close all
  elseif zenbakia==3
   ataza46
    input('sakatu edozein tekla jarraitzeko','s');
  elseif zenbakia==4
    
    input('Sakatu edozein tekla jarraitzeko','s');
  elseif zenbakia==5
    
    input('Sakatu edozein tekla jarraitzeko','s');
    
  elseif zenbakia<1 || zenbakia>6
        fprintf('Aukera ezegokia: zenbakia 1 eta 6 artean egon behar da\n')
    %%zenbaki bakoitzekin gauza konkretu batzuk bistaratzeko
    
  end
end
  
  
    
function [ hms ] = toHMS( seconds )
orduak=fix(seconds/3600);
%%orduak atera
minutuak=fix(rem(seconds,3600)/60);
%%aurreko ataleko hondarrarekin minutuak ateratzeko
segunduak=fix(rem(seconds,60));
%%aurreko ataleko hondarrarekin segunduak ateratzeko
hms=sprintf('%02d:%02d:%02d',orduak,minutuak,segunduak);
%%emaitza bistaratzeko
end




    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


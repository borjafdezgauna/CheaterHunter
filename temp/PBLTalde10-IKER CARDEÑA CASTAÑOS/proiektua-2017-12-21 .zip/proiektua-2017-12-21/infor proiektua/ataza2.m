id=1;
for i={'n1','a1'}
    for ii={'driver1','driver2'}
    filename= sprintf('%s-%s-log.csv',i{1},ii{1});
    errepideak=dlmread(filename,',',0,0);
    %%fitzategiak irakurri
    subplot(1,2,id)
    plot(errepideak(:,1),errepideak(:,2))
    hold on
    %%plotak egin
    xlabel('km');
    ylabel('km/h'); 
    %%grafikoen parrametroak identifikatu
    end
    if id==1
        title('n1-eko ibilbidea')
   else
        title('a1-eko ibilbidea')
   end
    id=id+1;
    %%plotak banatu
    xlabel('km');
    ylabel('km/h');
    legend('gidaria1','gidaria2')
end
 
  
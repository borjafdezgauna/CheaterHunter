zenbakia=input('eman zenbaki bat')
while 1=<zenbakia=<6
  if zenbakia=1
    fprintf(ataza1 && ataza12)
  elseif zenbakia=2
    fprintf(ataza2 && ataza22)
  elseif zenbakia=3
    fprintf()
  elseif zenbakia=4
    fprintf()
  elseif zenbakia=5
    fprintf()
   elseif zenbakia=6
    end
    end
  fprintf(Aukera ezegokia: zenbakia 1 eta 6 artean egon behar da)
  
    
N1h=dlmread('n1-height.csv',',');
A1h=dlmread('a1-height.csv',',');
plot( N1h(:,3),N1h(:,4))
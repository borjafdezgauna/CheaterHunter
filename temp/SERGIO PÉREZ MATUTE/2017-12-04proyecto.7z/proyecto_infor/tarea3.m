while 1<=a<=6
    if a=1
        imshow(route-elevations.png)
        
        
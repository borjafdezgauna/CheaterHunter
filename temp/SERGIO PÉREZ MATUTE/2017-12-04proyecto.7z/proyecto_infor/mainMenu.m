clc
clear all
% A0='####### MENU #######';
% A1='1. Muestra las graficas y estadisticas de las rutas';
% A2='2. Muestra las graficas y estadisticas de los conductores';
% A3='3. Calculos del tiempo para coneductor y ruta';
% A4='4. Comprobar los limites de velocidad';
% A5='5. Calculo de consumo de combustible para cada conductor y ruta';
% A6='6. Salir';
% formatSpec = ' %1$s\n %2$s\n %3$s\n %4$s\n %5$s\n %6$s\n';
% tabla = sprintf(formatSpec,A0,A1,A2,A3,A4,A5,A6)
MiMenu={'####### MENU #######';'1. Muestra las graficas y estadisticas de las rutas';'2. Muestra las graficas y estadisticas de los conductores';'3. Calculos del tiempo para coneductor y ruta';'4. Comprobar los limites de velocidad';'5. Calculo de consumo de combustible para cada conductor y ruta';'6. Salir'}
a=input('elige una opci�n: ')
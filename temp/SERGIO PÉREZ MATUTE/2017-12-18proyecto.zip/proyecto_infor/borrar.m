% clear all
% clc
% file=sprintf('n1-driver1-log.csv')
% datos=dlmread(file,',',0,0);
% velocidad=datos(:,2)
% kms=datos(:,1)
x=[0 1 2 3 4 5]
maximo=max(x)
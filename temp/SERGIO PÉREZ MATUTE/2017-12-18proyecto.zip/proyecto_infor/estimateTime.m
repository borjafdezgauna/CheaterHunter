
function [estimatedTime] = estimateTime (kms, speedkmH,numSlices)
vectorX = linspace(0,max(kms),numSlices);              
j=1;
for j=1:length(vectorX)
    j=j+1;
    miy = interpolateLinearly (vectorX,speedkmH,vectorX(j));

X1=vectorX(j);
X2=vectorX(j+1);
Y1=miy(j);
end
estimatedTime = cumsum((X2-X1)/Y1)
end

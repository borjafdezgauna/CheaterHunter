while 1<=a<=6
    if a=1
        (tarea1a.m)
    elseif a=2
        (tarea2a.m)
    elseif a=3
        
        
        
        
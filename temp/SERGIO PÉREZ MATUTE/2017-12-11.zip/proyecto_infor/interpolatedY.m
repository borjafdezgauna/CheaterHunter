clear all
clc

function [interpolatedY]=interpolatedLinearly(xvector,yvector,x)
    i=1
    j=1
        while x>=(min(xvector))&& x<=(max(xvector))
            i=1:length(xvector);
            interpolatedY=((yvector)*(((yvector+1)-(yvector))/((i+1)-i))*(x-i));
        end
    
end


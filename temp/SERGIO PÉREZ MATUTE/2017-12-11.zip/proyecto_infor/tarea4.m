function [interpolatedY]=interpolateLinearly(xvector,yvector,x)
yvector=[]
xvector=[]
    for i=1:length(yvector)
        a=(i+1)-i
        for j=1:length(xvector)
            b=(j+1)-j

        end
    end
interpolatedY=a/b
end

clc
clear all
archivo_a1=dlmread('a1-height.csv',',',1,0);
% cargamos el archivo a1_height desde la primera fila hasta la
% ultima,poniendo como divisor del vector una coma en la funciion dlmread
archivo_n1=dlmread('n1-height.csv',',',1,0);
% cargamos el archivo n1_height desde la primera fila hasta la
% ultima,poniendo como divisor del vector una coma en la funciion dlmread
subplot(2,2,1)
% dividos el plot en 4 partes, de tal manera que este grafico estar� en la
% parte superior izquierda.
plot(archivo_a1(:,4),archivo_a1(:,3))
% ploteamos en el eje x la columna 4 y en el eje y la columna 3
title('altura vs distancia autovia')
% ponemos un titulo al gr�fico
xlabel('distancia(km)')
% nombramos al eje x 
ylabel('altura(m)')
% nombramos al eje y 
subplot(2,2,2)
plot(archivo_n1(:,4),archivo_n1(:,3))
title('altura vs distancia nacional')
xlabel('distancia(km)')
ylabel('altura(m)')
subplot(2,2,3)
plot(archivo_a1(:,1),archivo_a1(:,2))
title('latitud vs longitud autovia')
xlabel('latitud')
ylabel('longitud')
subplot(2,2,4)
plot(archivo_n1(:,1),archivo_n1(:,2))
title('latitud vs longitud nacional')
xlabel('latitud')
ylabel('longitud')


function [m] = toMeters (km)
m= km*1000;
fprintf('toMeters (%2.f km)=> %2.f (m):\n',km,m)
end

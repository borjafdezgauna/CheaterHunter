function [kms,velocidad]= leervalores4(nombrearchivo)
v=dlmread(nombrearchivo,',',0,0);
kms=v(:,1);
kms=kms';
velocidad=v(:,2);
velocidad=velocidad';
plot(kms,velocidad);
end
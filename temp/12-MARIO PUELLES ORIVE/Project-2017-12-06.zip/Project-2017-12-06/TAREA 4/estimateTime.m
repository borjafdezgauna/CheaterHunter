
[kms,velocidad]=leervalores4('a1-driver1-log.csv');
[kms,velocidad]=leervalores4('a1-driver2-log.csv');
[kms,velocidad]=leervalores4('n1-driver1-log.csv');
[kms,velocidad]=leervalores4('n1-driver2-log.csv');
[interpolatedY]=interpolateLinearly(kms,velocidad,1000)

v=dlmread('a1-driver1-log.csv',',',0,0);
distancia=v(:,1);
distancia=distancia';
velocidad=v(:,2);
velocidad=velocidad';
a=estimateTime(distancia,velocidad,1000)
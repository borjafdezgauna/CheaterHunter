% SPEED VS DISTANCE PLOTS %

Firstdriver = 'a1-driver1-log.csv';
Firstdriversgoing = dlmread(Firstdriver,',',1,0);
Distance1 = Firstdriversgoing(:,2);
Speed1= Firstdriversgoing(:,1);

Secondriver = 'a1-driver2-log.csv';
Secondriverswgoing = dlmread(Secondriver,',',1,0);
Distance2 = Secondriverswgoing(:,2);
Speed2= Secondriverswgoing(:,1);

subplot(2,2,[2,3]);
plot (Speed1,Distance1,Speed2, Distance2)

Firstdriver1 = 'n1-driver1-log.csv';
Firstdriversreturn= dlmread(Firstdriver1,',',1,0);
Distance3 = Firstdriversreturn(:,2);
Speed3= Firstdriversreturn(:,1);

Secondriver1 = 'n1-driver2-log.csv';
Secondriverswreturn = dlmread(Secondriver1,',',1,0);
Distance4 = Secondriverswreturn(:,2);
Speed4 = Secondriverswreturn(:,1);

subplot(2,2,[2,3]);
plot(Speed3,Distance3,Speed4, Distance4)

% SPEED STATS %
M =dlmread ('a1-driver1-log.csv',',');

a = max (M(:,2));
b = min (M(:,2));
c = mean(M(:,2));
d = std (M(:,2));
X=sprintf ('driver1 statistics in route n1 \n Mean speed: % .2f (sd.%.2f)\n min-max speed :[% .2f,% .2f]',c,d,b,a );
disp (X)

M2=dlmread ('a1-driver2-log.csv',',');

a2 = max (M2(:,2));
b2 = min (M2(:,2));
c2 = mean(M2(:,2));
d2 = std (M2(:,2));
X2=sprintf ('driver1 statistics in route n1 \n Mean speed: % .2f (sd.%.2f)\n min-max speed :[% .2f,% .2f]',c2,d2,b2,a2 );
disp (X2)

M3 =dlmread ('n1-driver1-log.csv',',');

a3 = max (M3(:,2));
b3 = min (M3(:,2));
c3 = mean(M3(:,2));
d3 = std (M3(:,2));
X3=sprintf ('driver1 statistics in route n1 \n Mean speed: % .2f (sd.%.2f)\n min-max speed :[% .2f,% .2f]',c3,d3,b3,a3 );
disp (X3)

M4 =dlmread ('n1-driver2-log.csv',',');

a4 = max (M4(:,2));
b4 = min (M4(:,2));
c4 = mean(M4(:,2));
d4 = std (M4(:,2));
X4=sprintf ('driver1 statistics in route n1 \n Mean speed: % .2f (sd.%.2f)\n min-max speed :[% .2f,% .2f]',c4,d4,b4,a4);
disp (X4)
%4.2Workspace
%FirstDriverKm
FirstDriverKm = 'a1-driver1-log.csv';
a = dlmread(FirstDriverGo,',',1,0);
Km= a(:,1);

%SecondDriverKm
SecondDriverKm = 'a1-driver2-log.csv';
a = dlmread(SecondDriverGo,',',1,0);
km = a(:,1);


function time = calculatetime(xmeters, yspeed)

time = 0;

for i = 2:length(xmeters)
   m = xmeters(i) - xmeters(i-1);
   v = yspeed(i);
   t = m/v;
   time = time + t;
end

end
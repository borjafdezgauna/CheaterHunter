function [estimatedTime]=estimateTime(kms,speedKmH,numSlices)
    estimatedTime=0;
    metersDifference=max(kms)/numSlices;
    for i=1:numSlices
        x=(i-1)*metersDifference;
        y=interpolateLinearly(kms,speedKmH,x);
        estimatedTime=estimatedTime+(metersDifference/y);
    end
    estimatedTime=estimatedTime*3600;
    
   
end          
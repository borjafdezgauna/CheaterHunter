 seconds = estimateTime2(kms,speedKmH,numSlices);

 function [ hms ] = toHMS( seconds );
  hours = fix(seconds/3600);
  mins = fix(rem(seconds,3600)/60);
  secs = fix(rem(seconds,60));
  time = sprintf('%02d:%02d:%02d',hours, mins, secs);
 disp(time)
end
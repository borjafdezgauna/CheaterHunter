driver1Go =dlmread('a1-driver1-log.csv',',',1,0);
driver2Go=dlmread('a1-driver2-log.csv',',',1,0);
driver1ComeBack=dlmread('n1-driver1-log.csv',',',1,0);
driver2ComeBack=dlmread('n1-driver2-log.csv',',',1,0);
kmsDriver1Go=driver1Go(:,1);
kmsDriver2Go=driver2Go(:,1);
kmsDriver1ComeBack=driver1ComeBack(:,1);
kmsDriver2ComeBack=driver2ComeBack(:,1);
speedDriver1Go=driver1Go(:,2);
speedDriver2Go=driver2Go(:,2);
speedDriver1ComeBack=driver1ComeBack(:,2);
speedDriver2ComeBack=driver2ComeBack(:,2);
%Driver1 Go
estimatedTimeDriver1Go=estimateTime2(kmsDriver1Go,speedDriver1Go,10000);
Driver1Go=toHMS2(estimatedTimeDriver1Go);
fprintf('Estimated time for driver1 go:  %s',Driver1Go);
%Driver 2 Go
estimatedTimeDriver2Go=estimateTime2(kmsDriver2Go,speedDriver2Go,10000);
Driver2Go=toHMS2(estimatedTimeDriver2Go);
fprintf('\nEstimated time for driver2 go:  %s',Driver2Go);
%Driver 1 Come Back
estimatedTimeDriver1ComeBack=estimateTime2(kmsDriver1ComeBack,speedDriver1ComeBack,10000);
Driver1ComeBack=toHMS2(estimatedTimeDriver1ComeBack);
fprintf('\nEstimated time for driver1 Come Back:  %s',Driver1ComeBack);
%Driver 2 Come Back
estimatedTimeDriver2ComeBack=estimateTime2(kmsDriver2ComeBack,speedDriver2ComeBack,10000);
Driver2ComeBack=toHMS2(estimatedTimeDriver2ComeBack);
fprintf('\nEstimated time for driver2 Come Back:  %s',Driver2ComeBack);

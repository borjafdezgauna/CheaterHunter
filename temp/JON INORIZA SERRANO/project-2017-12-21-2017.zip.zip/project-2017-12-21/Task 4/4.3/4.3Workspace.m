%4.3Workspace
%FirstDriverGo
FirstDriverGo = 'a1-driver1-log.csv';
m = dlmread(FirstDriverGo,',',1,0);
speedKmH = m(:,1);

%FirstDriverComeBack
FirstDriverComeBack = 'a1-driver1-log.csv';
m = dlmread(FirstDriverComeBack,',',1,0);
speedKmH = m(:,2);

%SecondDriverGo
SecondDriverGo = 'a1-driver2-log.csv';
m = dlmread(SecondDriverGo,',',1,0);
speedKmH = m(:,1);

%SecondDriverComeBack
SecondDriverComeBack = 'a1-driver2-log.csv';
m = dlmread(SecondDriverComeBack,',',1,0);
speedKmH = m(:,2);

%FirstNDriverGo
FirstNDriverGo = 'n1-driver1-log.csv';
m = dlmread(FirstNDriverGo,',',1,0);
speedKmH = m(:,1);

%FirstNDriverComeBack
FirstNDriverComeBack = 'n1-driver1-log.csv';
m = dlmread(FirstNDriverComeBack,',',1,0);
speedKmH = m(:,2);

%SecondNDriverGo
SecondNDriverGo = 'n1-driver2-log.csv';
m = dlmread(SecondNDriverGo,',',1,0);
speedKmH = m(:,1);

%SecondNDriverComeBack
SecondNDriverComeBack = 'n1-driver2-log.csv';
m = dlmread(SecondNDriverComeBack,',',1,0);
speedKmH = m(:,2);

% LATITUDE VS LONGITUDE PLOTS %
subplot(2,1,1);
Filename1 = 'a1-height.csv';
Route1 = dlmread(Filename1,',',1,0);
Longitude1 = Route1(:,2);
Latitude1 = Route1(:,1);
subplot(2,1,2);
Filename2 = 'n1-height.csv';
Route2 = dlmread(Filename2,',',1,0);
Longitude2 = Route2(:,2);
Latitude2 = Route2(:,1);
subplot(2,2,[2,3]);
plot(Longitude1,Latitude1,Longitude2,Latitude2,'b')


% HEIGHT PLOTS %
subplot(2,2,1);
filename = 'a1-height.csv';
route1 = dlmread(filename,',',1,0);
Distance = route1(:,4);
Elevation = route1(:,3);
plot(Distance,Elevation);
title ('Donosti-Gasteiz1 (elevation)');

subplot(2,2,2);
filename2 = 'n1-height.csv';
route2 = dlmread(filename2,',',1,0);
Distance2 = route2(:,4);
Elevation2 = route2(:,3);
plot(Distance2,Elevation2);
title('Donosti-Gasteiz2 (elevation)');

subplot(2,2,[3,4]);
plot(Distance,Elevation,Distance2,Elevation2);


% ROUTE STATS%
M = dlmread ('a1-height.csv',',',1,0);
maxHeight = max (M(:,3));
minHeight = min (M(:,3));
meanHeight = mean (M(:,3));
sdHeight = std (M(:,3));

a1RouteStats = sprintf ('a1 route statistics:\nMean height: %.2f (sd: %.2f)\nHeight range: [%.2f, %2.f]', meanHeight, sdHeight, minHeight, maxHeight);
disp (a1RouteStats)

X = dlmread ('n1-height.csv',',',1,0);
maxHeight2 = max (X(:,3));
minHeight2 = min (X(:,3));
meanHeight2 = mean (X(:,3));
sdHeight2 = std (X(:,3));

a1RouteStats = sprintf ('n1 route statistics:\nMean height: %.2f (sd: %.2f)\nHeight range: [%.2f, %2.f]', meanHeight2, sdHeight2, minHeight2, maxHeight2);
disp (a1RouteStats)

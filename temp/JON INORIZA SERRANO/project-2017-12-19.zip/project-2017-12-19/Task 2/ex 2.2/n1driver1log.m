M =dlmread ('n1-driver1-log.csv',',');

a = max (M(:,2));
b = min (M(:,2));
c = mean(M(:,2));
d = std (M(:,2));
X=sprintf ('driver1 statistics in route n1\n Mean speed: %.2f (sd.%.2f)\n min-max speed :[%.2f,%.2f]',c,d,b,a );
disp (X)
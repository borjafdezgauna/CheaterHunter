xmeters = [0 1 2 3];
yspeed =  [0 10 20 30];
t213121 = calculatetime(xmeters, yspeed)
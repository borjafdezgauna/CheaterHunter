%4.1Workspace
%x
distance = 'a1-height-log.csv';
m = dlmread(distance,',',1,0);
xVector = m(:,4);

%y
speed = 'a1-height-log.csv';
a = dlmread(speed,',',1,0);
yVector = a(:,1);
function [ hms ] = toHMS( seconds );
hours = seconds/3600;
mins = mod(seconds,3600)/60;
secs = mod(seconds/3600,60);
time = sprintf('%.0f:%.0f:%.0f',hours, mins, secs);
disp(time)
end

menu = sprintf('####### MENU ########:\n 1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit');
disp (menu)
x=input('Choose an option:')
if x < 1 || x > 6 
    error = fprintf('Incorrect option: it must be between 1 and 6')
    disp (error)
elseif x == 1
    TASK1; 
elseif x == 2
    TASK2
elseif x == 3
    TASK4;
elseif x == 4
    TASK5;
elseif x == 5
    TASK6;
elseif x == 6
    exit;
end
end
end
end
end
end
end
menu = sprintf('####### MENU ########:\n 1. Show route plots/statistics\n2. Show driver plots/statistics\n3. Time calculations for each driver/route\n4. Check speed limits\n5. Fuel consumption calculations for each driver/route\n6. Exit\nChoose an option:');
disp (menu)
function menu = selectOption(x)
if x < 1 || x > 6 
    error = fprintf('Incorrect option: it must be between 1 and 6')
    disp (error)
if x == 1
    TASK1; 
if x == 2
    TASK2;
if x == 3
    TASK4;
if x == 4
    TASK5;
if x == 5
    TASK6;
if x == 6 
end
end
end
end
end
end
end
disp('####### MENU ########:')
disp('1. Show route plots/statistics')
disp('2. Show driver plots/statistics')
disp('3. Time calculations for each driver/route')
disp('4. Check speed limits')
disp('5. Fuel consumption calculations for each driver/route')
disp('6. Exit')
x=input('Choose an option:')





if x=1
    disp('route statistics')
     % Name of task route plots/statistics script
     
elseif x=2
    disp('driver plot statistics')
     % Name of task driver plots/statistics script
     
elseif x=3
    disp('time calculations for each driver/route script')
     % Name of task calculations for each driver/route script
elseif x=4
    disp('Speed limits')
     % Name of task speed limits script
elseif x=5
    disp('Fuel consumptions for each driver/route')
     % Name of task  Fuel consumption for each driver/route script
elseif x=6
     disp('EXIT')
else
    disp('Incorrect option: it must be between 1 and 6')
end
   

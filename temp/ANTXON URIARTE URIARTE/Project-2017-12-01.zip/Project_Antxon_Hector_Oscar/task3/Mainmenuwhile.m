disp('####### MENU ########:')
disp('1. Show route plots/statistics')
disp('2. Show driver plots/statistics')
disp('3. Time calculations for each driver/route')
disp('4. Check speed limits')
disp('5. Fuel consumption calculations for each driver/route')
disp('6. Exit')
x=input('Choose an option:')

while x>=1 && x<=5
   if x==1
         disp('route statistics')
     % Name of task route plots/statistics script
        disp('press any key')
        pause
        
        disp('####### MENU ########:')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp('6. Exit')
        x=input('Choose an option:')
   elseif x==2
        disp('plots/statistics')
     % Name of task driver plots/statistics script 
        disp('press any key')
        pause
        
        disp('####### MENU ########:')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp('6. Exit')
        x=input('Choose an option:')
   elseif x==3
       disp('Time calculations for each driver/route')
     % Name of task Time calculations for each driver/route script 
        disp('press any key')
        pause
        
        disp('####### MENU ########:')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp('6. Exit')
        x=input('Choose an option:')
   elseif x==4
       disp('Check speed limits')
     % Name of task Check speed limits script
        disp('press any key')
        pause
        disp('####### MENU ########:')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp('6. Exit')
        x=input('Choose an option:')
   elseif x==5
       
   end
       
        disp('####### MENU ########:')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp('6. Exit')
        x=input('Choose an option:')
        
end

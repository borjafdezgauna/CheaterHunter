function [ interpolatedY ] = interpolateLinearly( xVector, yVector, x)
interpolatedY= lerp( xVector, yVector, x)
end

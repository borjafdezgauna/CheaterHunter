function [ hms ] = toHMS( seconds )
  i=senconds
  while i>=60 && i<=3600
    i=rem(i,60)
    MM= fix(i/60)
    HH=00
    endwhile
    while i>=3600
      i= rem(i/60)
      MM=fix(i/60)
      HH=fix(MM/60)
     endwhile
 endfunction
 hms=fprintf('%2d:%2d:%2d',HH,MM,i)
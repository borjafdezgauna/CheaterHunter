%N1 Longitud-Latitud
n1heights=dlmread('n1-height.csv',',',1,0);
n1longitude= n1heights(:,2);
n1latitude= n1heights(:,1);
%A1 Height-Distance
a1heights= dlmread('a1-height.csv',',',1,0);
a1longitude=a1heights(:,2);
a1latitude= a1heights(:,1);
%Plots of distance-height
subplot(1,2, [1 2])
plot(n1latitude,n1longitude,a1latitude,a1longitude)
xlabel('Latitude')
ylabel('Longitude')
title('Path N1 and A1')
legend('N1','A1')


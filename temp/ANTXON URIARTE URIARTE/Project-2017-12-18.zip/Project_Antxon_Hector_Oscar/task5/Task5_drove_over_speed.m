N1_speedLimit= dlmread('n1-speed-limit.csv',';');
LimitkilometersN1=N1_speedLimit(:,1);
LimitSpeedsN1=N1_speedLimit(:,2);

A1_speedLimit= dlmread('a1-speed-limit.csv',';');
limitkilometersA1=A1_speedLimit(:,1);
LimitSpeedsA1=A1_speedLimit(:,2);

A1_1=dlmread('a1-driver1-log.csv',',');
DriverLogkm= A1_1(:,1);
DriverLogspeed= A1_1(:,2);
 
numSlices=length(DriverLogkm);
A1_1Results= checkSpeedLimits(DriverLogkm,DriverLogspeed,limitkilometersA1,LimitSpeedsA1,numSlices)

A1_2= dlmread('a1-driver2-log.csv',',');
DriverLogkm1= A1_2(:,1);
DriverLogspeed1= A1_2(:,2);

numSlices1=length(DriverLogkm1);
A1_2Results=checkSpeedLimits(DriverLogkm1,DriverLogspeed1,limitkilometersA1,LimitSpeedsA1,numSlices1)


N1_1=dlmread('n1-driver1-log.csv',',');
DriverLogkm2= N1_1(:,1);
DriverLogspeed2= N1_1(:,2);
 
numSlices2=length(DriverLogkm2);
N1_1Results=checkSpeedLimits(DriverLogkm2,DriverLogspeed2,LimitkilometersN1,LimitSpeedsN1,numSlices2)


N1_2=dlmread('n1-driver2-log.csv',',');
DriverLogkm3= N1_2(:,1);
DriverLogspeed3= N1_2(:,2);

 
numSlices3=length(DriverLogkm3);
N1_2Results=checkSpeedLimits(DriverLogkm3,DriverLogspeed3,LimitkilometersN1,LimitSpeedsN1,numSlices3)

function [ interpolatedY ] = interpolateToTheLeft( xVector, yVector , x)
i=1;


while i <= length(xVector)&& xVector(i)<x 
    i=i+1;  
end

if i == 1
    i = i +1;
end

y0=yVector(i-1);

interpolatedY= y0;



end

  

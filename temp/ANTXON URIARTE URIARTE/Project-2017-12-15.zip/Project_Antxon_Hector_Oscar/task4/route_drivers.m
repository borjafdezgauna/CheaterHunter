A1_1=dlmread('a1-driver1-log.csv',',');
kms= A1_1(:,1);
speedKmH= A1_1(:,2);

numSlices=length(kms);

estimateTime(kms,speedKmH,numSlices)


A1_2= dlmread('a1-driver2-log.csv',',');
kms= A1_2(:,1);
speedKmH= A1_2(:,2);

numSlices=length(kms);

estimateTime(kms,speedKmH,numSlices)


N1_1=dlmread('n1-driver1-log.csv',',');
kms= N1_1(:,1);
speedKmH= N1_1(:,2);

numSlices=length(kms);

estimateTime(kms,speedKmH,numSlices)


N1_2=dlmread('n1-driver2-log.csv',',');
kms= N1_2(:,1);
speedKmH= N1_2(:,2);

numSlices=length(kms);

estimateTime(kms,speedKmH,numSlices)


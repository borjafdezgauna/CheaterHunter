function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
m=toMeters(kms);
msSpeed=toMetersPerSecond(speedKmH);
i=1;
distance= (m./numSlices);
    
while i< numSlices
    speed= msSpeed(i+1);
    t(i)= (distance(i)/speed)/i;  
    i=i+1;
end
estimatedTime=sum(t)
end
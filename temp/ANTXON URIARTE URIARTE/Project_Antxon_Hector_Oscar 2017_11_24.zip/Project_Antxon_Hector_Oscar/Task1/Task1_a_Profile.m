%N1 Height-Distance
n1heights=dlmread('n1-height.csv',',',1,0);
n1distance= n1heights(:,4);
n1elevation= n1heights(:,3);
%A1 Height-Distance
a1heights= dlmread('a1-height.csv',',',1,0);
a1distance=a1heights(:,4);
a1elevation= a1heights(:,3);
%Plots of distance-height
subplot(1,2, [1 2])
plot(n1distance,n1elevation,a1distance,a1elevation)
xlabel('Distance(km)')
ylabel('Height(m)')
title('profile N1 and A1')




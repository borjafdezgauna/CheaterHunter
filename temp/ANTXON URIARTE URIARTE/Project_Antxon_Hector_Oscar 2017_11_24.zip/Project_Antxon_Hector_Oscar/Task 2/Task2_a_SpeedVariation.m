n1Driver1=dlmread('n1-driver1-log.csv',',');
n1Speed =n1Driver1(:,2);
n1Distance =n1Driver1(:,1);

n1Driver2=dlmread('n1-driver2-log.csv',',');
n1Speed2=n1Driver2(:,2);
n1Distance2=n1Driver2(:,1);

a1Driver1=dlmread('a1-driver1-log.csv',',');
a1Speed=a1Driver1(:,2);
a1Distance=a1Driver1(:,1);

a1Driver2=dlmread('a1-driver2-log.csv',',');
a1Speed2=a1Driver2(:,2);
a1Distance2=a1Driver2(:,1);

subplot(2,2,1)
plot(n1Distance,n1Speed)
xlabel('distance(km)')
ylabel('speed(km/h)')
title('N1 driver 1')

subplot(2,2,2)
plot(n1Distance2,n1Speed2)
xlabel('distance(km)')
ylabel('speed(km/h)')
title('N1 driver 2')

subplot(2,2,3)
plot(a1Distance,a1Speed)
xlabel('distance(km)')
ylabel('speed(km/h)')
title('A1 driver 1')

subplot(2,2,4)
plot(a1Distance2,a1Speed2)
xlabel('distance(km)')
ylabel('speed(km/h)')
title('A1 driver 2')

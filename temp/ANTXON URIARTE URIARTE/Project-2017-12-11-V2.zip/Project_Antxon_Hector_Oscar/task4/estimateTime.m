
function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
interpolatedLinearly

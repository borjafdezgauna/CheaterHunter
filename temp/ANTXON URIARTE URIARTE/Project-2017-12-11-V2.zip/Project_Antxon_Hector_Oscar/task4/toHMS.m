function [ hms ] = toHMS( seconds )
  if seconds>=60 && seconds<3600
    SS=rem(seconds,60);
    MM= fix(seconds/60);
    HH=00;
     hms=fprintf('%02d:%0.2d:%02.0f',HH,MM,SS);
  elseif seconds>=3600
      HH=fix(seconds/3600);
      MM=fix(rem(seconds,3600)/60);
      SS=rem(rem(seconds,3600),60);
      hms=fprintf('%0.2d:%0.2d:%02.0f',HH,MM,SS);
  end
    
end

%We change from kilometers to meters
function [ m ] = toMeters( kms )
m= kms.*1000;
end

for k=0:0.003:3
    disp(k)
end
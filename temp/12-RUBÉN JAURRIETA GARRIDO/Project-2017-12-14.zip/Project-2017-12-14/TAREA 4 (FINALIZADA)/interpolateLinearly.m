function  interpolatedY = interpolateLinearly(xVector,yVector,x)
resta=xVector-x;
if all(resta)==0
    a=(resta==0);
    interpolatedY=a*yVector';
else
    c=find(resta>0);
    c=resta(c);
    c=min(c);
    xder=x+c;
    b2=(xVector==xder);
    yder=b2*yVector';
    d=find(resta<0);
    d=resta(d);
    d=max(d);
    xizq=x+d;
    b3=(xVector==xizq);
    yizq=b3*yVector';
    interpolatedY=yizq+((yder-yizq)/(xder-xizq))*(x-xizq);
end
end

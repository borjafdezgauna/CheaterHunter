[kms,speedKmH]=leervalores4('a1-driver2-log.csv');
[distancia,limite]=leervalores5('a1-speed-limit.csv');
numSlices=1000;
z=kms(1);
v=kms(end);
w=(v-z)/numSlices;
a=(w:w:v);
for i=1:numSlices
b(i)=interpolateLinearly(kms,speedKmH,a(i));
c(i)=interpolatetoleft(distancia,limite,a(i));
end
j=b>c;
plot(a,b)
hold on
plot(a,c)
persup=(sum(j)/numSlices)
p=estimateTime(kms,speedKmH,numSlices);
p=p*persup;
tiempo=toHMS(p)


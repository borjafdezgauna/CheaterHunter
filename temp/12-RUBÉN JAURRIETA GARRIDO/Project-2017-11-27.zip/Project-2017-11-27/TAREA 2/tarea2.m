v=dlmread('a1-driver1-log.csv',',',0,0);
distanciaa1dr1=v(:,1);
distanciaa1dr1=distanciaa1dr1';
velocidada1dr1=v(:,2);
velocidada1dr1=velocidada1dr1';
figure
subplot (2,1,1)
plot(distanciaa1dr1,velocidada1dr1)
title('Ruta a1 Driver 1')
xlabel('Distancia')
ylabel('Velocidad')
hold on
c=dlmread('a1-driver2-log.csv',',',0,0);
distanciaa1dr2=c(:,1);
distanciaa1dr2=distanciaa1dr2';
velocidada1dr2=c(:,2);
velocidada1dr2=velocidada1dr2';
plot(distanciaa1dr2,velocidada1dr2)

w=dlmread('n1-driver1-log.csv',',',0,0);
distancian1dr1=w(:,1);
distancian1dr1=distancian1dr1';
velocidadn1dr1=w(:,2);
velocidadn1dr1=velocidadn1dr1';
subplot (2,1,2)
plot(distancian1dr1, velocidadn1dr1)
title('Ruta n1 Driver1')
xlabel('Distancia')
ylabel('Velocidad')
hold on

u=dlmread('n1-driver2-log.csv',',',0,0);
distancian1dr2=u(:,1);
distancian1dr2=distancian1dr2';
velocidadn1dr2=u(:,2);
velocidadn1dr2=velocidadn1dr2';
plot(distancian1dr2,velocidadn1dr2)
saveas(gcf,'Tarea2.png','jpg')

mediavelocidadn1dr1=mean(velocidadn1dr1);
mediavelocidadn1dr2=mean(velocidadn1dr2);
mediavelocidada1dr1=mean(velocidada1dr1);
mediavelocidada1dr2=mean(velocidada1dr2);
desviacionn1dr1=std(velocidadn1dr1);
desviacionn1dr2=std(velocidadn1dr2);
desviaciona1dr1=std(velocidada1dr1);
desviaciona1dr2=std(velocidada1dr2);
rangon1dr1min=min(velocidadn1dr1);
rangon1dr1max=max(velocidadn1dr1);
rangon1dr2min=min(velocidadn1dr2);
rangon1dr2max=max(velocidadn1dr2);
rangoa1dr1min=min(velocidada1dr1);
rangoa1dr1max=max(velocidada1dr1);
rangoa1dr2min=min(velocidada1dr2);
rangoa1dr2max=max(velocidada1dr2);

fprintf('Estadisticas del conductor1 en la ruta n1:\n')
fprintf('Velocidad media: %.2f (sd: %.2f)\n',mediavelocidadn1dr1,desviacionn1dr1)
fprintf('Rango de velocidades: [%.2f, %.2f]\n',rangon1dr1min,rangon1dr1max)
fprintf('\n')
fprintf('Estadisticas del conductor2 en la ruta n1:\n')
fprintf('Velocidad media: %.2f (sd: %.2f)\n',mediavelocidadn1dr2,desviacionn1dr2)
fprintf('Rango de velocidades: [%.2f, %.2f]\n',rangon1dr2min,rangon1dr2max)
fprintf('\n')
fprintf('Estadisticas del conductor1 en la ruta a1:\n')
fprintf('Velocidad media: %.2f (sd: %.2f)\n',mediavelocidada1dr1,desviaciona1dr1)
fprintf('Rango de velocidades: [%.2f, %.2f]\n',rangoa1dr1min,rangoa1dr1max)
fprintf('\n')
fprintf('Estadisticas del conductor2 en la ruta a1:\n')
fprintf('Velocidad media: %.2f (sd: %.2f)\n',mediavelocidada1dr2,desviaciona1dr2)
fprintf('Rango de velocidades: [%.2f, %.2f]\n',rangoa1dr2min,rangoa1dr2max)
function  interpolatedY = interpolateLinearly(kms,velocidad,numSlices)
plot(kms, velocidad)

interpolatedY=interp1(kms,Velocidad,numSlices)
end
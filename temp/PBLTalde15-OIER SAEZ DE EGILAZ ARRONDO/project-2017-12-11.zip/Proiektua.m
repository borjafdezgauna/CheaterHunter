MenuOption=0;
while MenuOption~=6
  clc
  fprintf('#######  MENU  ########:\n 1. Show route plots/statistics\n 2. Show driver plots/statistics\n 3. Time calculations for each driver/route\n 4. Check speed limits\n 5. Fuel consumption calculations for each driver/route\n 6. Exit\n')
  MenuOption= input('Sartu nahi den ariketa: ');
  MenuOption=MenuZenbakia(MenuOption);
  if MenuOption==1
    Ataza1
    input('Sakatu edozein tekla jarraitzeko','s');
    close all
  end
    if MenuOption==2
    Ataza2
    input('Sakatu edozein tekla jarraitzeko','s');
    close all
  end
    if MenuOption==3
    Ataza4
    input('Sakatu edozein tekla jarraitzeko','s');
    close all    
  end
    if MenuOption==4
    Ataza5
    input('Sakatu edozein tekla jarraitzeko','s');
    close all
  end
    if MenuOption==5
    Ataza6
    input('Sakatu edozein tekla jarraitzeko','s');
    close all
  end
     if MenuOption==6
       EZ=0;
        while EZ==0
         Erantzuna=input('Benetan atera nahi duzu? (1=Bai/0=Ez)');
           if Erantzuna==1
             MenuOption=6;
             EZ=1;
           else
           end
           if Erantzuna==0
             MenuOption=0;
              EZ=1;
           else
           end
        end
  end
end
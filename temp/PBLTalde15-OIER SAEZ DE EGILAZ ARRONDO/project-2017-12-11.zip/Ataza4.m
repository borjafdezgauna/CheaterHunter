fprintf('\n\n')
tarteak=input('Sartu estimazioa egiteko nahi duzun tarte kopurua: ');
for errepidea={'a','n'}
  for gidaria={'driver1','driver2'}
        
    fitxategia=sprintf('%s1-%s-log.csv',errepidea{1},gidaria{1});
    Fitxategia=dlmread(fitxategia,',');
    
    denbora=bideden(Fitxategia(:,1),Fitxategia(:,2),tarteak);
    estimazioa=SegtoHMS(denbora);
    fprintf('Estimated time for %s in route %s1 is: %s\n',gidaria{1},errepidea{1},estimazioa)
  end
end
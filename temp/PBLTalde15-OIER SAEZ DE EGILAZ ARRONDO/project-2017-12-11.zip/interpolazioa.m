function [abiadura] = interpolazioa(xbektorea,ybektorea,posizioa)
i=1;
    while i<length(xbektorea) && xbektorea(i)<posizioa 
    i=i+1;
    end
    if i==1
    i=i+1;  
    end 
    x0=xbektorea(i-1);
    x1=xbektorea(i);
    y0=ybektorea(i-1);
    y1=ybektorea(i);
    abiadura=((posizioa-x0)/(x1-x0))*(y1-y0)+y0;
end


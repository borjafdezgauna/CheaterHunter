for i={'a','n'}
fitxategia=sprintf('%s1-height.csv',i{1});
Fitxategia=dlmread(fitxategia,',',1,0);

subplot(1,2,1)
hold on
plot(Fitxategia(:,4),Fitxategia(:,3));
title('Altuerak');
xlabel('Distantzia(km)');
ylabel('Altuera(m)');

subplot(1,2,2)
hold on
plot(Fitxategia(:,2),Fitxategia(:,1));
title('Ibilbidea');
xlabel('Longitudea(�)');
ylabel('Latitudea(�)');

batezbestekoaltuera=mean(Fitxategia(:,3));
desbiderazioestandarra=std(Fitxategia(:,3));
altueramax=max(Fitxategia(:,3));
altueramin=min(Fitxategia(:,3));

fprintf('%s1 ibilbidearen estatistikak: \nBatezbesteko altuera: %.2f\t(sd: %.2f)\nAltuera tartea: [%.2f, %.2f]\n\n',i{1},batezbestekoaltuera,desbiderazioestandarra,altueramax, altueramin);  
end
saveas(gcf,'route-elevations','png')


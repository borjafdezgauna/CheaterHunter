function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
for i=1:numSlices
  t= (i-1)*100
  
  
  
  interpolatedY=
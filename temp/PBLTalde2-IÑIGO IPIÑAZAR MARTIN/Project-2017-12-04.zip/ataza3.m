clc
disp('####### MENUA #######')
disp('1-Bideen estatistikak eta grafikoak bistaratu')
disp('2-Gidarien estatistikak eta grafikoak bistaratu')
disp('3-Denboraren kalkuluak gidari bakoitzarentzat')
disp('4-Abiadura mugak ikusi')
disp('5-Erregai gastua bide/gidari bakoitzeko')
disp('6-Irten')
MenuAukera=input('Aukeratu zenbaki bat:');
while MenuAukera<1 || MenuAukera>6
  fprintf('Aukera desegokia: 1 eta 6 arteko balio bat eman\n')
  MenuAukera=input('Aukeratu zenbaki bat:');
end
switch MenuAukera
  case 1
    ataza1
  case 2
    ataza2
  case 3
    
  case 4
    
  case 5
    
  case 6
    exit
    end
input('Sakatu Enter menura itzultzeko');
ataza3
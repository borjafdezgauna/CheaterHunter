irudiZenb = 1;

for num={'a1','n1'}

  subplot(1,2,irudiZenb);

  for gid=1:2
      file=sprintf('%s-driver%d-log.csv',num{1},gid);

        datuak=dlmread(file, ',');
        hold on
      plot(datuak(:,1),datuak(:,2));
        xlabel('Distantzia (km)')
        ylabel('Abiadura (km/h)')
        title(sprintf('%s bideko abiadurak 2 gidarientzat',num{1}))
end 

irudiZenb=2;
end
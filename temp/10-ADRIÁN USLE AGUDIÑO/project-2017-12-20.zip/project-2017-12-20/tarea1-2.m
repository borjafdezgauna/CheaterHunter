%Tarea 1.2
for ruta={'a1','n1'}
    filename = sprintf('%s-height.csv',ruta{1}) ;
    M = dlmread (filename,',',1,0);
    h=M(:,3);
    %Estad�sticas de la ruta :
   
    Alturamedia =mean(h);
    desviacion =std(M(:,3));
    Rangodealturas=[min(M(:,3)),max(M(:,3))];
    
    fprintf('Ruta %s \n',ruta{1});
    fprintf('Altura media %f \n',Alturamedia);
    fprintf('Desviacion %f \n',desviacion);
    fprintf('Rango de alturas %f \n',Rangodealturas);
end
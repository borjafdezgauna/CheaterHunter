%ejercicio5.1
%M es menor o igual que 5 y N en mayor que 25
if (M<= 5 && N> 25)
    disp (`ok�);
else 
    disp (`no�);
end 

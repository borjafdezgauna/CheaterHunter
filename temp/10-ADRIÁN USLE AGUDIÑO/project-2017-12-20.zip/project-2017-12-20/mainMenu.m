clc
eleccion= input('Pulsa una tecla para continuar')
while eleccion ~= 6

  if eleccion<1 || eleccion>6
    disp ('Opci�n incorrecta: debe ser un n�mero entre 1 y 6')
  elseif eleccion ==1
    run ('Tarea1-1.m');
  elseif eleccion ==2
    run ('Tarea2.1.m');
  elseif eleccion == 3
    disp('La tarea que desea aun no se encuentra en el menu')
  elseif eleccion == 4
     disp('La tarea que desea aun no se encuentra en el menu')
   else eleccion==5
      disp('La tarea que desea aun no se encuentra en el menu')
   end
   eleccion= input('Pulsa una tecla para continuar');
end
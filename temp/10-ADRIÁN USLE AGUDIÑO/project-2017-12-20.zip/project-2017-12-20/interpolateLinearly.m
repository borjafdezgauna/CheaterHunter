function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
  if x<min(xVector) || x>max(xVector)
    %no se puede interpolar porque la x se encuentra fuera del vector
    disp ('no se puede interpolar porque la x se encuentra fuera del vector')
    else
    while x>min(xVector) && x<max(xVector)
      if xVector==x1
        interpolatedY==y1
      elseif x>min(xVector) && x<max(xVector)
        x=x2-x1
        interpolatedY= y1+(((x-x1)*(y2-y1))/(x2-x1));
      end
      end
   end
end
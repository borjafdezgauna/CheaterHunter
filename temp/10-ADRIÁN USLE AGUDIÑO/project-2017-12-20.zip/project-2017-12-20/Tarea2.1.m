% TAREA 2

for ruta={'a1','n1'}
   
    filename = sprintf('%s-driver1-log.csv',ruta{1}) ;
    M= dlmread(filename,',',0,0);
     
      a1distancia=M(:,1);
      a1velocidad=M(:,2);
   
  hold on
   
   filename = sprintf('%s-driver2-log.csv',ruta{1}) ;
    N = dlmread(filename,',',0,0);
     
      n1distancia=N(:,1);
      n1velocidad=N(:,2);
      
      
      subplot(1,2,1);
      
    hold on

    p1 = plot(a1distancia,a1velocidad,n1distancia,n1velocidad);

    ylabel('velocidad');
    xlabel('distancia');
    title('conductor 1 velocidad/distancia')

    subplot(1,2,2)
    
    hold on
    
    p2 = plot(n1distancia,n1velocidad,a1distancia,a1velocidad);
    
    ylabel('velocidad');
    xlabel('distancia');
    title('Conductor 2 velocidad/distancia')
end
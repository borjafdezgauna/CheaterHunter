eleccion=menu('MEN�','1. Muestra las gr�ficas y estad�sticas de las rutas','2. Muestra las gr�ficas y estad�sticas de los conductores','3. C�lculos de tiempo para cada conductor y ruta','4. Comprobar los l�mites de velocidad','5. C�lculo de consumo de combustible para cada conductor y ruta','6. Salir')

switch eleccion 
    case '1. Muestra las gr�ficas y estad�sticas de las rutas'
       
    case '2. Muestra las gr�ficas y estad�sticas de los conductores'
        
    case '3. C�lculos de tiempo para cada conductor y ruta'
        
    case '4. Comprobar los l�mites de velocidad'
        
    case '5. C�lculo de consumo de combustible para cada conductor y ruta'
       
    case '6. Salir'
      
end
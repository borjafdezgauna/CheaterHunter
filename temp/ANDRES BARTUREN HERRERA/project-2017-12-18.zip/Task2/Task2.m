a1= dlmread('files/a1-height.csv',',',1,0);
n1= dlmread('files/n1-height.csv',',',1,0);
driver11= dlmread('files/n1-driver1-log.csv',',',1,0);
driver12= dlmread('files/a1-driver1-log.csv',',',1,0);
driver21= dlmread('files/n1-driver2-log.csv',',',1,0);
driver22= dlmread('files/a1-driver2-log.csv',',',1,0);

a11= driver12(:,1);
n11= driver12(:,1);
a21= driver22(:,1);
n21= driver21(:,1);
a12= a1(:,2);
n12= n1(:,2);


msn1= (sum(n11')/length(n11'));
sdn1= std(n11);
minsn11= min(n11);
maxsn21= max(n11);

msn2= (sum(n11')/length(n11'));
sdn2= std(n11);
minsn12= min(n11);
minsn22= max(n11);

msa1= (sum(a11')/length(a11'));
sda1= std(a11);
minsa11= min(a11);
maxsa21= max(a11);

msa2= (sum(a11')/length(a11'));
sda2= std(a11);
minsa12= min(a11);
maxsa22= max(a11);

figure
subplot(1,2,1)       
plot(a12,a11,a12,a21)
title('A1')
xlabel('Distance from origin (km)')
ylabel('Speed of the driver (km/h)')

subplot(1,2,2)       
plot(n12,n11,n12,n21)       
title('N1')
xlabel('Distance from origin (km)')
ylabel('Speed of the driver (km/h)')

saveas(figure,'route-elevations.png')

fprintf('driver1 statistics in route n1: \n Mean speed: %d (sd: %d) \n Min-Max speed: [%d, %d] \n',msn1,sdn1,minsn11,maxsn21)
fprintf('driver2 statistics in route n1: \n Mean speed: %d (sd: %d) \n Min-Max speed: [%d, %d] \n',msn2,sdn2,minsn12,maxsn22)
fprintf('driver1 statistics in route a1: \n Mean speed: %d (sd: %d) \n Min-Max speed: [%d, %d] \n',msa1,sda1,minsa11,maxsa21)
fprintf('driver2 statistics in route a1: \n Mean speed: %d (sd: %d) \n Min-Max speed: [%d, %d] \n',msa2,sda2,minsa12,maxsa22)
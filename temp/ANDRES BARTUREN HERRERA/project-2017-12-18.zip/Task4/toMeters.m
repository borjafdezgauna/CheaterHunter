function [m] = toMeters(kms)
  m= (1000.*kms);
  end
%tarea 4
%km a m
function [ m ] = toMeters( km )
m = km * 1000 ;
end 

clc
clear
clear all

%%% VALORES ESTADÍSTICOS 

% std = standard deviation ---> desviacion estandar
% mean---> media
% Columna 1 ---> Distancia desde el origen (km) 
% Columna 2 ---> Velocidad (km/h)


%% RUTA N1
 
% Datos y salida del conductor 1 en la ruta N1:
datos_n1_driver1 = dlmread('n1-driver1-log.csv', ',');
velocidad_n1_driver1 = datos_n1_driver1(:, 2);
media_velocidad_n1_driver1 = mean(velocidad_n1_driver1);
desviacion_estandar_velocidad_n1_driver1 = std(velocidad_n1_driver1);
mini_velocidad_n1_driver1 = min(velocidad_n1_driver1);
maxi_velocidad_n1_driver1 = max(velocidad_n1_driver1);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_n1_driver1);
fprintf('  (sd: %f)\n', desviacion_estandar_velocidad_n1_driver1);
fprintf('Rango de velocidades: [%f,', mini_velocidad_n1_driver1);
fprintf(' %f]\n\n\n', maxi_velocidad_n1_driver1);

                %Estadísticas del conductor1 en la ruta n1:
                %Velocidad media: 95.99 (sd: 10.14)
                %Rango de velocidades: [0.00, 118.44]
                

% Datos y salida del conductor 2 en la ruta N1:
datos_n1_driver2 = dlmread('n1-driver2-log.csv', ',');
velocidad_n1_driver2 = datos_n1_driver2(:, 2);
media_velocidad_n1_driver2 = mean(velocidad_n1_driver2);
desviacion_estandar_velocidad_n1_driver2 = std(velocidad_n1_driver2);
mini_velocidad_n1_driver2 = min(velocidad_n1_driver2);
maxi_velocidad_n1_driver2 = max(velocidad_n1_driver2);

disp('Estadísticas del conductor 2 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_n1_driver2); 
fprintf('  (sd: %f)\n', desviacion_estandar_velocidad_n1_driver2);
fprintf('Rango de velocidades: [%f,', mini_velocidad_n1_driver2);
fprintf(' %f]\n\n\n', maxi_velocidad_n1_driver2);

                %Estadísticas del conductor2 en la ruta n1:
                %Velocidad media: 114.10 (sd: 10.78)
                %Rango de velocidades: [0.00, 121.43]

%% RUTA A1

% Datos y salida del conductor 1 en la ruta A1:
datos_a1_driver1 = dlmread('a1-driver1-log.csv', ',');
velocidad_a1_driver1 = datos_a1_driver1(:, 2);
media_velocidad_a1_driver1 = mean(velocidad_a1_driver1);
desviacion_estandar_velocidad_a1_driver1 = std(velocidad_a1_driver1);
mini_velocidad_a1_driver1 = min(velocidad_a1_driver1);
maxi_velocidad_a1_driver1 = max(velocidad_a1_driver1);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_a1_driver1); 
fprintf('  (std.dev: %f)\n', desviacion_estandar_velocidad_a1_driver1);
fprintf('Rango de velocidades: [%f,', mini_velocidad_a1_driver1);
fprintf(' %f]\n\n\n', maxi_velocidad_a1_driver1);

                %Estadísticas del conductor1 en la ruta a1:
                %Velocidad media: 101.29 (std.dev: 14.82)
                %Rango de velocidades: [0.00, 119.00]
                
                % Datos y salida del conductor 2 en la ruta A1:
datos_a1_driver2 = dlmread('a1-driver2-log.csv', ',');
velocidad_a1_driver2 = datos_a1_driver2(:, 2);
media_velocidad_a1_driver2 = mean(velocidad_a1_driver2);
desviacion_estandar_velocidad_a1_driver2 = std(velocidad_a1_driver2);
mini_velocidad_a1_driver2 = min(velocidad_a1_driver2);
maxi_velocidad_a1_driver2 = max(velocidad_a1_driver2);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_a1_driver2); 
fprintf('  (std.dev: %f)\n', desviacion_estandar_velocidad_a1_driver2);
fprintf('Rango de velocidades: [%f,', mini_velocidad_a1_driver2);
fprintf(' %f]\n\n\n', maxi_velocidad_a1_driver2);

                %Estadísticas del conductor2 en la ruta a1:
                %Velocidad media: 104,79 (std.dev: 15.62)
                %Rango de velocidades: [0.00, 122.17]

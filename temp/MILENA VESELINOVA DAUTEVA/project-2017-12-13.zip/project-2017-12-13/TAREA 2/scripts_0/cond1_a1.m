clc
clear
clear all

% Datos y salida del conductor 1 en la ruta A1:
datos_a1_driver1 = dlmread('a1-driver1-log.csv', ',');
velocidad_a1_driver1 = datos_a1_driver1(:, 2);
media_velocidad_a1_driver1 = mean(velocidad_a1_driver1);
desviacion_estandar_velocidad_a1_driver1 = std(velocidad_a1_driver1);
mini_velocidad_a1_driver1 = min(velocidad_a1_driver1);
maxi_velocidad_a1_driver1 = max(velocidad_a1_driver1);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_a1_driver1); 
fprintf('  (std.dev: %f)\n', desviacion_estandar_velocidad_a1_driver1);
fprintf('Rango de velocidades: [%f,', mini_velocidad_a1_driver1);
fprintf(' %f]\n\n\n', maxi_velocidad_a1_driver1);

                %Estadísticas del conductor1 en la ruta a1:
                %Velocidad media: 101.29 (std.dev: 14.82)
                %Rango de velocidades: [0.00, 119.00]
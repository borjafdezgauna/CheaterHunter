clc
clear
clear all

% Datos y salida del conductor 1 en la ruta N1:
datos_n1_driver1 = dlmread('n1-driver1-log.csv', ',');
velocidad_n1_driver1 = datos_n1_driver1(:, 2);
media_velocidad_n1_driver1 = mean(velocidad_n1_driver1);
desviacion_estandar_velocidad_n1_driver1 = std(velocidad_n1_driver1);
mini_velocidad_n1_driver1 = min(velocidad_n1_driver1);
maxi_velocidad_n1_driver1 = max(velocidad_n1_driver1);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_n1_driver1);
fprintf('  (sd: %f)\n', desviacion_estandar_velocidad_n1_driver1);
fprintf('Rango de velocidades: [%f,', mini_velocidad_n1_driver1);
fprintf(' %f]\n\n\n', maxi_velocidad_n1_driver1);

                %Estadísticas del conductor1 en la ruta n1:
                %Velocidad media: 95.99 (sd: 10.14)
                %Rango de velocidades: [0.00, 118.44]
                
clc 
clear
clear all

% Datos del conductor 1 en la ruta N1:
datos_n1_driver1 = dlmread('n1-driver1-log.csv');
velocidad=datos_n1_driver1(:,2);
distancia_origen_n1_driver1 = datos_n1_driver1(:,1);

subplot(2,2,1);
plot(distancia_origen_n1_driver1, velocidad)
xlabel('distancia desde el origen (km)');
ylabel('velocidad (km/h)');
title('RUTA N1: CONDUCTOR 1');


% Datos del conductor 2 en la ruta N1:
datos_n1_driver2 = dlmread('n1-driver2-log.csv');
velocidad=datos_n1_driver2(:,2);
distancia_origen_n1_driver2 = datos_n1_driver2(:,1);

subplot(2,2,2);
plot(distancia_origen_n1_driver2, velocidad)
xlabel('distancia desde el origen (km)');
ylabel('velocidad (km/h)');
title('RUTA N1: CONDUCTOR 2');


% Datos del conductor 1 en la ruta A1:
datos_a1_driver1 = dlmread('a1-driver1-log.csv');
velocidad = datos_a1_driver1(:,2);
distancia_origen_a1_driver1 = datos_a1_driver1(:,1);

subplot(2,2,3);
plot(distancia_origen_a1_driver1, velocidad);
xlabel('distancia desde el origen (km)');
ylabel('velocidad (km/h)');
title('RUTA A1: CONDUCTOR 1');


% Datos del conductor 2 en la ruta A1:
datos_a1_driver2=dlmread('a1-driver2-log.csv');
velocidad=datos_a1_driver2(:,2);
distancia_origen_a1_driver2=datos_a1_driver2(:,1);
subplot(2,2,4);
plot(distancia_origen_a1_driver2, velocidad);
xlabel('distancia desde el origen (km)');
ylabel('velocidad (km/h)');
title('RUTA A1: CONDUCTOR 2');


% Guardar la gráfica como un archivo de imagen - (gcf, 'nombre del archivo.formato').
% Se guarda en la carpeta en la que estamos trabajando.
saveas(gcf, 'route-elevations.png') 



%%% VALORES ESTADÍSTICOS 

% std = standard deviation ---> desviacion estandar
% mean---> media
% Columna 1 ---> Distancia desde el origen (km) 
% Columna 2 ---> Velocidad (km/h)


%% RUTA N1
 
% Datos y salida del conductor 1 en la ruta N1:
datos_n1_driver1 = dlmread('n1-driver1-log.csv', ',');
velocidad_n1_driver1 = datos_n1_driver1(:, 2);
media_velocidad_n1_driver1 = mean(velocidad_n1_driver1);
desviacion_estandar_velocidad_n1_driver1 = std(velocidad_n1_driver1);
mini_velocidad_n1_driver1 = min(velocidad_n1_driver1);
maxi_velocidad_n1_driver1 = max(velocidad_n1_driver1);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %.2f', media_velocidad_n1_driver1);
fprintf('  (sd: %.2f)\n', desviacion_estandar_velocidad_n1_driver1);
fprintf('Rango de velocidades: [%.2f,', mini_velocidad_n1_driver1);
fprintf(' %.2f]\n\n\n', maxi_velocidad_n1_driver1);

                %Estadísticas del conductor1 en la ruta n1:
                %Velocidad media: 95.99 (sd: 10.14)
                %Rango de velocidades: [0.00, 118.44]
                

% Datos y salida del conductor 2 en la ruta N1:
datos_n1_driver2 = dlmread('n1-driver2-log.csv', ',');
velocidad_n1_driver2 = datos_n1_driver2(:, 2);
media_velocidad_n1_driver2 = mean(velocidad_n1_driver2);
desviacion_estandar_velocidad_n1_driver2 = std(velocidad_n1_driver2);
mini_velocidad_n1_driver2 = min(velocidad_n1_driver2);
maxi_velocidad_n1_driver2 = max(velocidad_n1_driver2);

disp('Estadísticas del conductor 2 en la ruta N1: ');
fprintf('Velocidad media: %.2f', media_velocidad_n1_driver2); 
fprintf('  (sd: %.2f)\n', desviacion_estandar_velocidad_n1_driver2);
fprintf('Rango de velocidades: [%.2f,', mini_velocidad_n1_driver2);
fprintf(' %.2f]\n\n\n', maxi_velocidad_n1_driver2);

                %Estadísticas del conductor2 en la ruta n1:
                %Velocidad media: 114.10 (sd: 10.78)
                %Rango de velocidades: [0.00, 121.43]

                
%% RUTA A1

% Datos y salida del conductor 1 en la ruta A1:
datos_a1_driver1 = dlmread('a1-driver1-log.csv', ',');
velocidad_a1_driver1 = datos_a1_driver1(:, 2);
media_velocidad_a1_driver1 = mean(velocidad_a1_driver1);
desviacion_estandar_velocidad_a1_driver1 = std(velocidad_a1_driver1);
mini_velocidad_a1_driver1 = min(velocidad_a1_driver1);
maxi_velocidad_a1_driver1 = max(velocidad_a1_driver1);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %.2f', media_velocidad_a1_driver1); 
fprintf('  (std.dev: %.2f)\n', desviacion_estandar_velocidad_a1_driver1);
fprintf('Rango de velocidades: [%.2f,', mini_velocidad_a1_driver1);
fprintf(' %.2f]\n\n\n', maxi_velocidad_a1_driver1);

                %Estadísticas del conductor1 en la ruta a1:
                %Velocidad media: 101.29 (std.dev: 14.82)
                %Rango de velocidades: [0.00, 119.00]
                
                
                
% Datos y salida del conductor 2 en la ruta A1:
datos_a1_driver2 = dlmread('a1-driver2-log.csv', ',');
velocidad_a1_driver2 = datos_a1_driver2(:, 2);
media_velocidad_a1_driver2 = mean(velocidad_a1_driver2);
desviacion_estandar_velocidad_a1_driver2 = std(velocidad_a1_driver2);
mini_velocidad_a1_driver2 = min(velocidad_a1_driver2);
maxi_velocidad_a1_driver2 = max(velocidad_a1_driver2);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %.2f', media_velocidad_a1_driver2); 
fprintf('  (std.dev: %.2f)\n', desviacion_estandar_velocidad_a1_driver2);
fprintf('Rango de velocidades: [%.2f,', mini_velocidad_a1_driver2);
fprintf(' %.2f]\n\n\n', maxi_velocidad_a1_driver2);

                %Estadísticas del conductor2 en la ruta a1:
                %Velocidad media: 104,79 (std.dev: 15.62)
                %Rango de velocidades: [0.00, 122.17]


clc
clear
clear all
eleccion=0;
while eleccion ~=6
    eleccion=menu('MENÚ','1. Muestra las gráficas y estadísticas de las rutas','2. Muestra las gráficas y estadísticas de los conductores','3. Cálculos de tiempo para cada conductor y ruta','4. Comprobar los límites de velocidad','5. Cálculo de consumo de combustible para cada conductor y ruta','6. Salir')
    switch eleccion
        case 1
            disp('1. Muestra las gráficas y estadísticas de las rutas')
            
            % Especificar que es el archivo 'route-elevations' de la primera tarea,
            % ya que tanto la pimera como la segunda comparten el mismo nombre.
            % solucionado: opcion 1 ---> ...-1.m; opcion 2 ---> ...-2.m
            ej1
            
            
            
        case 2
            disp('2. Muestra las gráficas y estadísticas de los conductores')
        case 3
            disp('3. Cálculos de tiempo para cada conductor y ruta')
        case 4
            disp('4. Comprobar los límites de velocidad')
        case 5
            disp('5. Cálculo de consumo de combustible para cada conductor y ruta')
        case 6
            disp('6. Salir')
            
    end
end

disp('Hola')
t=input('teclea algo');
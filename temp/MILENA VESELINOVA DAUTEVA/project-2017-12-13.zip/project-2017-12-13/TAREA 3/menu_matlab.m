clc
clear
clear all

%%% TAREA 3

disp('#######   MENÚ   #######: ');
sprintf('1. Muestra las gráficas y estadísticas de las rutas')
sprintf('2. Muestra las gráficas y estadísticas de los conductores %s')
sprintf('3. Cálculos de tiempo para cada conductor y ruta')
sprintf('4. Comprobar los límites de velocidad')
sprintf('5. Cálculo de consumo de combustible para cada conductor y ruta')
sprintf('6. Salir')



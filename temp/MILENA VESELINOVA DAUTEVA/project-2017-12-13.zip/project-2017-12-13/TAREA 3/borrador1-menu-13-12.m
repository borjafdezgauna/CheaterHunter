clc
clear
clear all

eleccion=menu('MENÚ','1. Muestra las gráficas y estadísticas de las rutas','2. Muestra las gráficas y estadísticas de los conductores','3. Cálculos de tiempo para cada conductor y ruta','4. Comprobar los límites de velocidad','5. Cálculo de consumo de combustible para cada conductor y ruta','6. Salir')
switch eleccion 
    case 1 
        open('route-elevations-1.m')
       
       
        % Especificar que es el archivo 'route-elevations' de la primera tarea,
        % ya que tanto la pimera como la segunda comparten el mismo nombre.
        % solucionado: opcion 1 ---> ...-1.m; opcion 2 ---> ...-2.m
       
    case 2 
        disp('2. Muestra las gráficas y estadísticas de los conductores')
    case 3
        disp('3. Cálculos de tiempo para cada conductor y ruta')
    case 4
        disp('4. Comprobar los límites de velocidad')
    case 5
        disp('5. Cálculo de consumo de combustible para cada conductor y ruta')
    case 6
        disp('6. Salir')
        
end


function choice=displayMenu(options)
for i=1:length(options)
frpintf('%d. %s\n', i, options{i});
end

choice=0;
while ~any(choice == 1:length(option))
choice = inputNumber('please choose a menu option')
end


function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)

IX = xVector(1,2) - xVector(1,1);

IY = yVector(1,2) - yVector(1,1);

P = IX/IY ;

posicion = x - xVector(1,1);

interpolatedY = yVector + posicion * P;
end 
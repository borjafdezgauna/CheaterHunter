clc
clear
clear all

% Datos y salida del conductor 2 en la ruta A1:
datos_a1_driver2 = dlmread('a1-driver2-log.csv', ',');
velocidad_a1_driver2 = datos_a1_driver2(:, 2);
media_velocidad_a1_driver2 = mean(velocidad_a1_driver2);
desviacion_estandar_velocidad_a1_driver2 = std(velocidad_a1_driver2);
mini_velocidad_a1_driver2 = min(velocidad_a1_driver2);
maxi_velocidad_a1_driver2 = max(velocidad_a1_driver2);

disp('Estadísticas del conductor 1 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_a1_driver2); 
fprintf('  (std.dev: %f)\n', desviacion_estandar_velocidad_a1_driver2);
fprintf('Rango de velocidades: [%f,', mini_velocidad_a1_driver2);
fprintf(' %f]\n\n\n', maxi_velocidad_a1_driver2);

                %Estadísticas del conductor2 en la ruta a1:
                %Velocidad media: 104,79 (std.dev: 15.62)
                %Rango de velocidades: [0.00, 122.17]

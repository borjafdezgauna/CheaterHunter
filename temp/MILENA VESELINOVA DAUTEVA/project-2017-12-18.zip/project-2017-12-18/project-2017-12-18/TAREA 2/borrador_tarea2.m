fichero=dlmread('n1-driver2-log.csv');
velocidad_n1_2=fichero(:,2);
media_v=mean(velocidad_n1_2)
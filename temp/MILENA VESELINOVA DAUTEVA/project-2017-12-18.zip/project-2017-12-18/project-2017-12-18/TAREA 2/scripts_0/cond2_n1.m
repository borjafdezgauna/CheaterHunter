clc
clear
clear all

% Datos y salida del conductor 2 en la ruta N1:
datos_n1_driver2 = dlmread('n1-driver2-log.csv', ',');
velocidad_n1_driver2 = datos_n1_driver2(:, 2);
media_velocidad_n1_driver2 = mean(velocidad_n1_driver2);
desviacion_estandar_velocidad_n1_driver2 = std(velocidad_n1_driver2);
mini_velocidad_n1_driver2 = min(velocidad_n1_driver2);
maxi_velocidad_n1_driver2 = max(velocidad_n1_driver2);

disp('Estadísticas del conductor 2 en la ruta N1: ');
fprintf('Velocidad media: %f', media_velocidad_n1_driver2); 
fprintf('  (sd: %f)\n', desviacion_estandar_velocidad_n1_driver2);
fprintf('Rango de velocidades: [%f,', mini_velocidad_n1_driver2);
fprintf(' %f]\n\n\n', maxi_velocidad_n1_driver2);

                %Estadísticas del conductor2 en la ruta n1:
                %Velocidad media: 114.10 (sd: 10.78)
                %Rango de velocidades: [0.00, 121.43]

                
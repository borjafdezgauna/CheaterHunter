function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
m = toMeters(kms)
speedMS = toMetersPerSecond( speedKmH )
interpolarty
slice = m(length(m)-m(1)/numSlices
estimatedTime = 0 
for j = 
estimatedTime =   /slice
end 


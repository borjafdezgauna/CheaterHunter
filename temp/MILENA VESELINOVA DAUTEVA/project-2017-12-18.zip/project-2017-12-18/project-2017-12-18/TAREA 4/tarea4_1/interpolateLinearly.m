
function [interpolatedY] = interpolateLinearly(xVector, yVector, x)


i = 1
while x > xVector (i) && i < length(xVector)
     
    i = i+1
    
end
if i==1
interpolatedY = yVector(i)
else
%+(yVector(i+1)-yVector(i))/(xVector(i+1)-xVector(i)))*(x-xVector(i))
interpolatedY = yVector(i-1)+((yVector(i)-yVector(i-1))/(xVector(i)-xVector(i-1)))*(x-xVector(i-1))
end
end
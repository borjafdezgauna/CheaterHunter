xVector=[10 20 40];
yVector=[120 150 130];
xx=[10 15 25 40];
yy=interp1(xVector,yVector,x,'linear');
disp([xx' yy'])
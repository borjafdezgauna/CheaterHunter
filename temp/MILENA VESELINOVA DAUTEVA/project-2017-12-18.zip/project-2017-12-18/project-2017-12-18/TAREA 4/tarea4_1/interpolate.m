function [interpolatedY] = interpolateLinearly(xVector, yVector, x);

interpolatedY = yVector(1) + (diff(yVector)/(diff(xVector)) * (x(1) - xVector(1))
%nterpolatedY = 120 + (diff(yVector)/(diff(xVector)) * (10 - 10);
end function
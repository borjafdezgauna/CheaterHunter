%y = 120 + (150-120)/(20-12) * (10-12)

%y = interpolate(12, 120, 20, 150, 10)

xVector=[10 20 40];
yVector=[120 150 130];
x=[10 15 25 40];

interpolatedY = 120 + (diff(yVector)/(diff(xVector)) * (10 - 10);
% 3. Escribe una función que, dada una velocidades en km/h, devuelva la
% velocidad equivalente en m/s:
% function [ msSpeed ] = toMetersPerSecond( speedKmH )

function [ msSpeed ] = toMetersPerSecond( speedKmH )

msSpeed = speedKmH * 1000 / 3600;

end
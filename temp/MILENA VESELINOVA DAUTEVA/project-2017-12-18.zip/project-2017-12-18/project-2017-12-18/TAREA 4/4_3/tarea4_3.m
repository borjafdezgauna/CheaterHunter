clc
clear
clear all

% Comprueba que la función es correcta con los siguientes valores:
% toMetersPerSecond(120) => 33.3333
% toMetersPerSecond(15) => 4.1667

toMetersPerSecond(120)

toMetersPerSecond(15) 


clc
clear
clear all

% Si tomamos los ficheros de registros por condutor y ruta, kms tendría los
% valores de la primera columna del fichero, y speedKmH sería la segunda
% columna.

% Esta función interpola linealmente las velocidades del vector de
% velocidades para el número de intervalos de integración(numSlices)
% determinado. Para cada intervalo interpolaremos el valor de la velocidad
% usando la función que hicimos en la subtarea anterior {function [ msSpeed ] = toMetersPerSecond( speedKmH )},
% y estimaremos el tiempo necesario para cubrir la distancia que comprende cada intervalo.
% El resultado será la suma total de tiempos estimados para la ruta.

% Comprueba que la función es correcta con los siguientes valores:
% estimateTime([0 1 2 3],[40 50 40 30],1000) => 264.2797
% estimateTime([0 1 2 3],[40 50 40 20],1000) => 285.5495

%            DIAGRAMA:

%                  ^           ^         ^           ^
%                 kms      speedKmH   numSlices   estimatedTime = RESULTADO
%                              ^         ^
%                  ^           |         |
%                  |           |   numSlices = 1000
%            kms = [0 1 2 3]   |
%                              |
%                          speedKmH ---> VARIABLE

estimateTime(kms, speedKmH, numSlices)

kms = [0 1 2 3];
numSlices = 1000;
if numSlices = 1000
for speedKmH = 40
estimateTime = interp1(kms, speedKmH, numSlices);
end

if numSlices = 1000
for speedKmH = 50
estimateTime = interp1(kms, speedKmH, numSlices);
end

if numSlices = 1000
for speedKmH = 40
estimateTime = interp1(kms, speedKmH, numSlices);
end

if numSlices = 1000
for speedKmH = 30
estimateTime = interp1(kms, speedKmH, numSlices);
end 

end 
end
end
end













% 4. Escribe una función que estime el tiempo en el que se realiza la ruta:
% function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)

%This function is given a vector with a vehicle’s speed (speedKmH) at
%different points (kms) and the number of integration slices we want to
%use (numSlices)
% Esta función recibe un vector con la velocidad del vehículo (speedKmH)
% en diferentes puntos (kms) y el
% número de pasos de integración (numSlices)

function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)

estimatedTime = interp1(kms, speedKmH, numSlices);

end


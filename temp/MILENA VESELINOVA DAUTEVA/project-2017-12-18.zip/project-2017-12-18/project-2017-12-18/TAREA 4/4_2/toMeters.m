% 2. Escribe una función que, dada una cantidad de kilómetros, devuelva el
% número equivalente de metros:

% function [ m ] = toMeters( km )

function [ m ] = toMeters( km )

m = km * 1000 ;

end 


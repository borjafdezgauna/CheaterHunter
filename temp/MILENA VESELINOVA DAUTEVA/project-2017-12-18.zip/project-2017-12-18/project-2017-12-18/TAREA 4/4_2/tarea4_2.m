clc
clear
clear all

% Comprueba que la función es correcta con los siguientes valores:
% toMeters(2.3) => 2300
% toMeters(0.3) => 300

toMeters(2.3) 

toMeters(0.3)
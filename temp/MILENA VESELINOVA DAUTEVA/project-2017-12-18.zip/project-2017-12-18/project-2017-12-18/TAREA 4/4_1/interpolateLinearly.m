% 1. Escribe una función que interpole linealmente a partir de un conjunto de
% valores x-y:
% function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)

function [ interpolatedY ] = interpolateLinearly( xVector, yVector , x)
% This function gets a vector with x-values and a vector with y-values
% and returns the interpolated value of y for the given x.
% Esta función recibe un vector con los valores de x, otro
% con los valores de y, y devuelve el valor interpolado de y para un x
%dado.

%interp1 ---> funcion que interpola linealmente
interpolatedY = interp1(xVector, yVector, x);

% Vectores dados por la tarea:
%xVector = [10 20 40]
%yVector = [120 150 130]

end




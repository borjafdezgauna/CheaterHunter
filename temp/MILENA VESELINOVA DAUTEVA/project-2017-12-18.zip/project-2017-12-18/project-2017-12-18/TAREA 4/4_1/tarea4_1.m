clc
clear
clear all

%Comprueba que la función es correcta con los siguientes valores:
%interpolateLinearly([10 20 40],[120 150 130],10) => 120
%interpolateLinearly([10 20 40],[120 150 130],15) => 135
%interpolateLinearly([10 20 40],[120 150 130],25) => 145
%interpolateLinearly([10 20 40],[120 150 130],40) => 130

% Vectores dados por la tarea:
xVector = [10 20 40];
yVector = [120 150 130];


% Interpolacion para cada variable(x):
for x = 10
interpolateLinearly = interp1(xVector, yVector, x)

for x = 15
interpolateLinearly = interp1(xVector, yVector, x)

for x=25
interpolateLinearly = interp1(xVector, yVector, x)

for x=40
interpolateLinearly = interp1(xVector, yVector, x)

end
end
end
end


clc
clear
clear all
% Control de errores
eleccion=0;
while eleccion ~=6
    eleccion=menu('MENÚ','1. Muestra las gráficas y estadísticas de las rutas','2. Muestra las gráficas y estadísticas de los conductores','3. Cálculos de tiempo para cada conductor y ruta','4. Comprobar los límites de velocidad','5. Cálculo de consumo de combustible para cada conductor y ruta','6. Salir')
    switch eleccion
        case 1
        %eleccion1=route-elevations-1
        run ('route-elevations-1.m')
        %load('route-elevations-1.m')
            %disp('1. Muestra las gráficas y estadísticas de las rutas')
            
            % Especificar que es el archivo 'route-elevations' de la primera tarea,
            % ya que tanto la pimera como la segunda comparten el mismo nombre.
            % solucionado: opcion 1 ---> ...-1.m; opcion 2 ---> ...-2.m    
            
        case 2
        run('route-elevations-2.m')
            %disp('2. Muestra las gráficas y estadísticas de los conductores')
            
        case 3
            %disp('3. Cálculos de tiempo para cada conductor y ruta')
            %Tarea 4, 5 ó 6
            
            %Estimated time for driver1 in route n1: 1:58:54
            %Estimated time for driver2 in route n1: 1:56:13
            %Estimated time for driver1 in route a1: 1:54:09
            %Estimated time for driver2 in route a1: 1:51:12
            
            
            
            
            
            
        case 4
            %disp('4. Comprobar los límites de velocidad')
            %Tarea 4, 5 ó 6
            
        case 5
            %disp('5. Cálculo de consumo de combustible para cada conductor y ruta')
            %Tarea 4, 5 ó 6
            
        case 6
            %disp('6. Salir')
            %Tarea 4, 5 ó 6
            
            
            otherwise 
            quit
            %end
    end
end

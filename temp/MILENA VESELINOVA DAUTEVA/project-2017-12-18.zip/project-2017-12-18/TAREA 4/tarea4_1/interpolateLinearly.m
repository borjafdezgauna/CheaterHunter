%%%%%%
function [interpolatedY] = interpolateLinearly(xVector, yVector, x);
if x < xVector(lenght(xVector) && x > xVector(1) 
       while ~(x>xVector (i) && x<xVector(i+1)
       interpolatedY = yVector(i)+[yVector(i+1)-yVector(i)]/[xVector(i+1)-xVector(i)]*(x-xVector(i))
       end 
elseif
sprintf(" el valor no esta dentro del vector de distancias")
     end

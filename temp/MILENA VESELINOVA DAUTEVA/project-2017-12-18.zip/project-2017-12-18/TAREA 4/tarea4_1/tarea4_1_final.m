%%%%%%
function [interpolatedY] = interpolateLinearly(xVector, yVector, x);
for i=1:length(xVector)
while ~(x>xVector (i) && x<xVector(i+1)
y=yVector(i)+[yVector(i+1)-yVector(i)]/[xVector(i+1)-xVector(i)]*(x-xVector(i)
end
end
end

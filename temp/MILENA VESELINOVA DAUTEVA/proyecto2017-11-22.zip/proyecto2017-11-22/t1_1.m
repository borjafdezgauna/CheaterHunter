n2 = dlmread('n1-height.csv', ',', 1 , 0)
h1 = n2(:,3) 
subplot(1,2,1)
plot(h1)
xlabel('distancia(km)')
ylabel('altura(m)')

 

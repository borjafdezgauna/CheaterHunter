datos2=dlmread('n1-driver1-log.csv')
velocidad=datos2(:,2)
distancia_origen=datos2(:,1)
subplot(2,2,2)
plot(distancia_origen, velocidad)
xlabel('distancia desde el origen (km)')
ylabel('velocidad (km/h)')
title('RUTA N1: CONDUCTOR 1')





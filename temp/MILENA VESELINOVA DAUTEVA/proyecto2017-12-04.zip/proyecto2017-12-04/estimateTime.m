function [ estimatedTime ] = estimateTime( kms, speedKmH, numSlices)
% 
% incremetoKm = km2 - km1
% incrementoV = v2 - v1 
kms=

end
h1=dlmread('a1-height.csv', ',', [1 2 0 2])
h2=dlmread('n1-height.csv', ',', [1 2 0 2])

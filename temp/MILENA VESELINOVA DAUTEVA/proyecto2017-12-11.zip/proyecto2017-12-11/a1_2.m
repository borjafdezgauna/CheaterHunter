datos3=dlmread('a1-driver2-log.csv')
velocidad=datos3(:,2)
distancia_origen=datos3(:,1)
subplot(2,2,3)
plot(distancia_origen, velocidad)
xlabel('distancia desde el origen (km)')
ylabel('velocidad (km/h)')
title('RUTA A1: CONDUCTOR 2')


clc
clear
clear all

%% PERFILES DE ELEVACION DE LAS RUTAS
% ELEVACIÓN DE LA RUTA A1 %

%lectura de datos de archivos .csv ---> dlmread; empezando por la fila nº2.
datos_a1 = dlmread('a1-height.csv', ',', 1, 0);

%Para seleccionar una columna entera ---> (:, Nº COLUMNA)
%Columna 1 ---> Latitud
%Columna 2 ---> Longitud
%Columna 3 ---> Altura (m)
%Columna 4 ---> Distancia (km)


%Distancia-Altura A1
altura = datos_a1(:,3);
distancia = datos_a1(:,4);

%subplot(2,2,*posición de la grafica; 1 (2º cuadrante), 2 (1er cuadrante), 3 (3er cuadrante), 4 (4ª cuadrante) *)
subplot(2,2,1)
plot(distancia, altura)
xlabel('distancia(km)')
ylabel('altura(m)')
title('Ruta A1')

%Latitud-Longitud A1
longitud = datos_a1(:,2);
latitud = datos_a1(:,1);
subplot(2,2,2)
plot(latitud,longitud)
xlabel('longitud')
ylabel('latitud')
title('Ruta A1')



%ELEVACIÓN DE LA RUTA N1

datos_n1 = dlmread('n1-height.csv', ',', 1, 0);

%Distancia-Altura N1
altura=datos_n1(:,3);
distancia = datos_n1(:,4);
subplot(2,2,3)
plot(distancia,altura)
xlabel('distancia(km)')
ylabel('altura(m)')
title('Ruta N1')

%Longitud-Latitud N1
longitud = datos_n1(:,2);
latitud = datos_n1(:,1);
subplot(2,2,4)
plot(latitud,longitud)
xlabel('longitud')
ylabel('latitud')
title('Ruta N1')

%Guardar la gráfica como un archivo de imagen - (gcf, 'nombre del archivo.formato').
%Se guarda en la carpeta en la que estamos trabajando.
saveas(gcf, 'route-elevations.png') 




%% VALORES ESTADÍSTICOS 

% std = standard deviation ---> desviacion estandar
% mean---> media 

%   N1   %     
  
datos_n1 = dlmread('n1-height.csv', ',', 1, 0);
altura_n1 = datos_n1(:, 3);
e = mean(altura_n1);
f = std(altura_n1);
g = min(altura_n1);
h = max(altura_n1);

%SALIDA DE DATOS DE LA RUTA N1:
disp('Estadísticas de la ruta N1: ');
fprintf('Altura media: %f', e); 
fprintf('  (sd: %f)\n', f);
fprintf('Rango de alturas: [%f,', g);
fprintf(' %f]\n\n\n', h);


%   A1   %
                 
datos_a1 = dlmread('a1-height.csv', ',', 1, 0);
altura_a1 = datos_a1(:,3);
a = mean(altura_a1);
b = std(altura_a1);
c = min(altura_a1);
d = max(altura_a1);

%SALIDA DE DATOS DE LA RUTA A1:
disp('Estadísticas de la ruta A1: ');
fprintf('Altura media: %f', a); 
fprintf('  (sd: %f)\n', b);
fprintf('Rango de alturas: [%f,', c);
fprintf(' %f]\n', d);




        
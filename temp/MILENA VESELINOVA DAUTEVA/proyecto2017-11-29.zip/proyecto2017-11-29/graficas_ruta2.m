datos = dlmread('n1-height.csv', ',', 1, 0);
altura=datos(:,3);
distancia = datos(:,4);
subplot(2,2,1)
plot(distancia,altura)
xlabel('distancia(km)')
ylabel('altura(m)')
longitud = datos(:,2);
latitud = datos(:,1);
subplot(2,2,2)
plot(latitud,longitud)
xlabel('longitud')
ylabel('latitud')

saveas(gcf, 'route-elevations2.png') 
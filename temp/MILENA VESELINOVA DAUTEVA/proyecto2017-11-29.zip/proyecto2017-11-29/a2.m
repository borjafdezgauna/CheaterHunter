datos = dlmread('a1-height.csv', ',', 1, 0);
altura=datos(:,3);
distancia = datos(:,4);
subplot(2,2,1)
plot(distancia,altura)
xlabel('distancia(km)')
ylabel('altura(m)')
longitud = datos(:,3);
latitud = datos(:,2);
subplot(2,2,2)
plot(latitud,longitud)
xlabel('longitud')
ylabel('latitud')
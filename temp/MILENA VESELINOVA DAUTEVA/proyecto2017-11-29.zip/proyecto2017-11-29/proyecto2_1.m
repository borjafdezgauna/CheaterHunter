datos1=dlmread('a1-driver1-log.csv')
velocidad=datos(:,2)
distancia_origen=datos(:,1)
subplot(2,2,1)
plot(distancia_origen, velocidad)
xlabel('distancia desde el origen (km)')
ylabel('velocidad (km/h)')
title('RUTA A1: CONDUCTOR 1')






hold on
subplot(1,2,1)
plot((n1Height(:,4)),(n1Height(:,3)))
xlabel('distance(km)')
ylabel('heights(m)')
subplot(1,2,2)
plot((a1Height(:,4)),(a1Height(:,3)))
xlabel('distance(km)')
ylabel('heights(m)')
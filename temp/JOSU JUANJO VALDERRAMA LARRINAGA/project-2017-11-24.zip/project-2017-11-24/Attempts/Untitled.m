n1Height = dlmread('n1-height.csv',',', 1, 0)
a1Height = dlmread('a1-height.csv',',', 1, 0)
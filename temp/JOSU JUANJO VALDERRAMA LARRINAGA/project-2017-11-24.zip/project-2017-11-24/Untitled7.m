n1Height = dlmread('n1-height.csv',',', 1, 0);
a1Height = dlmread('a1-height.csv',',', 1, 0);

hold on
subplot(1,2,1)
plot((n1Height(:,4)),(n1Height(:,3)),(a1Height(:,4)),(a1Height(:,3)))
xlabel('distance(km)')
ylabel('heights(m)')
title('HEIGHTS')

subplot(1,2,2)
plot((n1Height(:,2)),(n1Height(:,1)),(a1Height(:,2)),(a1Height(:,1)))
xlabel('longitude')
ylabel('latitude')
title('ROUTE')

saveas(gcf, 'route-elevations.png')

% write here the code for the lines below

disp ('n1 route statistics:')
fprintf('Mean height: %f (sd: %f)',,)
fprintf('Height range: [%f, %f]',,)

disp ('a1 route statistics:')
fprintf('Mean height: %f (sd: %f)',,)
fprintf('Height range: [%f, %f]',,)


disp('#######MENU#######:')
disp('1. Show route plots/statistics')
disp('2.Show driver plots/statistics')
disp('3.Time calculations for each driver/route')
disp('4.Check speed limits')
disp('5.Fuel consumption calculations for each driver/route')
disp('6.Exit')
disp('Choose an option:')
   for i>=1 && i<=6
     if i=1 
       dlmread('route_statistics')
     elseif i=2
       


function [interpolatedY] = interpolateLinearly (xvector, Yvector, x)
  i=1;
  while xvector(i)<=x
    i=i+1
    end
    y2=Yvector(i);
    y1=Yvector(i-1);
    x2=xvector(i);
    x1=xvector(i-1);
    slope= (y2-y1)/(x2-x1);
    interpolatedY= y1 + slope *(x-x1);
    
endfunction

s=0;
disp('## ## ## # MENU ## ## ## #')
disp('1. Show route plots/statistics')
disp('2. Show driver plots/statistics')
disp('3. Time calculations for each driver/route')
disp('4. Check speed limits')
disp('5. Fuel consumption calculations for each driver/route')
disp ('6. Exit')
i = input('Choose an option:');

while s==0
    
    if i == 1
        % clc cleans before outputs
        clc
        disp ('CompleteTask1')
        disp('Press any key to continue')
        pause
        disp('## ## ## # MENU ## ## ## #')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 2
        clc
        disp('Press any key to continue')
        pause
        disp('CompleteTask2')
        disp('## ## ## # MENU ## ## ## #')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 3
        clc
        disp('Press any key to continue')
        pause
        disp('CompleteTask3')
        disp('## ## ## # MENU ## ## ## #')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 4
        clc
        disp('Press any key to continue')
        pause
        disp('CompleteTask4')
        disp('## ## ## # MENU ## ## ## #')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 5
        clc
        disp('Press any key to continue')
        pause
        disp('CompleteTask5')
        disp('## ## ## # MENU ## ## ## #')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 6
        clc
        disp ('Exit')
        s=s+1;
    else
        clc
        disp('Error Incorrect option: it must be between 1 and 6')
        disp('## ## ## # MENU ## ## ## #')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    end
    
end


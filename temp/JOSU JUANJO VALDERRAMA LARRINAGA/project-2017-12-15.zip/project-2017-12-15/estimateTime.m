function [ estimatedTime ] = estimateTime ( kms, speedKmH, numSlices )

toMeters (kms);

toMetersPerSecond (speedKmH);

interpolateLinearly (m, msSpeed , numSlices)

end
%s=0 to enter the while
s=0;
disp('####### MENU #######')
disp('1. Show route plots/statistics')
disp('2. Show driver plots/statistics')
disp('3. Time calculations for each driver/route')
disp('4. Check speed limits')
disp('5. Fuel consumption calculations for each driver/route')
disp ('6. Exit')
i = input('Choose an option:');


while s==0
    
    if i == 1
        %clc cleans before outputs
        clc
        CompleteTask1Code
        disp('Press any key to continue')
        pause %the menu does not appear until we press any key
        clc
        disp('####### MENU #######')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 2
        clc
        CompleteTask2Code
        disp('Press any key to continue')
        pause
        clc
        disp('####### MENU #######')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 3
        clc
        Task4_6
         disp('Press any key to continue')
        pause
        clc
        disp('####### MENU #######')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 4
       clc
        disp('CompleteTask5Code')
         disp('Press any key to continue')
        pause
        clc
        disp('####### MENU #######')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 5
        clc
        disp('CompleteTask6Code')
         disp('Press any key to continue')
        pause
        clc
        disp('####### MENU #######')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    elseif i == 6
        clc
        disp ('Exit')
        s=s+1; %exits the loop
    else
        clc
        disp('Error Incorrect option: it must be between 1 and 6') %displays an error message
         disp('Press any key to continue')
        pause
        disp('####### MENU #######')
        disp('1. Show route plots/statistics')
        disp('2. Show driver plots/statistics')
        disp('3. Time calculations for each driver/route')
        disp('4. Check speed limits')
        disp('5. Fuel consumption calculations for each driver/route')
        disp ('6. Exit')
        i = input('Choose an option:');
        
    end
    
end











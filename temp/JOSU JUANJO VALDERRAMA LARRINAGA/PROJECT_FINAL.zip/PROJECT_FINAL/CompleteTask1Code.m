%read all the files avoiding the first line
n1Height = dlmread('n1-height.csv',',', 1, 0);
a1Height = dlmread('a1-height.csv',',', 1, 0);

%use hold on to show all the plots 
hold on
    subplot(1,2,1) %position of the plot
        plot((n1Height(:,4)),(n1Height(:,3)),(a1Height(:,4)),(a1Height(:,3)))
            xlabel('distance(km)') %names of labels and the title
            ylabel('heights(m)')
            title('HEIGHTS')

    subplot(1,2,2)
        plot((n1Height(:,2)),(n1Height(:,1)),(a1Height(:,2)),(a1Height(:,1)))
            xlabel('longitude')
            ylabel('latitude')
            title('ROUTE')
%save the image as .png
saveas(gcf, 'route-elevations.png')

%save the columns we need in a variable
y1 = n1Height(:,3);
y2 = a1Height(:,3);

%get the values we need
meanHeightN1 = mean(y1);
stdN1 = std(y1);
minimumHeightN1 = min(y1);
maximumHeightN1 = max(y1);
meanHeightA1 = mean(y2);
stdA1 = std(y2);
minimumHeightA1 = min(y2);
maximumHeightA1 = max(y2);
%display the answers
disp ('n1 route statistics:')
    fprintf('Mean height: %f (sd: %f)\n', meanHeightN1, stdN1)
    fprintf('Height range: [%f, %f]\n', minimumHeightN1, maximumHeightN1)

disp ('a1 route statistics:')
    fprintf('Mean height: %f (sd: %f)\n', meanHeightA1, stdA1)
    fprintf('Height range: [%f, %f]\n', minimumHeightA1, maximumHeightA1)


%read the files
n1Driver1 = dlmread('n1-driver1-log.csv',',');
a1Driver1= dlmread('a1-driver1-log.csv',',');

n1Driver2= dlmread('n1-driver2-log.csv',',');
a1Driver2= dlmread('a1-driver2-log.csv',',');

%plots
hold on
subplot(1,2,1)
plot((n1Driver1(:,1)),(n1Driver1(:,2)),(n1Driver2(:,1)),(n1Driver2(:,2)))
xlabel('distance (km)')
ylabel('speeds (km/h)')
title('SPEEDS N1')

subplot(1,2,2)
plot((a1Driver1(:,1)),(a1Driver1(:,2)),(a1Driver2(:,1)),(a1Driver2(:,2)))
xlabel('distance (km)')
ylabel('speeds (km/h)')
title('SPEEDS A1')

%to save the plot as .png
saveas(gcf, 'driver-speeds.png')


%save the columns we need in a variable 
y1 = n1Driver1(:,2);
y2 = n1Driver2(:,2);
y3 = a1Driver1(:,2);
y4 = a1Driver2(:,2);

%get the values we need
meanSpeedN1Driver1 = mean(y1);
stdN1Driver1 = std(y1);
minimumSpeedN1Driver1 = min(y1);
maximumSpeedN1Driver1 = max(y1);

meanSpeedN1Driver2 = mean(y2);
stdN1Driver2 = std(y2);
minimumSpeedN1Driver2 = min(y2);
maximumSpeedN1Driver2 = max(y2);


meanSpeedA1Driver1 = mean(y3);
stdA1Driver1 = std(y3);
minimumSpeedA1Driver1 = min(y3);
maximumSpeedA1Driver1 = max(y3);

meanSpeedA1Driver2 = mean(y4);
stdA1Driver2 = std(y4);
minimumSpeedA1Driver2 = min(y4);
maximumSpeedA1Driver2 = max(y4);

%display the answers
disp ('driver1 statistics in route n1')
    fprintf('Mean speed: % f (sd: % f)\n', meanSpeedN1Driver1, stdN1Driver1)
    fprintf('Min-Max speed: [% f, % f]\n', minimumSpeedN1Driver1, maximumSpeedN1Driver1)

disp ('driver2 statistics in route n1')
    fprintf('Mean speed: % f (sd: % f)\n', meanSpeedN1Driver2, stdN1Driver2)
    fprintf('Min-Max speed: [% f, % f]\n', minimumSpeedN1Driver2, maximumSpeedN1Driver2)
    
disp ('driver1 statistics in route a1')
    fprintf('Mean speed: % f (sd: % f)\n', meanSpeedA1Driver1, stdA1Driver1)
    fprintf('Min-Max speed: [% f, % f]\n', minimumSpeedA1Driver1, maximumSpeedA1Driver1)
    
disp ('driver2 statistics in route a1')
    fprintf('Mean speed: % f (sd: % f)\n', meanSpeedA1Driver2, stdA1Driver2)
    fprintf('Min-Max speed: [% f, % f]\n', minimumSpeedA1Driver2, maximumSpeedA1Driver2)



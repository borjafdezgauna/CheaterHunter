%%Funtzio honek kilometrotatik metrotara pasatuko du
function  [ m ] = tometers( km )
  m= km*1000;

endfunction

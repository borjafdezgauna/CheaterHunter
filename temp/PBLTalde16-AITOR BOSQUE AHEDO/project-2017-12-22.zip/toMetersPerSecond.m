%%Funtzo honek km/h-tatik m/s-ra pasatuko ditu
function  [ msSpeed ] = toMetersPerSecond( speedKmH )
  msSpeed= speedKmH/3.6;

endfunction

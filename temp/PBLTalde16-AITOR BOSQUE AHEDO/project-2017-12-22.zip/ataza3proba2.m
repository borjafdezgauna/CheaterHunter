fprintf('\tMenu\n 1. Show route plots/statistics\n 2. Show driver plots/statistics\n 3. Time calculations for each driver/route\n 4. Check speed limits\n 5. Fuel consumption calculations for each driver/route\n 6. Exit\n\n')
n=input('Hautatu nahi duzun atalaren zenbakia:');
while n~=6
    
   
if 1>n || n>6;
   fprintf('Aukera ezegokia: 1 eta 6 artean egon behar da\n')
   
   
elseif n==1;
     Ataza1finala
    
elseif n==2
    Ataza2bukatuta
    
elseif n==3

    
elseif n==4
   
elseif n==5
disp('Fuel consumption calculations for each driver/route')
end 

input('Sakatu edozein tekla menura bueltatzeko');

 fprintf('\n\tMenu\n 1. Show route plots/statistics\n 2. Show driver plots/statistics\n 3. Time calculations for each driver/route\n 4. Check speed limits\n 5. Fuel consumption calculations for each driver/route\n 6. Exit\n\n')
 
n=input('Hautatu nahi duzun atalaren zenbakia:');

end
  

 disp('Menuaren amaiera')
 




    
    